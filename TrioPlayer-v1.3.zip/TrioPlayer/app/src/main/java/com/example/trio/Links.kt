package com.example.trio

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MimeTypes

/** A pasted link is shown to the player as a one-movie "Title" from the source "link"; the web address is its id. */
const val LINK_SOURCE = "link"

fun isWebLink(s: String): Boolean {
    val u = s.trim()
    return (u.startsWith("http://", true) || u.startsWith("https://", true)) && u.length > 10 && u.none { it.isWhitespace() }
}

fun linkName(u: String): String {
    val path = u.substringBefore("?").substringBefore("#").trimEnd('/')
    val last = path.substringAfterLast('/').let { try { java.net.URLDecoder.decode(it, "UTF-8") } catch (e: Exception) { it } }
    val clean = last.substringBeforeLast('.', last).replace('.', ' ').replace('_', ' ').trim()
    return clean.ifBlank { u.substringAfter("//").substringBefore('/') }
}

fun linkReq(u: String): PlayReq = PlayReq(
    Title("$LINK_SOURCE:$u", LINK_SOURCE, u, linkName(u), null, false, "", 0.0, emptyList(), null, null, 0L, 0),
    emptyList(), null
)

/** Tells the player what kind of stream a link is when the address has no clear file ending. */
fun linkMime(u: String): String? {
    val l = u.lowercase()
    return when {
        l.contains(".m3u8") -> MimeTypes.APPLICATION_M3U8
        l.contains(".mpd") -> MimeTypes.APPLICATION_MPD
        else -> null
    }
}

@Composable
fun LinksScreen(store: Store, onPlay: (String) -> Unit) {
    val clip = LocalClipboardManager.current
    var url by remember { mutableStateOf("") }
    var recent by remember { mutableStateOf(store.recentLinks()) }
    val ok = isWebLink(url)
    fun play(u: String) { onPlay(u.trim()); recent = store.recentLinks() }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Play from a link", style = MaterialTheme.typography.titleLarge)
        Text(
            "Paste any video link: mp4, mkv, m3u8 (live / HLS), mpd and more. No server needed.",
            Modifier.padding(top = 4.dp, bottom = 12.dp), color = Color(0xFFB0B0B8), fontSize = 13.sp
        )
        OutlinedTextField(
            url, { url = it }, singleLine = true, label = { Text("Video link") }, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
        )
        if (url.isNotBlank() && !ok) Text("The link must start with http:// or https://", Modifier.padding(top = 4.dp), color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { clip.getText()?.text?.trim()?.let { url = it } }) { Text("Paste") }
            Button(onClick = { play(url) }, enabled = ok, modifier = Modifier.weight(1f)) { Text("▶  Play") }
        }
        if (recent.isNotEmpty()) Text("Recent links", Modifier.padding(top = 20.dp, bottom = 4.dp), style = MaterialTheme.typography.titleSmall)
        LazyColumn(Modifier.fillMaxSize()) {
            items(recent, key = { it }) { u ->
                ListItem(
                    headlineContent = { Text(linkName(u), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { Text(u, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    trailingContent = { TextButton(onClick = { store.removeLink(u); recent = store.recentLinks() }) { Text("✕") } },
                    modifier = Modifier.clickable { play(u) }
                )
            }
        }
    }
}
