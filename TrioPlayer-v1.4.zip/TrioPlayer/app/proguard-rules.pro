# video decoder (native code calls back into these classes) and the player
-keep class io.github.anilbeesetti.nextlib.** { *; }
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**
# network, images, background work
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn coil.**
-keep class androidx.work.** { *; }
-keep class com.example.trio.CatalogWorker { *; }
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
