package com.example.trio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import androidx.compose.runtime.Immutable
import java.io.File

const val DEFAULT_URL = "http://funtimebd.net:8096"

/** One Emby / Jellyfin server. Every server works like its own app: own catalog, home, search. */
@Immutable
data class Server(val id: String, val name: String, val url: String, val user: String, val pass: String, val token: String, val uid: String)

@Immutable
data class Hist(val titleKey: String, val epId: String?, val label: String, val pos: Long, val dur: Long, val time: Long) {
    val key get() = epId ?: titleKey
    val finished get() = dur > 0 && pos >= dur * 0.95
}

class Store(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("trio", Context.MODE_PRIVATE)

    // ---- the servers (accounts are typed in the app, never in the code)
    private var scache: List<Server>? = null

    init {
        if (!sp.contains("servers")) {
            // first start of this version: carry the single server of the older versions over, with its saved catalog
            val tok = sp.getString("etoken", "") ?: ""
            val uid = sp.getString("euid", "") ?: ""
            if (tok.isNotBlank() && uid.isNotBlank()) {
                saveServers(listOf(Server("funtimebd", "FuntimeBD", sp.getString("eurl", DEFAULT_URL) ?: DEFAULT_URL,
                    sp.getString("euser", "") ?: "", sp.getString("epass", "") ?: "", tok, uid)))
                sp.edit().putString("active", "funtimebd").apply()
                val old = File(ctx.filesDir, "catalog.json")
                if (old.exists()) old.renameTo(catFile("funtimebd"))
            } else saveServers(emptyList())
        }
    }

    private fun saveServers(l: List<Server>) {
        scache = l
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("n", it.name).put("u", it.url).put("us", it.user).put("p", it.pass).put("t", it.token).put("i", it.uid)) }
        sp.edit().putString("servers", a.toString()).apply()
    }
    fun servers(): List<Server> = scache ?: arr("servers").let { a ->
        (0 until a.length()).map { val o = a.getJSONObject(it); Server(o.getString("id"), o.getString("n"), o.getString("u"), o.optString("us"), o.optString("p"), o.optString("t"), o.optString("i")) }
    }.also { scache = it }
    fun server(id: String): Server? = servers().firstOrNull { it.id == id }
    val loggedIn get() = servers().isNotEmpty()

    /** the server whose home / search / list is on screen */
    var activeId: String
        get() = sp.getString("active", "")?.takeIf { server(it) != null } ?: servers().firstOrNull()?.id ?: ""
        set(v) { sp.edit().putString("active", v).apply() }

    fun upsertServer(s: Server) {
        val l = servers()
        saveServers(if (l.any { it.id == s.id }) l.map { if (it.id == s.id) s else it } else l + s)
    }
    /** a server that is already there (same address and user) is updated, otherwise a new one is added; returns its id */
    fun addOrUpdateServer(name: String, url: String, user: String, pass: String, token: String, uid: String): String {
        servers().firstOrNull { it.url.equals(url, true) && it.user.equals(user, true) }?.let {
            upsertServer(it.copy(name = name.ifBlank { it.name }, pass = pass, token = token, uid = uid)); return it.id
        }
        val host = url.substringAfter("//").substringBefore("/")
        var id = host.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifBlank { "server" }
        while (server(id) != null) id += "x"
        val shown = name.ifBlank { host.removePrefix("www.").substringBefore(":") }
        upsertServer(Server(id, shown, url, user, pass, token, uid))
        return id
    }
    fun removeServer(id: String) {
        saveServers(servers().filter { it.id != id })
        catFile(id).delete()
        if (sp.getString("active", "") == id) sp.edit().putString("active", servers().firstOrNull()?.id ?: "").apply()
    }

    /** true when the person chose to use the app without adding a server (links only) */
    var skipped: Boolean
        get() = sp.getBoolean("skipped", false)
        set(v) { sp.edit().putBoolean("skipped", v).apply() }

    // ---- recently played links (newest first, at most 25)
    fun recentLinks(): List<String> = arr("links").let { a -> (0 until a.length()).map { a.getString(it) } }
    fun addLink(u: String) {
        val l = recentLinks().toMutableList(); l.remove(u); l.add(0, u)
        sp.edit().putString("links", JSONArray(l.take(25)).toString()).apply()
    }
    fun removeLink(u: String) {
        val l = recentLinks().toMutableList(); l.remove(u)
        sp.edit().putString("links", JSONArray(l).toString()).apply()
    }

    val deviceId: String
        get() = sp.getString("dev", null) ?: java.util.UUID.randomUUID().toString().also { sp.edit().putString("dev", it).apply() }

    /** "http://host:8096/web/#/home.html" -> "http://host:8096" */
    fun normalize(u: String): String {
        var s = u.trim()
        if (s.isEmpty()) return s
        if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://$s"
        s = s.substringBefore("#").substringBefore("?")
        val i = s.indexOf("/web", 8)
        if (i > 0) s = s.substring(0, i)
        return s.trimEnd('/')
    }

    // ---- last full update, per server
    fun lastRefresh(id: String): Long = sp.getLong("lastref_$id", if (id == "funtimebd") sp.getLong("lastref", 0L) else 0L)
    fun setLastRefresh(id: String, v: Long) { sp.edit().putLong("lastref_$id", v).apply() }
    /** the server's own "recently added" lists (movies, series), newest first */
    fun latest(id: String): Pair<List<String>, List<String>> =
        (sp.getString("latm_$id", "") ?: "").split('\n').filter { it.isNotBlank() } to (sp.getString("lats_$id", "") ?: "").split('\n').filter { it.isNotBlank() }
    fun saveLatest(id: String, m: List<String>, s: List<String>) {
        sp.edit().putString("latm_$id", m.joinToString("\n")).putString("lats_$id", s.joinToString("\n")).apply()
    }
    /** auto | orig | 1080 | 720 | 480 */
    var quality: String
        get() = sp.getString("quality", "auto") ?: "auto"
        set(v) { sp.edit().putString("quality", v).apply() }
    var subLang: String
        get() = sp.getString("sublang", "") ?: ""
        set(v) { sp.edit().putString("sublang", v).apply() }

    // ---- catalog cache: one file per server, read and written as a stream (fast, little memory)
    private fun catFile(id: String) = File(ctx.filesDir, "catalog_$id.json")
    fun saveCatalog(id: String, list: List<Title>) {
        val tmp = File(ctx.filesDir, "catalog_$id.tmp")
        android.util.JsonWriter(tmp.bufferedWriter(Charsets.UTF_8, 64 * 1024)).use { w ->
            w.beginArray()
            for (t in list) {
                w.beginObject()
                w.name("k").value(t.key); w.name("s").value(t.source); w.name("i").value(t.id); w.name("n").value(t.name)
                w.name("sr").value(t.series); w.name("r").value(t.rating)
                w.name("g").beginArray(); for (g in t.genres) w.value(g); w.endArray()
                w.name("a").value(t.added); w.name("m").value(t.runtimeMin.toLong())
                t.year?.let { w.name("y").value(it.toLong()) }
                t.poster?.let { w.name("p").value(it) }
                t.backdrop?.let { w.name("b").value(it) }
                w.endObject()
            }
            w.endArray()
        }
        tmp.renameTo(catFile(id))
    }
    fun loadCatalog(id: String): List<Title> {
        val f = catFile(id)
        if (!f.exists()) return emptyList()
        return try {
            val out = ArrayList<Title>(8192)
            android.util.JsonReader(f.bufferedReader(Charsets.UTF_8, 64 * 1024)).use { r ->
                r.beginArray()
                while (r.hasNext()) {
                    var k = ""; var s = ""; var i = ""; var n = ""; var sr = false; var rt = 0.0; var a = 0L; var m = 0
                    var y: Int? = null; var p: String? = null; var b: String? = null; var g: List<String> = emptyList()
                    r.beginObject()
                    while (r.hasNext()) {
                        when (r.nextName()) {
                            "k" -> k = r.nextString()
                            "s" -> s = r.nextString()
                            "i" -> i = r.nextString()
                            "n" -> n = r.nextString()
                            "sr" -> sr = r.nextBoolean()
                            "r" -> rt = r.nextDouble()
                            "a" -> a = r.nextLong()
                            "m" -> m = r.nextInt()
                            "y" -> y = r.nextInt()
                            "p" -> p = r.nextString()
                            "b" -> b = r.nextString()
                            "g" -> { val l = ArrayList<String>(); r.beginArray(); while (r.hasNext()) l.add(r.nextString()); r.endArray(); g = l }
                            else -> r.skipValue()
                        }
                    }
                    r.endObject()
                    if (k.isNotEmpty()) out.add(Title(k, s, i, n, y, sr, "", rt, g, p, b, a, m))
                }
                r.endArray()
            }
            out
        } catch (e: Exception) { emptyList() }
    }

    // ---- my list and watch history
    private fun arr(k: String): JSONArray = try { JSONArray(sp.getString(k, "[]")) } catch (e: Exception) { JSONArray() }
    fun myList(): List<String> = arr("mylist").let { a -> (0 until a.length()).map { a.getString(it) } }
    fun toggleMyList(key: String) {
        val l = myList().toMutableList()
        if (!l.remove(key)) l.add(0, key)
        sp.edit().putString("mylist", JSONArray(l).toString()).apply()
    }
    fun favs(): List<String> = arr("favs").let { a -> (0 until a.length()).map { a.getString(it) } }
    fun toggleFav(key: String) {
        val l = favs().toMutableList()
        if (!l.remove(key)) l.add(0, key)
        sp.edit().putString("favs", JSONArray(l).toString()).apply()
    }
    // history lives in memory and is written to disk at most every 30 s (or when you leave the player): far less work for the phone
    private var hcache: MutableList<Hist>? = null
    private var lastFlush = 0L
    /** a copy, so screens notice changes when they ask again */
    fun history(): List<Hist> = hc().toList()
    private fun hc(): MutableList<Hist> = hcache ?: arr("hist").let { a ->
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Hist(o.getString("t"), o.optString("e").ifEmpty { null }, o.optString("l"), o.getLong("p"), o.getLong("d"), o.getLong("w"))
        }
    }.toMutableList().also { hcache = it }
    fun flushHistory() {
        val a = JSONArray()
        hc().take(400).forEach { h ->
            a.put(JSONObject().put("t", h.titleKey).put("e", h.epId ?: "").put("l", h.label).put("p", h.pos).put("d", h.dur).put("w", h.time))
        }
        sp.edit().putString("hist", a.toString()).apply()
        lastFlush = System.currentTimeMillis()
    }
    fun saveProgress(titleKey: String, epId: String?, label: String, pos: Long, dur: Long, flush: Boolean = false) {
        if (pos < 1000) return
        val l = hc()
        l.removeAll { it.key == (epId ?: titleKey) }
        l.add(0, Hist(titleKey, epId, label, pos, dur, System.currentTimeMillis()))
        if (flush || System.currentTimeMillis() - lastFlush > 30_000L) flushHistory()
    }
    /** "Remove from Continue Watching": drops the unfinished entries of this movie / series (finished episodes keep their marks) */
    fun removeFromContinue(titleKey: String) {
        hc().removeAll { it.titleKey == titleKey && !it.finished }
        flushHistory()
    }
    fun resumePosition(key: String): Long {
        val h = hc().firstOrNull { it.key == key } ?: return 0
        return if (h.pos > 5000 && (h.dur <= 0 || h.pos < h.dur - 15000)) h.pos else 0
    }
}
