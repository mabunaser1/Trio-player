package com.example.trio

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Holds the saved servers. Every server is like its own app: its own catalog, home rows and search.
 * `titles` is always the catalog of the ACTIVE server; switching loads the other one from its own file.
 */
class Repo(private val ctx: Context, val store: Store) {
    private val srcs = HashMap<String, EmbySource>()
    fun source(id: String): EmbySource = srcs.getOrPut(id) { EmbySource(store, id) }

    var servers by mutableStateOf(store.servers())
    var activeId by mutableStateOf(store.activeId)
    val activeServer: Server? get() = servers.firstOrNull { it.id == activeId }

    var titles by mutableStateOf<List<Title>>(emptyList())
    var byKey by mutableStateOf<Map<String, Title>>(emptyMap())
    var latestM by mutableStateOf<List<String>>(emptyList())
    var latestS by mutableStateOf<List<String>>(emptyList())
    var loading by mutableStateOf(false)
    var refreshing by mutableStateOf(false)
    var progress by mutableStateOf("")
    var lastError by mutableStateOf("")
    private var lastQuick = 0L

    private fun set(list: List<Title>) { titles = list; byKey = list.associateBy { it.key } }
    private fun sync() { servers = store.servers(); activeId = store.activeId }
    private fun clear() { titles = emptyList(); byKey = emptyMap(); latestM = emptyList(); latestS = emptyList(); lastError = ""; lastQuick = 0L }

    /** the saved catalog of the active server, read off the main thread */
    suspend fun loadCache() {
        val id = activeId
        if (id.isBlank() || titles.isNotEmpty()) return
        loading = true
        try {
            val list = withContext(Dispatchers.IO) { store.loadCatalog(id) }
            if (id == activeId && titles.isEmpty()) {
                set(list)
                val (m, s) = store.latest(id); latestM = m; latestS = s
            }
        } finally { loading = false }
    }

    suspend fun switchTo(id: String) {
        if (store.server(id) == null) return
        store.activeId = id; sync(); clear()
        loadCache()
    }

    /** Signs in and saves the server (a new one, or the same address + user again); it becomes the active one. Returns an error text or null. */
    suspend fun addServer(name: String, url: String, user: String, pass: String): String? {
        val (auth, err) = EmbyAuth.login(store, url, user, pass)
        if (auth == null) return err ?: "Could not sign in"
        val id = store.addOrUpdateServer(name.trim(), auth.url, user, pass, auth.token, auth.uid)
        srcs.remove(id)
        store.activeId = id; sync(); clear()
        loadCache()
        return null
    }

    suspend fun removeServer(id: String) {
        val wasActive = id == activeId
        store.removeServer(id); srcs.remove(id); sync()
        if (wasActive) { clear(); loadCache() }
    }

    fun isStale(id: String) = System.currentTimeMillis() - store.lastRefresh(id) > 24 * 3600_000L

    /** Downloads the whole catalog again (parallel pages). Normally at most once a day, or when you ask for it. */
    suspend fun refresh(force: Boolean = false, id: String = activeId): Boolean {
        if (id.isBlank() || store.server(id) == null) return true
        if (refreshing) return true
        if (!force && !isStale(id) && (id != activeId || titles.isNotEmpty())) return true
        refreshing = true; if (id == activeId) lastError = ""
        var ok = false
        try {
            val all = source(id).catalog { n, total -> if (id == activeId) progress = "$n / $total" }
            if (all.isNotEmpty()) {
                val sorted = withContext(Dispatchers.Default) { all.sortedByDescending { it.added } }
                withContext(Dispatchers.IO) { store.saveCatalog(id, sorted) }
                if (id == activeId) set(sorted)
            }
            store.setLastRefresh(id, System.currentTimeMillis())
            ok = true
        } catch (e: Exception) {
            if (id == activeId) lastError = e.message ?: "Update failed"
        } finally { refreshing = false; progress = "" }
        if (ok && id == activeId) quickRefresh(force = true)
        return ok
    }

    /**
     * What the server's web page shows under "recently added": two small requests, merged into the catalog.
     * Runs every time the app opens (at most every 5 minutes), so new movies and episodes show up at once.
     */
    suspend fun quickRefresh(force: Boolean = false) {
        val id = activeId
        if (id.isBlank() || store.server(id) == null || refreshing) return
        val now = System.currentTimeMillis()
        if (!force && now - lastQuick < 5 * 60_000L) return
        lastQuick = now
        try {
            val (m, s) = source(id).latest()
            if (id != activeId) return
            val merged = withContext(Dispatchers.Default) {
                val map = LinkedHashMap<String, Title>(titles.size * 2 + 16)
                for (t in titles) map[t.key] = t
                var changed = false
                for (t in m + s) if (map[t.key] != t) { map[t.key] = t; changed = true }
                if (changed) map.values.sortedByDescending { it.added } else null
            }
            latestM = m.map { it.key }; latestS = s.map { it.key }
            store.saveLatest(id, latestM, latestS)
            if (merged != null && id == activeId) {
                set(merged)
                withContext(Dispatchers.IO) { store.saveCatalog(id, merged) }
            }
        } catch (e: Exception) { /* offline: the saved lists stay */ }
    }

    /** Instant results from the saved catalog, then everything the server's own search finds. */
    suspend fun localSearch(q: String): List<Title> = withContext(Dispatchers.Default) {
        val toks = q.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (toks.isEmpty()) return@withContext emptyList<Title>()
        val nq = q.lowercase().filter { it.isLetterOrDigit() }
        titles.filter { t -> toks.all { t.lc.contains(it) } || (nq.length >= 3 && t.nn.contains(nq)) }
            .sortedWith(compareBy({ !it.lc.startsWith(toks[0]) }, { it.lc }))
    }

    suspend fun serverSearch(q: String): List<Title> {
        val id = activeId
        if (store.server(id) == null) return emptyList()
        return try { source(id).search(q) } catch (e: Exception) { emptyList() }
    }

    suspend fun details(t: Title): String = if (t.source == LINK_SOURCE || store.server(t.source) == null) t.overview else source(t.source).details(t)
    suspend fun episodes(t: Title): List<Episode> = source(t.source).episodes(t)
    suspend fun stream(t: Title, ep: Episode?): Stream =
        if (t.source == LINK_SOURCE) Stream(t.id, emptyList(), 0L, 0, "") { _, _ -> t.id } else source(t.source).stream(t, ep)

    companion object {
        /** Asks Android to refresh the catalogs once a day in the background, on unmetered (home wifi) networks. */
        fun scheduleDaily(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<CatalogWorker>(24, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.UNMETERED).setRequiresBatteryNotLow(true).build()).build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("catalog-daily", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}

class CatalogWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        val store = Store(applicationContext)
        if (!store.loggedIn) return Result.success()
        val repo = Repo(applicationContext, store)
        var ok = true
        for (s in store.servers()) if (!repo.refresh(force = true, id = s.id)) ok = false
        return if (ok) Result.success() else Result.retry()
    }
}
