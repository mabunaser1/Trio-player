package com.example.trio

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

class AuthException(msg: String) : IOException(msg)

/**
 * Emby and Jellyfin share this API. Search is the server's own search (SearchTerm), so it covers the whole library,
 * exactly like typing in the server's web page. The full catalog is downloaded page by page once a day.
 */
class EmbySource(private val store: Store) : Source {
    override val id = "funtimebd"
    override val name = "FuntimeBD"
    override val home get() = store.embyUrl
    override val ready get() = store.loggedIn

    private val http = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS).readTimeout(40, TimeUnit.SECONDS).build()

    private val base get() = store.embyUrl
    private val token get() = store.embyToken
    private val uid get() = store.embyUid

    private fun authHeader() =
        "MediaBrowser Client=\"Trio Player\", Device=\"Android\", DeviceId=\"${store.deviceId}\", Version=\"1.0\""

    /** Returns null on success, otherwise a message for the user. */
    suspend fun login(url: String, user: String, pass: String): String? = withContext<String?>(Dispatchers.IO) {
        try {
            val b = store.normalize(url)
            if (b.isBlank()) return@withContext "Enter the server address"
            val body = JSONObject().put("Username", user).put("Pw", pass).toString()
                .toRequestBody("application/json".toMediaType())
            val req = Request.Builder().url("$b/Users/AuthenticateByName").post(body)
                .header("X-Emby-Authorization", authHeader()).header("Authorization", authHeader()).build()
            http.newCall(req).execute().use { r ->
                if (r.code == 401 || r.code == 400) return@withContext "Wrong username or password"
                if (!r.isSuccessful) return@withContext "The server answered HTTP ${r.code}"
                val o = JSONObject(r.body!!.string())
                store.embyUrl = b; store.embyUser = user; store.embyPass = pass
                store.embyToken = o.getString("AccessToken")
                store.embyUid = o.getJSONObject("User").getString("Id")
                null
            }
        } catch (e: Exception) {
            "Cannot reach the server (${e.message ?: "network error"}). Are you on the BDIX wifi?"
        }
    }

    private fun rawGet(path: String, params: Map<String, String>): JSONObject {
        val b = "$base$path".toHttpUrl().newBuilder()
        params.forEach { (k, v) -> b.addQueryParameter(k, v) }
        b.addQueryParameter("api_key", token)
        val req = Request.Builder().url(b.build()).header("X-Emby-Token", token).build()
        http.newCall(req).execute().use { r ->
            if (r.code == 401) throw AuthException("Session expired")
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            return JSONObject(r.body!!.string())
        }
    }

    private suspend fun get(path: String, params: Map<String, String> = emptyMap()): JSONObject = withContext(Dispatchers.IO) {
        try { rawGet(path, params) }
        catch (e: AuthException) {
            // token no longer valid: sign in again with the saved account, then retry once
            if (login(base, store.embyUser, store.embyPass) != null) throw e
            rawGet(path, params)
        }
    }

    private fun img(id: String, type: String, w: Int) = "$base/Items/$id/Images/$type?maxWidth=$w&quality=85&api_key=$token"

    private fun parseDate(s: String): Long = try {
        val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US); f.timeZone = TimeZone.getTimeZone("UTC")
        f.parse(s.take(19))?.time ?: 0L
    } catch (e: Exception) { 0L }

    private fun title(o: JSONObject): Title {
        val id = o.getString("Id")
        val hasPoster = o.optJSONObject("ImageTags")?.has("Primary") == true
        val hasBackdrop = (o.optJSONArray("BackdropImageTags")?.length() ?: 0) > 0
        val g = o.optJSONArray("Genres")
        return Title(
            key = "funtimebd:$id", source = "funtimebd", id = id, name = o.optString("Name"),
            year = if (o.has("ProductionYear")) o.optInt("ProductionYear") else null,
            series = o.optString("Type") == "Series", overview = o.optString("Overview"),
            rating = o.optDouble("CommunityRating", 0.0),
            genres = if (g == null) emptyList() else (0 until g.length()).map { g.getString(it) },
            poster = if (hasPoster) img(id, "Primary", 400) else null,
            backdrop = if (hasBackdrop) img(id, "Backdrop", 1280) else null,
            added = parseDate(o.optString("DateCreated")),
            runtimeMin = (o.optLong("RunTimeTicks") / 600_000_000L).toInt()
        )
    }

    private val fields = "Overview,Genres,CommunityRating,ProductionYear,DateCreated,RunTimeTicks"

    override suspend fun catalog(onProgress: (Int, Int) -> Unit): List<Title> {
        val out = ArrayList<Title>()
        var start = 0
        val page = 500
        while (true) {
            val o = get(
                "/Users/$uid/Items", mapOf(
                    "IncludeItemTypes" to "Movie,Series", "Recursive" to "true", "Fields" to fields,
                    "SortBy" to "DateCreated", "SortOrder" to "Descending",
                    "StartIndex" to "$start", "Limit" to "$page"
                )
            )
            val items = o.optJSONArray("Items") ?: break
            for (i in 0 until items.length()) out.add(title(items.getJSONObject(i)))
            start += items.length()
            val total = o.optInt("TotalRecordCount", start)
            onProgress(start, total)
            if (items.length() == 0 || start >= total) break
        }
        return out
    }

    /** The server's own search over its whole library. */
    override suspend fun search(q: String): List<Title> {
        val o = get(
            "/Users/$uid/Items", mapOf(
                "SearchTerm" to q, "IncludeItemTypes" to "Movie,Series", "Recursive" to "true",
                "Fields" to fields, "Limit" to "200"
            )
        )
        val items = o.optJSONArray("Items") ?: return emptyList()
        return (0 until items.length()).map { title(items.getJSONObject(it)) }
    }

    override suspend fun episodes(t: Title): List<Episode> {
        val o = get("/Shows/${t.id}/Episodes", mapOf("userId" to uid, "Fields" to "Overview,RunTimeTicks"))
        val items = o.optJSONArray("Items") ?: return emptyList()
        return (0 until items.length()).map {
            val e = items.getJSONObject(it)
            val id = e.getString("Id")
            val hasThumb = e.optJSONObject("ImageTags")?.has("Primary") == true
            Episode(
                id, e.optString("Name"), e.optInt("ParentIndexNumber", 0), e.optInt("IndexNumber", 0),
                (e.optLong("RunTimeTicks") / 600_000_000L).toInt(), if (hasThumb) img(id, "Primary", 480) else null, e.optString("Overview")
            )
        }.sortedWith(compareBy({ it.season }, { it.number }))
    }

    override suspend fun stream(t: Title, ep: Episode?): Stream {
        val itemId = ep?.id ?: t.id
        val o = get("/Users/$uid/Items/$itemId")
        val ms = o.optJSONArray("MediaSources")?.optJSONObject(0)
        val msId = ms?.optString("Id")?.ifBlank { null } ?: itemId
        val subs = ArrayList<SubTrack>()
        val streams = ms?.optJSONArray("MediaStreams")
        if (streams != null) for (i in 0 until streams.length()) {
            val s = streams.getJSONObject(i)
            if (s.optString("Type") != "Subtitle" || !s.optBoolean("IsExternal")) continue
            if (s.has("IsTextSubtitleStream") && !s.optBoolean("IsTextSubtitleStream")) continue
            val codec = s.optString("Codec").lowercase()
            val ext = when (codec) { "ass", "ssa" -> "ass"; "vtt", "webvtt" -> "vtt"; else -> "srt" }
            val mime = when (ext) { "ass" -> "text/x-ssa"; "vtt" -> "text/vtt"; else -> "application/x-subrip" }
            val label = s.optString("DisplayTitle").ifBlank { s.optString("Language").ifBlank { "Subtitle ${i + 1}" } }
            subs.add(SubTrack(label, "$base/Videos/$itemId/$msId/Subtitles/${s.optInt("Index")}/0/Stream.$ext?api_key=$token", s.optString("Language").ifBlank { null }, mime))
        }
        val direct = "$base/Videos/$itemId/stream?static=true&MediaSourceId=$msId&api_key=$token"
        // used only if the phone cannot play the original file: the server converts it to H.264/AAC (best effort)
        val compat = "$base/Videos/$itemId/master.m3u8?MediaSourceId=$msId&VideoCodec=h264&AudioCodec=aac&TranscodingMaxAudioChannels=2" +
            "&SegmentContainer=ts&DeviceId=${store.deviceId}&PlaySessionId=${System.currentTimeMillis()}&api_key=$token"
        return Stream(direct, compat, subs)
    }
}
