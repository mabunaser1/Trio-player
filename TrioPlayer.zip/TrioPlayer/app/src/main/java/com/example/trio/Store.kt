package com.example.trio

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Hist(val titleKey: String, val epId: String?, val label: String, val pos: Long, val dur: Long, val time: Long) {
    val key get() = epId ?: titleKey
    val finished get() = dur > 0 && pos >= dur * 0.95
}

class Store(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("trio", Context.MODE_PRIVATE)

    // ---- the Emby / Jellyfin server (account is typed in the app, never in the code)
    var embyUrl: String
        get() = sp.getString("eurl", "http://funtimebd.net:8096") ?: ""
        set(v) { sp.edit().putString("eurl", normalize(v)).apply() }
    var embyUser: String
        get() = sp.getString("euser", "") ?: ""
        set(v) { sp.edit().putString("euser", v.trim()).apply() }
    var embyPass: String
        get() = sp.getString("epass", "") ?: ""
        set(v) { sp.edit().putString("epass", v).apply() }
    var embyToken: String
        get() = sp.getString("etoken", "") ?: ""
        set(v) { sp.edit().putString("etoken", v).apply() }
    var embyUid: String
        get() = sp.getString("euid", "") ?: ""
        set(v) { sp.edit().putString("euid", v).apply() }
    val loggedIn get() = embyToken.isNotBlank() && embyUid.isNotBlank()

    /** true when the person chose to use the app without adding a server (links only) */
    var skipped: Boolean
        get() = sp.getBoolean("skipped", false)
        set(v) { sp.edit().putBoolean("skipped", v).apply() }

    // ---- recently played links (newest first, at most 25)
    fun recentLinks(): List<String> = arr("links").let { a -> (0 until a.length()).map { a.getString(it) } }
    fun addLink(u: String) {
        val l = recentLinks().toMutableList(); l.remove(u); l.add(0, u)
        sp.edit().putString("links", JSONArray(l.take(25)).toString()).apply()
    }
    fun removeLink(u: String) {
        val l = recentLinks().toMutableList(); l.remove(u)
        sp.edit().putString("links", JSONArray(l).toString()).apply()
    }

    fun logout() { sp.edit().remove("etoken").remove("euid").remove("epass").apply() }

    val deviceId: String
        get() = sp.getString("dev", null) ?: java.util.UUID.randomUUID().toString().also { sp.edit().putString("dev", it).apply() }

    /** "http://host:8096/web/#/home.html" -> "http://host:8096" */
    fun normalize(u: String): String {
        var s = u.trim()
        if (s.isEmpty()) return s
        if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://$s"
        s = s.substringBefore("#").substringBefore("?")
        val i = s.indexOf("/web", 8)
        if (i > 0) s = s.substring(0, i)
        return s.trimEnd('/')
    }

    // ---- daily refresh
    var lastRefresh: Long
        get() = sp.getLong("lastref", 0L)
        set(v) { sp.edit().putLong("lastref", v).apply() }
    /** auto | orig | 1080 | 720 | 480 */
    var quality: String
        get() = sp.getString("quality", "auto") ?: "auto"
        set(v) { sp.edit().putString("quality", v).apply() }
    var subLang: String
        get() = sp.getString("sublang", "") ?: ""
        set(v) { sp.edit().putString("sublang", v).apply() }

    // ---- catalog cache (streamed to disk, a big library as one string would use too much memory)
    private fun catFile() = File(ctx.filesDir, "catalog.json")
    fun saveCatalog(list: List<Title>) {
        val tmp = File(ctx.filesDir, "catalog.tmp")
        tmp.bufferedWriter().use { w ->
            w.write("[")
            list.forEachIndexed { n, t ->
                val o = JSONObject().put("k", t.key).put("s", t.source).put("i", t.id).put("n", t.name).put("sr", t.series)
                    .put("o", t.overview).put("r", t.rating).put("g", JSONArray(t.genres)).put("a", t.added).put("m", t.runtimeMin)
                t.year?.let { o.put("y", it) }; t.poster?.let { o.put("p", it) }; t.backdrop?.let { o.put("b", it) }
                if (n > 0) w.write(",")
                w.write(o.toString())
            }
            w.write("]")
        }
        tmp.renameTo(catFile())
    }
    fun loadCatalog(): List<Title> = try {
        val a = JSONArray(catFile().readText())
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            val g = o.optJSONArray("g")
            Title(
                o.getString("k"), o.getString("s"), o.getString("i"), o.getString("n"), if (o.has("y")) o.getInt("y") else null,
                o.optBoolean("sr"), o.optString("o"), o.optDouble("r", 0.0),
                if (g == null) emptyList() else (0 until g.length()).map { i -> g.getString(i) },
                o.optString("p").ifEmpty { null }, o.optString("b").ifEmpty { null }, o.optLong("a"), o.optInt("m")
            )
        }
    } catch (e: Exception) { emptyList() }

    // ---- my list and watch history
    private fun arr(k: String): JSONArray = try { JSONArray(sp.getString(k, "[]")) } catch (e: Exception) { JSONArray() }
    fun myList(): List<String> = arr("mylist").let { a -> (0 until a.length()).map { a.getString(it) } }
    fun toggleMyList(key: String) {
        val l = myList().toMutableList()
        if (!l.remove(key)) l.add(0, key)
        sp.edit().putString("mylist", JSONArray(l).toString()).apply()
    }
    // history lives in memory and is written to disk at most every 30 s (or when you leave the player): far less work for the phone
    private var hcache: MutableList<Hist>? = null
    private var lastFlush = 0L
    /** a copy, so screens notice changes when they ask again */
    fun history(): List<Hist> = hc().toList()
    private fun hc(): MutableList<Hist> = hcache ?: arr("hist").let { a ->
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Hist(o.getString("t"), o.optString("e").ifEmpty { null }, o.optString("l"), o.getLong("p"), o.getLong("d"), o.getLong("w"))
        }
    }.toMutableList().also { hcache = it }
    fun flushHistory() {
        val a = JSONArray()
        hc().take(400).forEach { h ->
            a.put(JSONObject().put("t", h.titleKey).put("e", h.epId ?: "").put("l", h.label).put("p", h.pos).put("d", h.dur).put("w", h.time))
        }
        sp.edit().putString("hist", a.toString()).apply()
        lastFlush = System.currentTimeMillis()
    }
    fun saveProgress(titleKey: String, epId: String?, label: String, pos: Long, dur: Long, flush: Boolean = false) {
        if (pos < 1000) return
        val l = hc()
        l.removeAll { it.key == (epId ?: titleKey) }
        l.add(0, Hist(titleKey, epId, label, pos, dur, System.currentTimeMillis()))
        if (flush || System.currentTimeMillis() - lastFlush > 30_000L) flushHistory()
    }
    fun resumePosition(key: String): Long {
        val h = hc().firstOrNull { it.key == key } ?: return 0
        return if (h.pos > 5000 && (h.dur <= 0 || h.pos < h.dur - 15000)) h.pos else 0
    }
}
