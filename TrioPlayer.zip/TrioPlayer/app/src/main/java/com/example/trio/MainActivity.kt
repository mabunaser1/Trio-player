package com.example.trio

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    // a video link sent to the app from a browser or another app ("Open with" / "Share")
    private var incoming by mutableStateOf<String?>(null)

    private fun linkFrom(i: Intent?): String? {
        if (i == null) return null
        val d = i.data
        if (i.action == Intent.ACTION_VIEW && d != null) return d.toString()
        if (i.action == Intent.ACTION_SEND) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return null
            return Regex("https?://\\S+").find(t)?.value
        }
        return null
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); setIntent(intent); incoming = linkFrom(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        incoming = linkFrom(intent)
        // smaller bitmaps (RGB565) and no re-downloading of posters: less memory, less network, less battery
        coil.Coil.setImageLoader(
            coil.ImageLoader.Builder(this).allowRgb565(true).crossfade(false).respectCacheHeaders(false)
                .memoryCache { coil.memory.MemoryCache.Builder(this).maxSizePercent(0.12).build() }   // posters never take more than 12% of the memory
                .diskCache { coil.disk.DiskCache.Builder().directory(cacheDir.resolve("posters")).maxSizeBytes(120L * 1024 * 1024).build() }
                .build()
        )
        val scheme = darkColorScheme(
            primary = RED_, onPrimary = Color.White, background = BG, surface = BG,
            surfaceVariant = Color(0xFF1F1F23), onSurfaceVariant = Color(0xFFB0B0B8)
        )
        setContent { MaterialTheme(colorScheme = scheme) { Surface(Modifier.fillMaxSize()) { App(incoming) { incoming = null } } } }
    }
}

@Composable
fun App(incoming: String?, onConsumed: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val repo = remember { Repo(ctx, store) }
    val scope = rememberCoroutineScope()
    var loggedIn by remember { mutableStateOf(store.loggedIn) }
    var tab by remember { mutableStateOf(if (store.loggedIn) 0 else 2) }
    var skipped by remember { mutableStateOf(store.skipped) }
    var detail by remember { mutableStateOf<Title?>(null) }
    var play by remember { mutableStateOf<PlayReq?>(null) }
    var hist by remember { mutableStateOf(store.history()) }
    var myList by remember { mutableStateOf(store.myList()) }

    LaunchedEffect(Unit) { repo.loadCache() }
    LaunchedEffect(incoming) {
        val u = incoming
        if (u != null) { if (isWebLink(u)) store.addLink(u); play = linkReq(u); onConsumed() }
    }
    // once a day: opening the app refreshes the library when the last update is older than 24 h; a background job does the same
    LaunchedEffect(loggedIn) {
        if (loggedIn) { repo.refresh(); Repo.scheduleDaily(ctx) }
    }

    val pl = play
    val d = detail
    when {
        pl != null -> PlayerScreen(pl, repo, store) { play = null; hist = store.history() }
        !loggedIn && !skipped -> LoginScreen(repo, onDone = { loggedIn = true; tab = 0 }, onSkip = { store.skipped = true; skipped = true })
        d != null -> DetailScreen(
            t = d, repo = repo, hist = hist, inList = d.key in myList,
            onToggleList = { store.toggleMyList(d.key); myList = store.myList() },
            onPlay = { play = it }, onBack = { detail = null }
        )
        else -> Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> HomeScreen(
                        repo, hist, myList, onOpen = { detail = it },
                        onResume = { h, t ->
                            // jump straight back into the episode or movie that was being watched
                            scope.launch {
                                val eps = if (t.series) try { repo.episodes(t) } catch (e: Exception) { emptyList() } else emptyList()
                                play = PlayReq(t, eps, eps.firstOrNull { it.id == h.epId })
                            }
                        }
                    )
                    1 -> SearchScreen(repo) { detail = it }
                    2 -> LinksScreen(store) { u -> store.addLink(u); play = linkReq(u) }
                    else -> SourcesScreen(
                        repo, onUpdate = { scope.launch { repo.refresh(force = true) } },
                        onSignOut = { store.logout(); store.skipped = false; skipped = false; loggedIn = false }
                    )
                }
            }
            NavigationBar {
                listOf("Home" to "🏠", "Search" to "🔍", "Links" to "🔗", "Servers" to "📡").forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(icon) }, label = { Text(label) })
                }
            }
        }
    }
}
