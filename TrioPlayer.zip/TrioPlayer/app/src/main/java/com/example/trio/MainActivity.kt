package com.example.trio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scheme = darkColorScheme(
            primary = RED_, onPrimary = Color.White, background = BG, surface = BG,
            surfaceVariant = Color(0xFF1F1F23), onSurfaceVariant = Color(0xFFB0B0B8)
        )
        setContent { MaterialTheme(colorScheme = scheme) { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val repo = remember { Repo(ctx, store) }
    val scope = rememberCoroutineScope()
    var loggedIn by remember { mutableStateOf(store.loggedIn) }
    var tab by remember { mutableStateOf(0) }
    var detail by remember { mutableStateOf<Title?>(null) }
    var play by remember { mutableStateOf<PlayReq?>(null) }
    var hist by remember { mutableStateOf(store.history()) }
    var myList by remember { mutableStateOf(store.myList()) }

    LaunchedEffect(Unit) { repo.loadCache() }
    // once a day: opening the app refreshes the library when the last update is older than 24 h; a background job does the same
    LaunchedEffect(loggedIn) {
        if (loggedIn) { repo.refresh(); Repo.scheduleDaily(ctx) }
    }

    val pl = play
    val d = detail
    when {
        !loggedIn -> LoginScreen(repo) { loggedIn = true }
        pl != null -> PlayerScreen(pl, repo, store) { play = null; hist = store.history() }
        d != null -> DetailScreen(
            t = d, repo = repo, hist = hist, inList = d.key in myList,
            onToggleList = { store.toggleMyList(d.key); myList = store.myList() },
            onPlay = { play = it }, onBack = { detail = null }
        )
        else -> Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> HomeScreen(
                        repo, hist, myList, onOpen = { detail = it },
                        onResume = { h, t ->
                            // jump straight back into the episode or movie that was being watched
                            scope.launch {
                                val eps = if (t.series) try { repo.episodes(t) } catch (e: Exception) { emptyList() } else emptyList()
                                play = PlayReq(t, eps, eps.firstOrNull { it.id == h.epId })
                            }
                        }
                    )
                    1 -> SearchScreen(repo) { detail = it }
                    else -> SourcesScreen(
                        repo, onUpdate = { scope.launch { repo.refresh(force = true) } },
                        onSignOut = { store.logout(); loggedIn = false }
                    )
                }
            }
            NavigationBar {
                listOf("Home" to "🏠", "Search" to "🔍", "Sources" to "📡").forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(icon) }, label = { Text(label) })
                }
            }
        }
    }
}
