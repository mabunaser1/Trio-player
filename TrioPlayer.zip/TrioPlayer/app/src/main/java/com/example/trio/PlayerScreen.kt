package com.example.trio

import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

private val GREEN = Color(0xFF46D369)
private val RED = Color(0xFFE50914)
private val PANEL = Color(0xFF2B2B2B)

@Composable
private fun PlayIcon(dp: Dp, color: Color = Color.White) {
    Canvas(Modifier.size(dp)) {
        val w = this.size.width; val h = this.size.height
        val p = Path().apply { moveTo(w * 0.28f, h * 0.18f); lineTo(w * 0.28f, h * 0.82f); lineTo(w * 0.82f, h * 0.5f); close() }
        drawPath(p, color)
    }
}

@Composable
private fun PauseIcon(dp: Dp, color: Color = Color.White) {
    Canvas(Modifier.size(dp)) {
        val w = this.size.width; val h = this.size.height
        drawRect(color, Offset(w * 0.24f, h * 0.18f), Size(w * 0.17f, h * 0.64f))
        drawRect(color, Offset(w * 0.59f, h * 0.18f), Size(w * 0.17f, h * 0.64f))
    }
}

/** Round "10" seek button: back = turn left, forward = turn right. */
@Composable
private fun Seek10(forward: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(72.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(6.dp)) {
            drawArc(
                Color(0xFFA0A0A0), startAngle = -60f, sweepAngle = 300f, useCenter = false,
                style = Stroke(width = 6f)
            )
        }
        Text("10", color = Color(0xFFA0A0A0), fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BarButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.size(46.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) { content() }
}

@Composable
private fun PanelRow(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(if (selected) Color(0xFF3A3A3A) else Color.Transparent).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(4.dp).height(52.dp).background(if (selected) RED else Color.Transparent))
        Text(
            (if (selected) "▶   " else "      ") + text, Modifier.padding(horizontal = 12.dp),
            color = if (selected) GREEN else Color.White, fontSize = 19.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun PanelHeader(text: String) {
    Text(text, Modifier.padding(start = 16.dp, top = 14.dp, bottom = 4.dp), color = Color(0xFF9A9A9A), fontSize = 14.sp)
}

private fun trackLabel(f: androidx.media3.common.Format, n: Int): String {
    val lang = f.language?.takeIf { it.isNotBlank() && it != "und" }?.let { java.util.Locale(it).displayLanguage }
    val ch = when (f.channelCount) { 1 -> "mono"; 2 -> "stereo"; 6 -> "5.1"; 8 -> "7.1"; else -> null }
    return listOfNotNull(f.label ?: lang ?: "Track $n", ch).joinToString(" · ")
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(req: PlayReq, repo: Repo, store: Store, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val act = ctx as ComponentActivity
    val scope = rememberCoroutineScope()

    var ep by remember { mutableStateOf(req.start) }
    var exo by remember { mutableStateOf<ExoPlayer?>(null) }
    var playing by remember { mutableStateOf(true) }
    var buffering by remember { mutableStateOf(true) }
    var pos by remember { mutableStateOf(0L) }
    var dur by remember { mutableStateOf(0L) }
    var scrub by remember { mutableStateOf<Float?>(null) }
    var controls by remember { mutableStateOf(true) }
    var touch by remember { mutableStateOf(0L) }
    var panel by remember { mutableStateOf<String?>(null) }     // cc | speed | audio | eps
    var resize by remember { mutableStateOf(0) }                // 0 fit, 1 fill, 2 zoom
    var speed by remember { mutableStateOf(1f) }
    var muted by remember { mutableStateOf(false) }
    var hud by remember { mutableStateOf<String?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var tracksVersion by remember { mutableStateOf(0) }
    val cur = remember { arrayOfNulls<Stream>(1) }
    val usedCompat = remember { booleanArrayOf(false) }

    BackHandler(onBack = onClose)
    BackHandler(enabled = panel != null) { panel = null }
    LaunchedEffect(hud) { if (hud != null) { delay(1100); hud = null } }

    // landscape, no system bars
    DisposableEffect(Unit) {
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val c = WindowCompat.getInsetsController(act.window, act.window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        onDispose {
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            c.show(WindowInsetsCompat.Type.systemBars())
            val lp = act.window.attributes; lp.screenBrightness = android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE; act.window.attributes = lp
        }
    }

    fun label(e: Episode?) = if (e == null) req.title.name else "${req.title.name} S%02dE%02d".format(e.season, e.number)

    fun loadEp(p: ExoPlayer, e: Episode?, compat: Boolean = false, at: Long = -1L) {
        scope.launch {
            err = null; buffering = true
            try {
                val s = if (compat && cur[0] != null) cur[0]!! else repo.stream(req.title, e)
                cur[0] = s
                val cfgs = s.subs.map { t ->
                    val b = MediaItem.SubtitleConfiguration.Builder(Uri.parse(t.url)).setMimeType(t.mime).setLabel(t.label)
                    if (t.lang != null) b.setLanguage(t.lang)
                    b.build()
                }
                val uri = if (compat) (s.compatUrl ?: s.url) else s.url
                val resume = if (at >= 0) at else store.resumePosition(e?.id ?: req.title.key)
                if (resume > 0 && at < 0) Toast.makeText(ctx, "Resuming from ${fmtTime(resume)}", Toast.LENGTH_SHORT).show()
                p.setMediaItem(MediaItem.Builder().setUri(uri).setSubtitleConfigurations(cfgs).build(), resume)
                p.prepare(); p.playWhenReady = true
            } catch (ex: Exception) { err = ex.message ?: "Could not start playback" }
        }
    }

    fun saveNow() {
        val p = exo ?: return
        store.saveProgress(req.title.key, ep?.id, label(ep), p.currentPosition, p.duration.coerceAtLeast(0))
    }

    fun switchEp(e: Episode) {
        val p = exo ?: return
        saveNow(); ep = e; usedCompat[0] = false; panel = null
        loadEp(p, e)
    }

    fun nextOf(): Episode? {
        val e = ep ?: return null
        val i = req.eps.indexOfFirst { it.id == e.id }
        return if (i >= 0 && i + 1 < req.eps.size) req.eps[i + 1] else null
    }
    val nextEpisode = nextOf()

    // create the player
    LaunchedEffect(Unit) {
        val p = ExoPlayer.Builder(ctx).setRenderersFactory(NextRenderersFactory(ctx)).build()
        val lang = store.subLang
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().apply {
            if (lang.isNotBlank()) { setPreferredTextLanguage(lang); setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false) }
            else setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        }.build()
        p.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_ENDED) { val n = nextOf(); if (n != null) switchEp(n) else onClose() }
            }
            override fun onTracksChanged(tracks: Tracks) { tracksVersion++ }
            override fun onPlayerError(error: PlaybackException) {
                if (!usedCompat[0] && cur[0]?.compatUrl != null) {
                    usedCompat[0] = true
                    Toast.makeText(ctx, "Converting on the server for this phone…", Toast.LENGTH_SHORT).show()
                    loadEp(p, ep, compat = true, at = p.currentPosition)
                } else err = error.message ?: "Playback error"
            }
        })
        loadEp(p, ep)
        exo = p
    }

    // position, progress saving, auto-hide of the controls
    LaunchedEffect(exo) {
        val p = exo ?: return@LaunchedEffect
        var n = 0
        while (true) {
            pos = p.currentPosition; dur = p.duration.coerceAtLeast(0)
            if (++n % 10 == 0) saveNow()
            delay(500)
        }
    }
    LaunchedEffect(controls, touch, playing, panel) {
        if (controls && playing && panel == null) { delay(3500); controls = false }
    }
    DisposableEffect(exo) {
        val p = exo
        val obs = androidx.lifecycle.LifecycleEventObserver { _, ev -> if (ev == androidx.lifecycle.Lifecycle.Event.ON_PAUSE) p?.pause() }
        act.lifecycle.addObserver(obs)
        onDispose {
            act.lifecycle.removeObserver(obs)
            if (p != null) {
                store.saveProgress(req.title.key, ep?.id, label(ep), p.currentPosition, p.duration.coerceAtLeast(0))
                p.release()
            }
        }
    }

    val p = exo
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (p != null) AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    this.player = p
                    useController = false
                    keepScreenOn = true
                    setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                }
            },
            update = { v -> v.resizeMode = when (resize) { 1 -> 3; 2 -> 4; else -> 0 } },
            modifier = Modifier.fillMaxSize()
        )

        // ---- touch layer: tap = controls, double tap = ±10 s, swipe = seek / brightness / volume
        Box(
            Modifier.fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { if (panel != null) panel = null else { controls = !controls; touch = System.currentTimeMillis() } },
                        onDoubleTap = { off ->
                            val pl = exo
                            if (pl != null) {
                                val left = off.x < size.width / 2f
                                val d = pl.duration
                                val t = (pl.currentPosition + if (left) -10_000L else 10_000L).let { if (d > 0) it.coerceIn(0L, d) else it.coerceAtLeast(0L) }
                                pl.seekTo(t)
                                hud = if (left) "⏪ 10 s" else "10 s ⏩"
                            }
                        }
                    )
                }
                .pointerInput(Unit) {
                    val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                    var mode = 0; var tx = 0f; var ty = 0f; var seekBy = 0L
                    var bright = act.window.attributes.screenBrightness.let { if (it < 0f) 0.5f else it }
                    var vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                    detectDragGestures(
                        onDragStart = { mode = 0; tx = 0f; ty = 0f; seekBy = 0L; vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() },
                        onDragEnd = {
                            val pl = exo
                            if (mode == 1 && seekBy != 0L && pl != null) {
                                val d = pl.duration
                                pl.seekTo((pl.currentPosition + seekBy).let { if (d > 0) it.coerceIn(0L, d) else it.coerceAtLeast(0L) })
                            }
                            mode = 0; seekBy = 0L
                        },
                        onDragCancel = { mode = 0; seekBy = 0L },
                        onDrag = { change, drag ->
                            change.consume()
                            tx += drag.x; ty += drag.y
                            if (mode == 0 && (abs(tx) > 24f || abs(ty) > 24f)) {
                                mode = if (abs(tx) > abs(ty)) 1 else if (change.position.x < size.width / 2f) 2 else 3
                            }
                            when (mode) {
                                1 -> {
                                    seekBy += (drag.x * 90_000f / size.width).toLong()
                                    val target = ((exo?.currentPosition ?: 0L) + seekBy).coerceAtLeast(0L)
                                    hud = (if (seekBy >= 0) "+" else "−") + fmtTime(abs(seekBy)) + "  →  " + fmtTime(target)
                                }
                                2 -> {
                                    bright = (bright - drag.y / size.height * 1.3f).coerceIn(0.02f, 1f)
                                    val lp = act.window.attributes; lp.screenBrightness = bright; act.window.attributes = lp
                                    hud = "☀ Brightness ${(bright * 100).toInt()}%"
                                }
                                3 -> {
                                    vol = (vol - drag.y / size.height * maxVol * 1.3f).coerceIn(0f, maxVol.toFloat())
                                    am.setStreamVolume(AudioManager.STREAM_MUSIC, vol.toInt(), 0)
                                    hud = "🔊 Volume ${(vol / maxVol * 100).toInt()}%"
                                }
                            }
                        }
                    )
                }
        )

        // ---- centre: -10 | play/pause or spinner | +10
        if (controls && panel == null) {
            Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(56.dp)) {
                Seek10(false) { exo?.let { it.seekTo((it.currentPosition - 10_000L).coerceAtLeast(0L)); touch = System.currentTimeMillis() } }
                Box(Modifier.size(76.dp).clickable { exo?.let { if (it.isPlaying) it.pause() else it.play() }; touch = System.currentTimeMillis() }, contentAlignment = Alignment.Center) {
                    if (buffering) CircularProgressIndicator(color = RED, strokeWidth = 4.dp, modifier = Modifier.size(64.dp))
                    else if (playing) PauseIcon(54.dp) else PlayIcon(60.dp)
                }
                Seek10(true) { exo?.let { val d = it.duration; it.seekTo((it.currentPosition + 10_000L).let { t -> if (d > 0) t.coerceAtMost(d) else t }); touch = System.currentTimeMillis() } }
            }
        } else if (buffering && panel == null) {
            CircularProgressIndicator(color = RED, strokeWidth = 4.dp, modifier = Modifier.align(Alignment.Center).size(56.dp))
        }

        // ---- top right: close
        if (controls && panel == null) {
            Box(
                Modifier.align(Alignment.TopEnd).padding(18.dp).size(48.dp).clickable(onClick = onClose),
                contentAlignment = Alignment.Center
            ) { Text("✕", color = Color.White, fontSize = 30.sp) }
        }

        // ---- floating settings button (right side)
        if (controls && panel == null) {
            Box(
                Modifier.align(Alignment.CenterEnd).padding(end = 22.dp).size(64.dp).background(Color(0xAA2B2B2B), CircleShape)
                    .clickable { panel = "speed" },
                contentAlignment = Alignment.Center
            ) { Text("⚙", color = Color.White, fontSize = 30.sp) }
        }

        // ---- bottom bar
        if (controls && panel == null) {
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000))))
                    .padding(horizontal = 14.dp)
            ) {
                val total = dur.coerceAtLeast(1L)
                Slider(
                    value = (scrub ?: (pos.toFloat() / total)).coerceIn(0f, 1f),
                    onValueChange = { scrub = it; touch = System.currentTimeMillis() },
                    onValueChangeFinished = { scrub?.let { v -> exo?.seekTo((v * total).toLong()) }; scrub = null },
                    colors = SliderDefaults.colors(
                        thumbColor = RED, activeTrackColor = RED, inactiveTrackColor = Color(0x66FFFFFF)
                    ),
                    modifier = Modifier.fillMaxWidth().height(28.dp)
                )
                Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    BarButton({ exo?.let { if (it.isPlaying) it.pause() else it.play() }; touch = System.currentTimeMillis() }) {
                        if (playing) PauseIcon(30.dp) else PlayIcon(30.dp)
                    }
                    BarButton({ muted = !muted; exo?.volume = if (muted) 0f else 1f }) { Text(if (muted) "🔇" else "🔊", fontSize = 22.sp) }
                    Text(
                        fmtTime(scrub?.let { (it * total).toLong() } ?: pos) + "  /  " + fmtTime(dur),
                        Modifier.padding(horizontal = 8.dp), color = Color.White, fontSize = 16.sp, maxLines = 1
                    )
                    Spacer(Modifier.width(6.dp))
                    val e = ep
                    if (e != null) Box(
                        Modifier.background(Color.White, RoundedCornerShape(8.dp)).padding(horizontal = 14.dp, vertical = 6.dp)
                    ) { Text("S${e.season} · E${e.number}", color = Color.Black, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
                    Text(
                        buildAnnotatedString {
                            append(req.title.name)
                            if (e != null) { append(" – "); withStyle(SpanStyle(color = GREEN)) { append(e.name) } }
                        },
                        Modifier.weight(1f).padding(horizontal = 12.dp), color = Color.White, fontSize = 18.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    if (req.eps.isNotEmpty()) BarButton({ panel = "eps" }) { Text("☰", color = Color.White, fontSize = 24.sp) }
                    if (nextEpisode != null) BarButton({ switchEp(nextEpisode) }) { Text("⏭", color = Color.White, fontSize = 24.sp) }
                    BarButton({ panel = "cc" }) {
                        Box(Modifier.border(2.dp, Color.White, RoundedCornerShape(4.dp)).padding(horizontal = 4.dp, vertical = 1.dp)) {
                            Text("CC", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    BarButton({ panel = "speed" }) { Text("⚙", color = Color.White, fontSize = 26.sp) }
                    BarButton({ resize = (resize + 1) % 3; hud = listOf("Fit", "Fill", "Zoom")[resize] }) { Text("⛶", color = Color.White, fontSize = 26.sp) }
                }
            }
        }

        // ---- short messages
        hud?.let {
            Box(
                Modifier.align(Alignment.TopCenter).padding(top = 40.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(24.dp)).padding(horizontal = 20.dp, vertical = 10.dp)
            ) { Text(it, color = Color.White, fontSize = 18.sp) }
        }

        // ---- side panel with tabs
        panel?.let { tab ->
            @Suppress("UNUSED_VARIABLE") val tv = tracksVersion
            val tracks = p?.currentTracks?.groups.orEmpty()
            val texts = tracks.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported() }
            val audios = tracks.filter { it.type == C.TRACK_TYPE_AUDIO && it.isSupported() }
            val textOn = p?.trackSelectionParameters?.disabledTrackTypes?.contains(C.TRACK_TYPE_TEXT) == false
            Column(
                Modifier.align(Alignment.TopEnd).fillMaxHeight(0.92f).fillMaxWidth(0.52f).widthIn(min = 320.dp)
                    .background(PANEL)
            ) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    val tabs = listOf("cc" to "CC", "speed" to "⏱", "audio" to "🎧") + (if (req.eps.isNotEmpty()) listOf("eps" to "☰") else emptyList())
                    tabs.forEach { (id, icon) ->
                        Column(Modifier.clickable { panel = id }.padding(horizontal = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(icon, color = Color.White, fontSize = 24.sp, modifier = Modifier.padding(vertical = 6.dp))
                            Box(Modifier.width(44.dp).height(3.dp).background(if (tab == id) Color.White else Color.Transparent))
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Box(Modifier.size(44.dp).clickable { panel = null }, contentAlignment = Alignment.Center) { Text("✕", color = Color.White, fontSize = 26.sp) }
                }
                LazyColumn(Modifier.fillMaxWidth()) {
                    when (tab) {
                        "cc" -> {
                            item { PanelRow("Off", !textOn) {
                                p?.trackSelectionParameters = p!!.trackSelectionParameters.buildUpon()
                                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                                store.subLang = ""
                            } }
                            itemsIndexed(texts) { n, g ->
                                PanelRow("${n + 1}. " + trackLabel(g.getTrackFormat(0), n + 1), textOn && g.isSelected) {
                                    p?.trackSelectionParameters = p!!.trackSelectionParameters.buildUpon()
                                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
                                    store.subLang = g.getTrackFormat(0).language ?: ""
                                }
                            }
                            if (texts.isEmpty()) item { Text("No subtitles in this video.", Modifier.padding(16.dp), color = Color(0xFF9A9A9A)) }
                        }
                        "speed" -> {
                            item { PanelHeader("Playback speed") }
                            itemsIndexed(listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)) { _, s ->
                                PanelRow(if (s == 1f) "Normal" else "${s}×", speed == s) { speed = s; p?.setPlaybackSpeed(s) }
                            }
                            item { PanelHeader("Picture size") }
                            itemsIndexed(listOf("Fit", "Fill (stretch)", "Zoom (crop)")) { i, n -> PanelRow(n, resize == i) { resize = i } }
                        }
                        "audio" -> {
                            itemsIndexed(audios) { n, g ->
                                PanelRow("${n + 1}. " + trackLabel(g.getTrackFormat(0), n + 1), g.isSelected) {
                                    p?.trackSelectionParameters = p!!.trackSelectionParameters.buildUpon()
                                        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
                                }
                            }
                            if (audios.isEmpty()) item { Text("No playable audio track.", Modifier.padding(16.dp), color = Color(0xFF9A9A9A)) }
                        }
                        else -> {
                            val e0 = ep
                            val list = req.eps.filter { e0 == null || it.season == e0.season }
                            item { PanelHeader(if (e0 != null) "Season ${e0.season}" else "Episodes") }
                            itemsIndexed(list) { _, e -> PanelRow("${e.number}. ${e.name}", e.id == e0?.id) { switchEp(e) } }
                        }
                    }
                }
            }
        }

        // ---- error
        err?.let { msg ->
            Column(
                Modifier.align(Alignment.Center).padding(24.dp).background(Color(0xE6101014), RoundedCornerShape(16.dp)).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("This video can't be played", color = Color.White, fontSize = 18.sp)
                Text(msg, color = Color(0xFFB0B0B8), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp), maxLines = 3, overflow = TextOverflow.Ellipsis)
                Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { exo?.let { pl -> usedCompat[0] = false; loadEp(pl, ep, at = pl.currentPosition) } }) { Text("Try again") }
                    OutlinedButton(onClick = onClose) { Text("Go back") }
                }
            }
        }
    }
}
