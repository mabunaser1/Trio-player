package com.example.trio

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val BG = Color(0xFF0A0A0A)
val RED_ = Color(0xFFE50914)

// ------------------------------------------------------------------ login

@Composable
fun LoginScreen(repo: Repo, onDone: () -> Unit) {
    val store = repo.store
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf(store.embyUrl) }
    var user by remember { mutableStateOf(store.embyUser) }
    var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Trio Player", style = MaterialTheme.typography.headlineLarge, color = RED_, fontWeight = FontWeight.Bold)
        Text("Sign in to the FuntimeBD server", Modifier.padding(top = 4.dp, bottom = 20.dp), color = Color(0xFFB0B0B8))
        OutlinedTextField(
            url, { url = it }, singleLine = true, label = { Text("Server address") }, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
        )
        OutlinedTextField(user, { user = it }, singleLine = true, label = { Text("Username") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        OutlinedTextField(
            pass, { pass = it }, singleLine = true, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
        error?.let { Text(it, Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.error) }
        Button(
            onClick = {
                busy = true; error = null
                scope.launch {
                    val e = repo.emby.login(url, user.trim(), pass)
                    busy = false
                    if (e == null) onDone() else error = e
                }
            },
            enabled = !busy && user.isNotBlank(), modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
        ) { Text(if (busy) "Signing in…" else "Sign in") }
        Text("The password stays on this phone only. Connect to the BDIX wifi first.", Modifier.padding(top = 12.dp), color = Color(0xFF8A8A92), fontSize = 12.sp)
    }
}

// ------------------------------------------------------------------ cards and rows

@Composable
fun PosterCard(t: Title, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick)) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (t.poster != null) AsyncImage(model = t.poster, contentDescription = t.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            else Text(t.name, Modifier.padding(8.dp), style = MaterialTheme.typography.labelMedium, maxLines = 4, textAlign = TextAlign.Center)
            if (t.rating > 0) Text(
                "★ %.1f".format(t.rating),
                Modifier.align(Alignment.TopEnd).padding(4.dp).background(Color(0xAA000000), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp),
                style = MaterialTheme.typography.labelSmall
            )
        }
        Text(t.name, Modifier.padding(top = 4.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium)
        Text(
            listOfNotNull(t.year?.toString(), if (t.series) "Series" else null).joinToString(" · "),
            color = Color(0xFF8A8A92), style = MaterialTheme.typography.labelSmall, maxLines = 1
        )
    }
}

@Composable
fun PosterRow(title: String, list: List<Title>, onOpen: (Title) -> Unit) {
    if (list.isEmpty()) return
    Column(Modifier.padding(top = 16.dp)) {
        Text(title, Modifier.padding(horizontal = 16.dp, vertical = 6.dp), style = MaterialTheme.typography.titleMedium)
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.key }) { t -> PosterCard(t, Modifier.width(112.dp)) { onOpen(t) } }
        }
    }
}

// ------------------------------------------------------------------ home

@Composable
fun HomeScreen(repo: Repo, hist: List<Hist>, myList: List<String>, onOpen: (Title) -> Unit, onResume: (Hist, Title) -> Unit) {
    val titles = repo.titles
    val year = remember { java.util.Calendar.getInstance().get(java.util.Calendar.YEAR) }
    val rows = remember(titles) {
        val out = ArrayList<Pair<String, List<Title>>>()
        out.add("Recently added" to titles.sortedByDescending { it.added }.take(40))
        out.add("Latest releases" to titles.filter { (it.year ?: 0) >= year - 1 }.sortedWith(compareByDescending<Title> { it.year ?: 0 }.thenByDescending { it.rating }).take(40))
        out.add("Top rated" to titles.filter { it.rating >= 7.0 }.sortedByDescending { it.rating }.take(40))
        out.add("Movies" to titles.filter { !it.series }.sortedBy { it.key.hashCode() }.take(40))
        out.add("Series" to titles.filter { it.series }.sortedByDescending { it.added }.take(40))
        titles.flatMap { t -> t.genres.map { g -> g to t } }.groupBy({ it.first }, { it.second })
            .entries.sortedByDescending { it.value.size }.take(14)
            .forEach { out.add(it.key to it.value.sortedByDescending { t -> t.added }.take(40)) }
        out.filter { it.second.size >= 3 }
    }
    val cont = remember(hist, titles) {
        hist.filter { it.pos > 10_000 && !it.finished }
            .mapNotNull { h -> repo.byKey[h.titleKey]?.let { h to it } }.distinctBy { it.second.key }.take(15)
    }
    val mine = remember(myList, titles) { myList.mapNotNull { repo.byKey[it] } }
    val hero = remember(titles) { titles.firstOrNull { it.backdrop != null } }

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(Modifier.padding(start = 16.dp, end = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Trio Player", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, color = RED_)
            }
        }
        if (repo.refreshing) item {
            Text("Updating the library… ${repo.progress}", Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium)
        }
        if (titles.isEmpty() && !repo.refreshing) item {
            Text(
                if (repo.lastError.isNotBlank()) "Could not load the library: ${repo.lastError}\nCheck that you are on the BDIX wifi, then open the Sources tab and tap Update now."
                else "Your library is empty. Open the Sources tab and tap Update now.",
                Modifier.padding(16.dp)
            )
        }
        if (hero != null) item {
            Box(Modifier.fillMaxWidth().height(340.dp).background(MaterialTheme.colorScheme.surfaceVariant).clickable { onOpen(hero) }) {
                AsyncImage(model = hero.backdrop, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, BG))))
                Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                    Text(hero.name, style = MaterialTheme.typography.headlineMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Button(onClick = { onOpen(hero) }, modifier = Modifier.padding(top = 8.dp)) { Text("▶ Play") }
                }
            }
        }
        if (cont.isNotEmpty()) item {
            Column(Modifier.padding(top = 16.dp)) {
                Text("Continue watching", Modifier.padding(horizontal = 16.dp, vertical = 6.dp), style = MaterialTheme.typography.titleMedium)
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(cont, key = { it.first.key }) { (h, t) -> PosterCard(t, Modifier.width(112.dp)) { onResume(h, t) } }
                }
            }
        }
        if (mine.isNotEmpty()) item { PosterRow("My List", mine, onOpen) }
        items(rows.size) { i -> PosterRow(rows[i].first, rows[i].second, onOpen) }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

// ------------------------------------------------------------------ search: saved catalog first, then the server's own search

@Composable
fun SearchScreen(repo: Repo, onOpen: (Title) -> Unit) {
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Title>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(q) {
        val s = q.trim()
        if (s.length < 2) { results = emptyList(); busy = false; return@LaunchedEffect }
        val local = repo.localSearch(s)
        results = local
        delay(350)
        busy = true
        val remote = repo.serverSearch(s)
        val have = local.map { it.key }.toSet()
        results = local + remote.filter { it.key !in have }
        busy = false
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            q, { q = it }, singleLine = true, label = { Text("Search every movie and series on the servers") },
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        )
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 12.dp))
        if (q.trim().length >= 2 && results.isEmpty() && !busy) Text("Nothing found on the servers.", Modifier.padding(16.dp))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(104.dp), contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(results, key = { it.key }) { t -> PosterCard(t) { onOpen(t) } }
        }
    }
}

// ------------------------------------------------------------------ sources

@Composable
fun SourcesScreen(repo: Repo, onUpdate: () -> Unit, onSignOut: () -> Unit) {
    val fmt = remember { java.text.SimpleDateFormat("d MMM yyyy, HH:mm", java.util.Locale.getDefault()) }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        item { Text("Sources", style = MaterialTheme.typography.titleLarge) }
        item {
            Text(
                "Last update: " + (if (repo.store.lastRefresh > 0) fmt.format(java.util.Date(repo.store.lastRefresh)) else "never") +
                    "\nThe library updates itself once a day.",
                Modifier.padding(vertical = 8.dp), style = MaterialTheme.typography.bodySmall
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onUpdate, enabled = !repo.refreshing) { Text(if (repo.refreshing) "Updating… ${repo.progress}" else "Update now") }
                OutlinedButton(onClick = onSignOut) { Text("Change account") }
            }
        }
        if (repo.lastError.isNotBlank()) item { Text("Last error: ${repo.lastError}", Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.error) }
        items(repo.sources, key = { it.id }) { s ->
            val n = repo.titles.count { it.source == s.id }
            ListItem(
                headlineContent = { Text(s.name) },
                supportingContent = { Text(s.home.substringAfter("//") + "  ·  " + if (s.ready) "$n titles" else "not connected yet") }
            )
        }
    }
}

// ------------------------------------------------------------------ title page (movie, or series with a season drop-down)

@Composable
fun DetailScreen(
    t: Title, repo: Repo, hist: List<Hist>, inList: Boolean,
    onToggleList: () -> Unit, onPlay: (PlayReq) -> Unit, onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    var eps by remember(t.key) { mutableStateOf<List<Episode>>(emptyList()) }
    var loading by remember(t.key) { mutableStateOf(t.series) }
    var loadErr by remember(t.key) { mutableStateOf<String?>(null) }
    var season by remember(t.key) { mutableStateOf<Int?>(null) }
    var showSeasons by remember { mutableStateOf(false) }

    LaunchedEffect(t.key) {
        if (!t.series) return@LaunchedEffect
        try { eps = repo.episodes(t) } catch (e: Exception) { loadErr = e.message ?: "Could not load episodes" }
        loading = false
    }
    val bySeason = remember(eps) { eps.groupBy { it.season }.toSortedMap() }
    val last = remember(hist, t.key) { hist.firstOrNull { it.titleKey == t.key && it.epId != null && !it.finished } }
    val curSeason = season ?: last?.let { h -> eps.firstOrNull { it.id == h.epId }?.season } ?: bySeason.keys.firstOrNull { it > 0 } ?: bySeason.keys.firstOrNull()
    val resumeEp = last?.let { h -> eps.firstOrNull { it.id == h.epId } } ?: eps.firstOrNull { it.season > 0 } ?: eps.firstOrNull()
    fun play(e: Episode?) = onPlay(PlayReq(t, eps, e))

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Box(Modifier.fillMaxWidth().height(260.dp).background(MaterialTheme.colorScheme.surfaceVariant)) {
                val art = t.backdrop ?: t.poster
                if (art != null) AsyncImage(model = art, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x66000000), Color.Transparent, BG))))
                TextButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).statusBarsPadding()) { Text("← Back") }
                Box(
                    Modifier.align(Alignment.Center).size(72.dp).border(3.dp, RED_, CircleShape).background(Color(0x55000000), CircleShape)
                        .clickable { if (t.series) play(resumeEp) else play(null) },
                    contentAlignment = Alignment.Center
                ) { Text("▶", color = Color.White, fontSize = 30.sp) }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text(t.name, style = MaterialTheme.typography.headlineSmall)
                val meta = listOfNotNull(
                    t.year?.toString(), t.rating.takeIf { it > 0 }?.let { "★ %.1f".format(it) },
                    t.runtimeMin.takeIf { it > 0 && !t.series }?.let { "${it}m" },
                    if (t.series && bySeason.isNotEmpty()) "${bySeason.keys.count { it > 0 }.coerceAtLeast(1)} season(s)" else null,
                    t.genres.take(3).joinToString(", ").ifBlank { null }
                ).joinToString("  ·  ")
                Text(meta, Modifier.padding(top = 4.dp), style = MaterialTheme.typography.labelMedium, color = Color(0xFFB0B0B8))
                Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { if (t.series) play(resumeEp) else play(null) }, enabled = !t.series || resumeEp != null,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            if (last != null) "▶ Resume" + (resumeEp?.let { "  S${it.season} E${it.number}" } ?: "")
                            else if (!t.series && hist.any { it.key == t.key && !it.finished }) "▶ Resume" else "▶ Play"
                        )
                    }
                    OutlinedButton(onClick = onToggleList) { Text(if (inList) "✓ My List" else "+ My List") }
                }
                if (t.overview.isNotBlank()) Text(t.overview, Modifier.padding(top = 12.dp), style = MaterialTheme.typography.bodyMedium)
            }
        }
        if (t.series) {
            if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth().padding(16.dp)) }
            loadErr?.let { m -> item { Text(m, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error) } }
            if (bySeason.isNotEmpty() && curSeason != null) {
                item {
                    val n = bySeason[curSeason]?.size ?: 0
                    Box(
                        Modifier.padding(16.dp).background(Color(0xFF1F1F23), RoundedCornerShape(8.dp)).border(1.dp, Color(0x55E50914), RoundedCornerShape(8.dp))
                            .clickable { showSeasons = true }.padding(horizontal = 16.dp, vertical = 12.dp)
                    ) { Text("${seasonName(curSeason)} ($n EP)   ⌄", fontSize = 17.sp) }
                }
                val list = bySeason[curSeason].orEmpty()
                items(list, key = { it.id }) { e ->
                    val h = hist.firstOrNull { it.epId == e.id }
                    Row(
                        Modifier.fillMaxWidth().clickable { play(e) }.padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(Modifier.width(150.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                            if (e.thumb != null) AsyncImage(model = e.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            Box(Modifier.align(Alignment.Center).size(36.dp).border(2.dp, Color.White, CircleShape).background(Color(0x66000000), CircleShape), contentAlignment = Alignment.Center) {
                                Text("▶", color = Color.White, fontSize = 14.sp)
                            }
                            if (h != null && h.dur > 0) LinearProgressIndicator(
                                progress = { (h.pos.toFloat() / h.dur).coerceIn(0f, 1f) }, color = RED_, trackColor = Color(0x66FFFFFF),
                                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                            )
                        }
                        Column(Modifier.weight(1f)) {
                            Text("${e.number}. ${e.name}", maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
                            Text(
                                listOfNotNull("E${e.number}", "S${e.season}", e.runtimeMin.takeIf { it > 0 }?.let { "${it}m" }).joinToString("  ·  "),
                                color = Color(0xFF8A8A92), style = MaterialTheme.typography.labelMedium
                            )
                            if (e.overview.isNotBlank()) Text(e.overview, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = Color(0xFFB0B0B8))
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(32.dp)) }
    }

    if (showSeasons) {
        AlertDialog(
            onDismissRequest = { showSeasons = false },
            containerColor = Color.White, shape = RoundedCornerShape(4.dp),
            confirmButton = {},
            text = {
                LazyColumn {
                    items(bySeason.keys.toList()) { s ->
                        Row(
                            Modifier.fillMaxWidth().clickable { season = s; showSeasons = false }.padding(vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${seasonName(s)} (${bySeason[s]?.size ?: 0} EP)", Modifier.weight(1f), color = Color(0xFF202020), fontSize = 20.sp)
                            RadioButton(selected = s == curSeason, onClick = { season = s; showSeasons = false })
                        }
                        HorizontalDivider(color = Color(0xFFE0E0E0))
                    }
                }
            }
        )
    }
}

fun seasonName(s: Int) = if (s == 0) "Specials" else "Season $s"
