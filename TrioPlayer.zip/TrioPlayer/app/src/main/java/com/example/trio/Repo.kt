package com.example.trio

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Holds the catalog of all connected sources and refreshes it once a day. */
class Repo(private val ctx: Context, val store: Store) {
    val emby = EmbySource(store)
    val sources: List<Source> = listOf(
        emby,
        PendingSource("sunplex", "Sunplex", "https://sunplex.net"),
        PendingSource("ctgmovies", "CTGMovies", "https://ctgmovies.com")
    )

    var titles by mutableStateOf<List<Title>>(emptyList())
    var byKey by mutableStateOf<Map<String, Title>>(emptyMap())
    var refreshing by mutableStateOf(false)
    var progress by mutableStateOf("")
    var lastError by mutableStateOf("")

    private fun set(list: List<Title>) { titles = list; byKey = list.associateBy { it.key } }

    fun loadCache() { if (titles.isEmpty()) set(store.loadCatalog()) }

    val isStale get() = System.currentTimeMillis() - store.lastRefresh > 24 * 3600_000L

    /** Downloads the whole catalog again. Normally called at most once a day. */
    suspend fun refresh(force: Boolean = false): Boolean {
        if (refreshing) return true
        if (!force && !isStale && titles.isNotEmpty()) return true
        refreshing = true; lastError = ""
        return try {
            val all = ArrayList<Title>()
            for (s in sources.filter { it.ready }) {
                all.addAll(s.catalog { n, total -> progress = "${s.name}: $n / $total" })
            }
            if (all.isNotEmpty()) { set(all.sortedByDescending { it.added }); store.saveCatalog(titles) }
            store.lastRefresh = System.currentTimeMillis()
            true
        } catch (e: Exception) {
            lastError = e.message ?: "Update failed"; false
        } finally { refreshing = false; progress = "" }
    }

    /** Instant results from the saved catalog, then everything the servers' own search finds. */
    fun localSearch(q: String): List<Title> {
        val toks = q.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (toks.isEmpty()) return emptyList()
        val nq = q.lowercase().filter { it.isLetterOrDigit() }
        return titles.filter { t ->
            val n = t.name.lowercase()
            toks.all { n.contains(it) } || (nq.length >= 3 && n.filter { it.isLetterOrDigit() }.contains(nq))
        }.sortedWith(compareBy({ !it.name.lowercase().startsWith(toks[0]) }, { it.name.lowercase() }))
    }

    suspend fun serverSearch(q: String): List<Title> =
        sources.filter { it.ready }.flatMap { try { it.search(q) } catch (e: Exception) { emptyList() } }

    private fun sourceOf(t: Title) = sources.first { it.id == t.source }
    suspend fun episodes(t: Title) = sourceOf(t).episodes(t)
    suspend fun stream(t: Title, ep: Episode?) = sourceOf(t).stream(t, ep)

    companion object {
        /** Asks Android to refresh the catalog once a day in the background, on unmetered (home/BDIX wifi) networks. */
        fun scheduleDaily(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<CatalogWorker>(24, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.UNMETERED).build()).build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("catalog-daily", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}

class CatalogWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        val store = Store(applicationContext)
        if (!store.loggedIn) return Result.success()
        val repo = Repo(applicationContext, store)
        return if (repo.refresh(force = true)) Result.success() else Result.retry()
    }
}
