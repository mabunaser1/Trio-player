package com.example.trio

import androidx.compose.runtime.Immutable

/** One movie or one series (a series is ONE entry, its seasons and episodes are loaded on its page). */
@Immutable
data class Title(
    val key: String,           // "<source>:<id>"
    val source: String, val id: String, val name: String, val year: Int?, val series: Boolean,
    val overview: String, val rating: Double, val genres: List<String>,
    val poster: String?, val backdrop: String?, val added: Long, val runtimeMin: Int
) {
    // computed once per title, so searching 20,000 titles does not re-process every name on every key press
    val lc: String = name.lowercase()
    val nn: String = lc.filter { it.isLetterOrDigit() }
    // formatted once, not on every scroll frame
    val ratingText: String = if (rating > 0) "★ %.1f".format(rating) else ""
    val yearText: String = year?.toString() ?: ""
}

data class Episode(
    val id: String, val name: String, val season: Int, val number: Int,
    val runtimeMin: Int, val thumb: String?, val overview: String
)

data class SubTrack(val label: String, val url: String, val lang: String?, val mime: String)

/** What the player needs to start one movie or episode. */
class Stream(
    val url: String, val subs: List<SubTrack>,
    val bitrate: Long, val height: Int, val codec: String,
    /** index of the English audio track on the server, -1 when there is none (used for converted streams) */
    val engAudio: Int = -1,
    /** file type of the original (mkv, mp4 ...), used to name a download */
    val container: String = "",
    /** address of a server-converted H.264/AAC version: (max height, video kbit/s) -> url */
    val transcode: (Int, Int) -> String
)

/** A server the app can read. Emby/Jellyfin is implemented; the two web sites plug in here once their link format is known. */
interface Source {
    val id: String
    val name: String
    val home: String
    val ready: Boolean
    suspend fun catalog(onProgress: (Int, Int) -> Unit): List<Title>
    suspend fun search(q: String): List<Title>
    suspend fun episodes(t: Title): List<Episode>
    suspend fun stream(t: Title, ep: Episode?): Stream
    /** the long description, loaded when a title page opens (the catalog does not carry it, which keeps updates small and fast) */
    suspend fun details(t: Title): String = t.overview
    /** the server's own "recently added" lists (movies, series); servers without such a list return nothing */
    suspend fun latest(): Pair<List<Title>, List<Title>> = emptyList<Title>() to emptyList()
}

/** Placeholder for a site whose way of serving videos is not wired in yet. */
class PendingSource(override val id: String, override val name: String, override val home: String) : Source {
    override val ready = false
    override suspend fun catalog(onProgress: (Int, Int) -> Unit): List<Title> = emptyList()
    override suspend fun search(q: String): List<Title> = emptyList()
    override suspend fun episodes(t: Title): List<Episode> = emptyList()
    override suspend fun stream(t: Title, ep: Episode?): Stream = throw UnsupportedOperationException("$name is not connected yet")
}

/** headers: what a website's own player sent (Referer, Cookie ...), needed by streams that refuse requests from anywhere else */
/** one quality of a file found on a website page: label like "1080p", height 1080, and its address */
data class Variant(val label: String, val height: Int, val url: String)

/** an episode or quality button read from a website's own page */
class WebItem(val text: String, val cur: Boolean)

/** lets the player drive the website it was started from (next episode, quality) */
interface PlayCtl {
    suspend fun items(): Pair<List<WebItem>, List<WebItem>>
    /** kind "ep" or "q": clicks it on the page, waits for the new video and returns it (null = nothing new came) */
    suspend fun choose(kind: String, idx: Int): Sniffed?
}

data class PlayReq(
    val title: Title, val eps: List<Episode>, val start: Episode?, val headers: Map<String, String> = emptyMap(),
    val ctl: PlayCtl? = null,
    /** website playlists: episode id -> the qualities that page offers for it */
    val variants: Map<String, List<Variant>> = emptyMap()
)

fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}
