package com.example.trio

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.view.ViewGroup
import android.webkit.DownloadListener
import android.webkit.WebResourceResponse
import android.os.Message
import android.view.View
import org.json.JSONArray
import org.json.JSONTokener
import androidx.compose.material3.Switch
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private val VIDEO_EXT = setOf("mkv", "mp4", "avi", "m4v", "mov", "webm", "ts", "m2ts", "wmv", "flv", "mpg", "mpeg", "3gp", "m3u8")

fun isVideoUrl(u: String): Boolean {
    val p = u.substringBefore('?').substringBefore('#').lowercase()
    return VIDEO_EXT.any { p.endsWith(".$it") }
}

fun fileNameOf(u: String): String =
    Uri.decode(u.substringBefore('?').substringBefore('#').trimEnd('/').substringAfterLast('/')).ifBlank { "video" }

@Composable
fun DownloadIcon(tint: Color, dp: Dp) {
    Canvas(Modifier.size(dp)) {
        val w = this.size.width
        val h = this.size.height
        val sw = w * 0.1f
        drawLine(tint, Offset(w * 0.5f, h * 0.12f), Offset(w * 0.5f, h * 0.64f), sw, StrokeCap.Round)
        drawLine(tint, Offset(w * 0.28f, h * 0.44f), Offset(w * 0.5f, h * 0.66f), sw, StrokeCap.Round)
        drawLine(tint, Offset(w * 0.72f, h * 0.44f), Offset(w * 0.5f, h * 0.66f), sw, StrokeCap.Round)
        drawLine(tint, Offset(w * 0.2f, h * 0.86f), Offset(w * 0.8f, h * 0.86f), sw, StrokeCap.Round)
    }
}

/** Ad blocking: known ad / popup hosts are not even downloaded, and ad boxes are hidden on the page. */
object AdBlock {
    private val HOSTS = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "google-analytics.com", "googletagmanager.com",
        "adservice.google", "adsterra", "popads.net", "popcash.net", "propellerads", "propellerclick", "exoclick", "exosrv",
        "juicyads", "trafficjunky", "clickadu", "hilltopads", "adcash", "adnxs.com", "taboola.com", "outbrain.com",
        "mgid.com", "revcontent", "onclickads", "onclkds", "bidvertiser", "adsco.re", "a-ads.com", "ad-maven", "admaven",
        "pushwoosh", "richpush", "monetag", "profitablegate", "highperformanceformat", "highrevenuegate", "tsyndicate",
        "yllix", "ero-advertising", "adskeeper", "zeropark", "evadav", "popunder", "histats.com", "yandex.ru/ads", "amazon-adsystem"
    )
    fun isAd(url: String): Boolean {
        val host = try { Uri.parse(url).host?.lowercase() ?: return false } catch (e: Exception) { return false }
        val l = url.lowercase()
        return HOSTS.any { host.contains(it) || (it.contains('/') && l.contains(it)) }
    }
    /** run on every page: hides ad boxes, closes overlays, stops pop-up windows, gives the page an app feel */
    const val JS = """(function(){try{
if(window.__trio)return;window.__trio=1;
window.open=function(){return null};
var css='html,body{overscroll-behavior:none!important;-webkit-tap-highlight-color:transparent}'
+'::-webkit-scrollbar{display:none}'
+'ins.adsbygoogle,[id^="google_ads"],[id*="ad-container"],[class*="adsbox"],[class*="ad-banner"],[class*="advert"],[class*="popunder"],[id*="popunder"],iframe[src*="ads"],iframe[src*="doubleclick"],a[href*="adsterra"],a[href*="popads"],div[style*="z-index: 2147483647"]{display:none!important}'
+'body{-webkit-user-select:none;user-select:none}input,textarea{-webkit-user-select:text;user-select:text}';
var st=document.createElement('style');st.textContent=css;(document.head||document.documentElement).appendChild(st);
}catch(e){}})();"""
    const val LINKS = "(function(){try{return JSON.stringify(Array.prototype.map.call(document.querySelectorAll('a[href]'),function(a){return a.href}))}catch(e){return '[]'}})()"
}

/** One browser per open-site server, kept alive while you switch tabs so the page is still there when you come back. */
class WebHolder(val view: WebView) {
    var progress by mutableStateOf(0)
    var loading by mutableStateOf(false)
    var canBack by mutableStateOf(false)
    var canForward by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var adblock by mutableStateOf(true)
    var blocked by mutableStateOf(0)
    /** what the page's own requests would send, so protected folders still play */
    fun headersFor(u: String): Map<String, String> {
        val hd = LinkedHashMap<String, String>()
        view.url?.let { hd["Referer"] = it }
        val ck = try { android.webkit.CookieManager.getInstance().getCookie(u) } catch (e: Exception) { null }
        if (!ck.isNullOrBlank()) hd["Cookie"] = ck
        return hd
    }
    /** a video the person tapped: play it (the page's other videos become the playlist) */
    var onVideo: (String, List<String>) -> Unit = { _, _ -> }
    fun openVideo(u: String) {
        view.evaluateJavascript(AdBlock.LINKS) { r ->
            val list = try {
                val str = JSONTokener(r ?: "\"[]\"").nextValue() as? String ?: "[]"
                val a = JSONArray(str); (0 until a.length()).map { a.getString(it) }.filter { isVideoUrl(it) }
            } catch (e: Exception) { emptyList() }
            onVideo(u, list)
        }
    }
    /** (address, mime type) of a video or file the page wants to open */
    var onFile: (String, String) -> Unit = { _, _ -> }
    fun sync() { canBack = view.canGoBack(); canForward = view.canGoForward() }
}

@SuppressLint("SetJavaScriptEnabled")
fun createWeb(ctx: Context, url: String, adblock: Boolean = true): WebHolder {
    val wv = WebView(ctx)
    val h = WebHolder(wv)
    h.adblock = adblock
    wv.setBackgroundColor(android.graphics.Color.BLACK)
    wv.settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        useWideViewPort = true
        loadWithOverviewMode = true
        setSupportZoom(false)
        builtInZoomControls = false
        displayZoomControls = false
        mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        mediaPlaybackRequiresUserGesture = true
        allowFileAccess = false
        javaScriptCanOpenWindowsAutomatically = false
        setSupportMultipleWindows(true)
    }
    wv.isVerticalScrollBarEnabled = false
    wv.isHorizontalScrollBarEnabled = false
    wv.overScrollMode = View.OVER_SCROLL_NEVER
    wv.webViewClient = object : WebViewClient() {
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            if (h.adblock && AdBlock.isAd(request.url.toString())) {
                h.view.post { h.blocked++ }
                return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
            }
            return null
        }
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val u = request.url.toString()
            if (h.adblock && AdBlock.isAd(u)) return true
            if (isVideoUrl(u)) { h.openVideo(u); return true }       // a video file: Play / Download choice instead of a browser download
            return !u.startsWith("http", ignoreCase = true)            // block intent:, market:, tel: ... links
        }
        override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) { h.loading = true; h.error = null; h.sync() }
        override fun onPageFinished(view: WebView, url: String?) {
            h.loading = false; h.sync()
            if (h.adblock) view.evaluateJavascript(AdBlock.JS, null)
        }
        override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) { h.sync() }
        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (request.isForMainFrame) h.error = error.description?.toString() ?: "The page could not be loaded"
        }
    }
    wv.webChromeClient = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) { h.progress = newProgress }
        // pop-up windows (the usual ad trick) are never opened
        override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean = false
    }
    // a link the site sends as a file download: videos play straight away
    wv.setDownloadListener(DownloadListener { u, _, _, mime, _ ->
        if (isVideoUrl(u) || (mime ?: "").startsWith("video/")) h.openVideo(u) else h.onFile(u, mime ?: "")
    })
    // press and hold a link to a video
    wv.setOnLongClickListener { v ->
        val r = (v as WebView).hitTestResult
        val ex = r.extra
        if ((r.type == WebView.HitTestResult.SRC_ANCHOR_TYPE || r.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) && ex != null && isVideoUrl(ex)) {
            h.onFile(ex, ""); true
        } else false
    }
    wv.loadUrl(url)
    return h
}

/** The server's website inside the app: your own top bar, the site below it. Video files open a Play / Download choice. */
@Composable
fun WebSiteScreen(
    repo: Repo, holder: WebHolder, homeUrl: String,
    onSwitch: (String) -> Unit, onAdd: () -> Unit, onVideo: (String, List<String>) -> Unit, adOn: (Boolean) -> Unit, onFile: (String, String) -> Unit
) {
    holder.onFile = onFile
    holder.onVideo = onVideo
    // a hidden page stops running (battery)
    DisposableEffect(holder) { holder.view.onResume(); onDispose { holder.view.onPause() } }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 0.dp), verticalAlignment = Alignment.CenterVertically) {
            ServerSwitcher(repo, onSwitch, onAdd)
            Spacer(Modifier.weight(1f))
            // ad blocker: one tap on / off, the page reloads
            Row(
                Modifier.clip(RoundedCornerShape(16.dp)).background(if (holder.adblock) Color(0x6646D369) else Color(0xFF1F1F23))
                    .clickable { holder.adblock = !holder.adblock; adOn(holder.adblock); holder.view.reload() }.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) { Text(if (holder.adblock) "🛡 Ads off" + (if (holder.blocked > 0) " · ${holder.blocked}" else "") else "🛡 Ads on", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
            IconButton(onClick = { holder.view.goBack() }, enabled = holder.canBack) {
                Icon(Icons.Filled.ArrowBack, "Back", tint = if (holder.canBack) Color.White else Color(0xFF55555C))
            }
            IconButton(onClick = { holder.view.loadUrl(homeUrl) }) { Icon(Icons.Filled.Home, "Site home", tint = Color.White) }
        }
        Box(Modifier.fillMaxWidth().height(3.dp)) {
            if (holder.loading) LinearProgressIndicator(progress = { holder.progress / 100f }, color = RED_, trackColor = Color.Transparent, modifier = Modifier.fillMaxSize())
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                factory = { holder.view.also { (it.parent as? ViewGroup)?.removeView(it) } },
                modifier = Modifier.fillMaxSize()
            )
            holder.error?.let { msg ->
                Column(Modifier.fillMaxSize().background(BG).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("Can't open this page", fontSize = 18.sp)
                    Text(msg + "\nSome sites only work on their own network (for example BDIX).", Modifier.padding(top = 8.dp), color = Color(0xFF9A9A9A), textAlign = TextAlign.Center)
                    Button(onClick = { holder.error = null; holder.view.reload() }, modifier = Modifier.padding(top = 16.dp)) { Text("Try again") }
                }
            }
        }
    }
}

/** What to do with a video file found on a website. */
@Composable
fun FileActionDialog(url: String, mime: String, onPlay: () -> Unit, onDownload: () -> Unit, onDismiss: () -> Unit) {
    val name = remember(url) { fileNameOf(url) }
    val canPlay = isVideoUrl(url) || mime.startsWith("video/")
    val canDownload = !url.substringBefore('?').lowercase().endsWith(".m3u8")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(name, fontSize = 16.sp, maxLines = 3, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (canPlay) Button(onClick = onPlay, modifier = Modifier.fillMaxWidth()) { Text("▶  Play in Trio Player") }
                if (canDownload) OutlinedButton(onClick = onDownload, modifier = Modifier.fillMaxWidth()) {
                    DownloadIcon(Color.White, 20.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Download for offline")
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
