package com.example.trio

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.atomic.AtomicInteger

/**
 * An open site that shows plain folder listings (Apache / nginx / h5ai style, what most "FTP" movie sites are). No login.
 * The folders are read once into a catalog: movies and series are recognised from the file names, the top folders become
 * categories, the listing's date becomes "recently added". Playing uses the file as it is.
 */
class FolderSource(private val store: Store, override val id: String) : Source {
    private val sv get() = store.server(id)
    override val name get() = sv?.name ?: id
    override val home get() = sv?.url ?: ""
    override val ready get() = sv != null
    private val root get() = sv?.url ?: ""

    class Entry(val url: String, val path: String, val name: String, val dir: Boolean, val time: Long)
    private class Raw(val url: String, val rel: String, val dirUrl: String, val file: String, val time: Long, val poster: String?)

    companion object {
        private val VIDEO = setOf("mkv", "mp4", "avi", "m4v", "mov", "webm", "ts", "m2ts", "wmv", "flv", "mpg", "mpeg", "3gp", "m3u8")
        private val IMG = setOf("jpg", "jpeg", "png", "webp")
        private val ANCHOR = Regex("""<a\s[^>]*?href\s*=\s*["']([^"']+)["'][^>]*>(.*?)</a>(?=([\s\S]{0,160}))""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        private val D1 = Regex("""(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})""")
        private val D2 = Regex("""(\d{1,2})-([A-Za-z]{3})-(\d{4})\s+(\d{2}):(\d{2})""")
        private val TAGS = Regex("<[^>]*>")
        private val MONTHS = listOf("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec")
        private val EP1 = Regex("""(?i)(?:^|[^a-z0-9])s(\d{1,2})[ ._-]?e(\d{1,3})""")
        private val EP2 = Regex("""(?i)(?:^|[^a-z0-9])(\d{1,2})x(\d{2,3})(?![0-9a-z])""")
        private val YEAR = Regex("""(?<![0-9])((?:19|20)\d{2})(?![0-9])""")
        private val SEASON = Regex("""(?i)^(season|series|s)[ ._-]*\d+.*|^specials?$|^complete.*""")
        private val JUNK = Regex("""(?i)[\s._\-\[(]*\b(480p|576p|720p|1080p|2160p|4k|uhd|bluray|blu-ray|bdrip|brrip|web-?dl|web-?rip|hdrip|dvdrip|dvdscr|hdtv|hdcam|camrip|x264|x265|h\.?264|h\.?265|hevc|10bit|aac|ac3)\b.*""")
        private const val MAX_DEPTH = 6
        private const val MAX_DIRS = 12000

        private fun utc(y: Int, mo: Int, d: Int, h: Int, mi: Int): Long =
            java.util.GregorianCalendar(java.util.TimeZone.getTimeZone("UTC")).apply { clear(); set(y, mo - 1, d, h, mi) }.timeInMillis

        private fun parseTime(raw: String): Long {
            val s = raw.replace(TAGS, " ")
            D1.find(s)?.let { m -> val g = m.groupValues; return utc(g[1].toInt(), g[2].toInt(), g[3].toInt(), g[4].toInt(), g[5].toInt()) }
            D2.find(s)?.let { m ->
                val g = m.groupValues
                val mo = MONTHS.indexOf(g[2].lowercase()) + 1
                if (mo > 0) return utc(g[3].toInt(), mo, g[1].toInt(), g[4].toInt(), g[5].toInt())
            }
            return 0L
        }

        /** One folder page -> its folders and files (blocking). Only links that go deeper inside the site are kept. */
        fun listDir(url: String, rootUrl: String): List<Entry> {
            val html = HTTP.newCall(Request.Builder().url(url).header("Accept", "text/html").build()).execute().use { r ->
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                r.body!!.string()
            }
            val base = url.toHttpUrl()
            val rootHttp = rootUrl.toHttpUrl()
            val out = ArrayList<Entry>()
            val seen = HashSet<String>()
            for (m in ANCHOR.findAll(html)) {
                val href = m.groupValues[1].trim().substringBefore('#')
                if (href.isEmpty() || href.startsWith("?") || href.startsWith("mailto:", true) || href.startsWith("javascript:", true)) continue
                val u = base.resolve(href) ?: continue
                if (u.host != rootHttp.host || u.query != null) continue
                val path = u.encodedPath
                if (!path.startsWith(rootHttp.encodedPath) || !path.startsWith(base.encodedPath) || path.length <= base.encodedPath.length) continue
                if (!seen.add(path)) continue
                val last = path.trimEnd('/').substringAfterLast('/')
                // a link without a file extension is a folder / page of the site too (some sites leave the slash off)
                out.add(Entry(u.toString(), path, Uri.decode(last), path.endsWith("/") || !last.contains('.'), parseTime(m.groupValues[3])))
            }
            return out
        }

        private fun ext(n: String) = n.substringAfterLast('.', "").lowercase()
        private fun isVideo(n: String) = ext(n) in VIDEO && !n.contains("sample", true)

        /** null = this address works as a folder site, otherwise a message for the user */
        suspend fun probe(url: String): String? = withContext(Dispatchers.IO) {
            try {
                val es = listDir(url, url)
                if (es.none { it.dir || isVideo(it.name) }) "No folders or videos were found at this address. If it is an Emby or Jellyfin server, enter your username and password."
                else null
            } catch (e: Exception) {
                "Cannot open that address (${e.message ?: "network error"}). Check the link and that you are on the right network."
            }
        }

        /** "Movie.Name.2019.1080p.WEB-DL" -> ("Movie Name", 2019) */
        private fun clean(rawName: String): Pair<String, Int?> {
            var s = rawName.replace('.', ' ').replace('_', ' ').replace(Regex("""\[[^\]]*\]"""), " ")
            var year: Int? = null
            var cut = s.length
            val ms = YEAR.findAll(s).filter { it.range.first > 0 && it.groupValues[1].toInt() in 1900..2030 }.toList()
            if (ms.isNotEmpty()) { year = ms.last().groupValues[1].toInt(); cut = ms.last().range.first }
            var head = s.substring(0, cut)
            val j = JUNK.find(head)
            if (j != null && j.range.first > 0) head = head.substring(0, j.range.first)
            head = head.trim().trimEnd('-', '(', '[', ' ').trim()
            if (head.isBlank()) head = s.trim()
            return head.replace(Regex("\\s+"), " ") to year
        }
    }

    private fun rootPath() = root.toHttpUrl().encodedPath
    private fun rel(path: String) = path.removePrefix(rootPath())

    private fun pickImage(es: List<Entry>): String? {
        val imgs = es.filter { !it.dir && ext(it.name) in IMG }
        return (imgs.firstOrNull { Regex("(?i)poster|cover|folder|thumb|front").containsMatchIn(it.name) } ?: imgs.firstOrNull())?.url
    }

    /** all folders below the root, ten pages at a time */
    override suspend fun catalog(onProgress: (Int, Int) -> Unit): List<Title> = coroutineScope {
        val rootUrl = root
        val first = withContext(Dispatchers.IO) { listDir(rootUrl, rootUrl) }
        if (first.none { it.dir || isVideo(it.name) }) throw IOException("No folders or videos found. Is the address still correct?")
        val files = ArrayList<Raw>()
        val gate = Semaphore(10)
        val dirs = AtomicInteger(0)
        suspend fun handle(url: String, es: List<Entry>, depth: Int) {
            val vids = es.filter { !it.dir && isVideo(it.name) }
            val img = if (vids.size <= 2) pickImage(es) else null
            if (vids.isNotEmpty()) synchronized(files) { for (v in vids) files.add(Raw(v.url, rel(v.path), url, v.name, v.time, img)) }
            onProgress(synchronized(files) { files.size }, 0)
            if (depth >= MAX_DEPTH) return
            coroutineScope {
                es.filter { it.dir }.map { d ->
                    async {
                        if (dirs.incrementAndGet() > MAX_DIRS) return@async
                        val sub = gate.withPermit { withContext(Dispatchers.IO) { try { listDir(d.url, rootUrl) } catch (e: IOException) { null } } }
                        if (sub != null) handle(d.url, sub, depth + 1)
                    }
                }.awaitAll()
            }
        }
        handle(rootUrl, first, 0)
        build(files)
    }

    private fun seriesRoot(dirUrl: String): String {
        var d = dirUrl
        while (d.length > root.length) {
            val last = Uri.decode(d.trimEnd('/').substringAfterLast('/'))
            if (!SEASON.matches(last)) break
            d = d.trimEnd('/').substringBeforeLast('/') + "/"
        }
        return d
    }

    private fun genresOf(dirRel: String, name: String): List<String> =
        Uri.decode(dirRel).split('/').filter { it.isNotBlank() && !SEASON.matches(it) && !YEAR.matches(it) && !it.equals(name, true) }
            .take(2).map { it.replace('.', ' ').replace('_', ' ').trim() }.distinct()

    private class Ser(val name: String, val id: String, val rel: String, val dirRel: String) { val eps = ArrayList<Raw>() }

    private fun build(files: List<Raw>): List<Title> {
        val movies = LinkedHashMap<String, Title>()
        val series = LinkedHashMap<String, Ser>()
        for (f in files) {
            val nameNoExt = f.file.substringBeforeLast('.')
            val m = EP1.find(nameNoExt) ?: EP2.find(nameNoExt)
            val dirRel = rel(f.dirUrl.toHttpUrl().encodedPath)
            if (m != null) {
                val sRoot = seriesRoot(f.dirUrl)
                val flat = sRoot == f.dirUrl
                val nm = if (flat) clean(nameNoExt.substring(0, m.range.first)).first
                         else clean(Uri.decode(sRoot.trimEnd('/').substringAfterLast('/'))).first
                if (nm.isBlank()) continue
                val sid = if (flat) f.dirUrl + "#" + nm else sRoot
                val srel = rel(sid.substringBefore('#').toHttpUrl().encodedPath) + (if (flat) "#$nm" else "")
                val parentRel = if (flat) dirRel else rel(sRoot.trimEnd('/').substringBeforeLast('/').toHttpUrl().encodedPath)
                series.getOrPut(sid.lowercase()) { Ser(nm, sid, srel, parentRel) }.eps.add(f)
            } else {
                val (nm, yr) = clean(nameNoExt)
                val k = nm.lowercase() + "|" + (yr ?: 0)
                if (k in movies) continue
                movies[k] = Title(
                    key = "$id:${f.rel}", source = id, id = f.url, name = nm, year = yr, series = false, overview = "", rating = 0.0,
                    genres = genresOf(dirRel, nm), poster = f.poster, backdrop = null, added = f.time, runtimeMin = 0
                )
            }
        }
        val out = ArrayList<Title>(movies.size + series.size)
        out.addAll(movies.values)
        for (s in series.values) {
            out.add(Title(
                key = "$id:${s.rel}", source = id, id = s.id, name = s.name, year = null, series = true, overview = "", rating = 0.0,
                genres = genresOf(s.dirRel, s.name), poster = s.eps.firstNotNullOfOrNull { it.poster }, backdrop = null,
                added = s.eps.maxOf { it.time }, runtimeMin = 0
            ))
        }
        return out
    }

    /** the episodes of a series folder (looks inside its season folders) */
    override suspend fun episodes(t: Title): List<Episode> = withContext(Dispatchers.IO) {
        val dirUrl = t.id.substringBefore('#')
        val only = t.id.substringAfter('#', "")
        val found = ArrayList<Episode>()
        fun walk(url: String, depth: Int) {
            val es = try { listDir(url, root) } catch (e: IOException) { return }
            for (e in es) {
                if (e.dir) { if (depth < 3) walk(e.url, depth + 1); continue }
                if (!isVideo(e.name)) continue
                val nm = e.name.substringBeforeLast('.')
                val m = EP1.find(nm) ?: EP2.find(nm) ?: continue
                if (only.isNotEmpty() && !clean(nm.substring(0, m.range.first)).first.equals(only, true)) continue
                val title = clean(nm.substring(m.range.last + 1)).first
                val num = m.groupValues[2].toInt()
                found.add(Episode(e.url, title.ifBlank { "Episode $num" }, m.groupValues[1].toInt(), num, 0, null, ""))
            }
        }
        walk(dirUrl, 0)
        found.sortedWith(compareBy({ it.season }, { it.number }))
    }

    override suspend fun search(q: String): List<Title> = emptyList()

    override suspend fun stream(t: Title, ep: Episode?): Stream {
        val u = ep?.id ?: t.id
        return Stream(u, emptyList(), 0L, 0, "") { _, _ -> u }
    }
}
