package com.example.trio

import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil
import androidx.media3.ui.PlayerView
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.launch
import kotlin.math.abs

private val GREEN = Color(0xFF46D369)
private val RED = Color(0xFFE50914)
private val PANEL = Color(0xFF2B2B2B)

@Composable
private fun PlayIcon(dp: Dp, color: Color = Color.White) {
    Canvas(Modifier.size(dp)) {
        val w = this.size.width; val h = this.size.height
        val p = Path().apply { moveTo(w * 0.28f, h * 0.18f); lineTo(w * 0.28f, h * 0.82f); lineTo(w * 0.82f, h * 0.5f); close() }
        drawPath(p, color)
    }
}

@Composable
private fun PauseIcon(dp: Dp, color: Color = Color.White) {
    Canvas(Modifier.size(dp)) {
        val w = this.size.width; val h = this.size.height
        drawRect(color, Offset(w * 0.24f, h * 0.18f), Size(w * 0.17f, h * 0.64f))
        drawRect(color, Offset(w * 0.59f, h * 0.18f), Size(w * 0.17f, h * 0.64f))
    }
}

/** Round "10" seek button: back = turn left, forward = turn right. */
@Composable
private fun Seek10(forward: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(72.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(6.dp)) {
            drawArc(
                Color(0xFFA0A0A0), startAngle = -60f, sweepAngle = 300f, useCenter = false,
                style = Stroke(width = 6f)
            )
        }
        Text("10", color = Color(0xFFA0A0A0), fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BarButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.size(46.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) { content() }
}

@Composable
private fun PanelRow(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(if (selected) Color(0xFF3A3A3A) else Color.Transparent).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(4.dp).height(52.dp).background(if (selected) RED else Color.Transparent))
        Text(
            (if (selected) "▶   " else "      ") + text, Modifier.padding(horizontal = 12.dp),
            color = if (selected) GREEN else Color.White, fontSize = 19.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun PanelHeader(text: String) {
    Text(text, Modifier.padding(start = 16.dp, top = 14.dp, bottom = 4.dp), color = Color(0xFF9A9A9A), fontSize = 14.sp)
}

private val LANG = mapOf(
    "ben" to "Bengali", "hin" to "Hindi", "tam" to "Tamil", "tel" to "Telugu", "urd" to "Urdu", "mal" to "Malayalam",
    "kan" to "Kannada", "mar" to "Marathi", "pan" to "Punjabi", "eng" to "English", "jpn" to "Japanese", "kor" to "Korean",
    "zho" to "Chinese", "chi" to "Chinese", "spa" to "Spanish", "fra" to "French", "fre" to "French", "deu" to "German",
    "ger" to "German", "rus" to "Russian", "ara" to "Arabic", "tha" to "Thai", "tur" to "Turkish", "ind" to "Indonesian",
    "por" to "Portuguese", "ita" to "Italian", "nep" to "Nepali", "sin" to "Sinhala", "may" to "Malay", "msa" to "Malay"
)

/** "hin" / "hi" / "hi-IN" -> "Hindi"; null when the language is unknown. */
private fun langName(code: String?): String? {
    val c = code?.trim()?.lowercase()?.substringBefore('-')?.substringBefore('_') ?: return null
    if (c.isEmpty() || c == "und" || c == "mis" || c == "zxx") return null
    LANG[c]?.let { return it }
    val n = java.util.Locale(c).getDisplayLanguage(java.util.Locale.ENGLISH)
    return if (n.isBlank() || n.equals(c, true)) null else n.replaceFirstChar { it.uppercase() }
}

private fun isEnglish(f: androidx.media3.common.Format): Boolean =
    langName(f.language) == "English" || f.label?.contains("english", ignoreCase = true) == true

/** Track names are the language ("English", "Hindi"); two tracks of one language get a number (and 5.1 / stereo for audio). */
private fun trackNames(groups: List<Tracks.Group>, audio: Boolean): List<String> {
    val base = groups.mapIndexed { i, g ->
        val f = g.getTrackFormat(0)
        langName(f.language) ?: f.label?.takeIf { it.isNotBlank() } ?: "Track ${i + 1}"
    }
    return base.mapIndexed { i, n ->
        if (base.count { it == n } < 2) n
        else {
            val ch = if (audio) when (groups[i].getTrackFormat(0).channelCount) { 1 -> "mono"; 2 -> "stereo"; 6 -> "5.1"; 8 -> "7.1"; else -> null } else null
            n + " " + base.take(i + 1).count { it == n } + (ch?.let { " · $it" } ?: "")
        }
    }
}

// ---------------------------------------------------------------- quality: Original / Auto / 1080p / 720p / 480p

/** height -> video kbit/s used when the server converts the video */
private val TIERS = listOf(1080 to 8000, 720 to 4000, 480 to 1500)
private val LADDER = listOf("orig", "1080", "720", "480")

fun qualityName(q: String) = when (q) { "auto" -> "Auto"; "orig" -> "Original"; else -> "${q}p" }

/** True if this phone decodes the codec in hardware. Software decoding of 4K/HEVC is what makes phones hot. */
@OptIn(UnstableApi::class)
private fun hwDecoder(codec: String): Boolean {
    val mime = when (codec.lowercase()) {
        "h264", "avc" -> "video/avc"; "hevc", "h265" -> "video/hevc"; "av1" -> "video/av01"
        "vp9" -> "video/x-vnd.on2.vp9"; "vp8" -> "video/x-vnd.on2.vp8"; "mpeg4" -> "video/mp4v-es"
        else -> return true
    }
    return try { MediaCodecUtil.getDecoderInfo(mime, false, false)?.hardwareAccelerated ?: false } catch (e: Exception) { true }
}

private val speedHttp = OkHttpClient.Builder().connectTimeout(4, TimeUnit.SECONDS).readTimeout(4, TimeUnit.SECONDS).build()

/** Downloads about 2 MB from the file and returns the speed in Mbit/s (0 = could not measure). */
private suspend fun measureMbps(url: String): Double = withContext(Dispatchers.IO) {
    try {
        val t0 = System.nanoTime()
        val req = Request.Builder().url(url).header("Range", "bytes=0-1999999").build()
        speedHttp.newCall(req).execute().use { r ->
            var n = 0L
            val buf = ByteArray(32768)
            val src = r.body!!.byteStream()
            while (n < 2_000_000) { val k = src.read(buf); if (k < 0) break; n += k }
            val sec = (System.nanoTime() - t0) / 1e9
            if (sec <= 0.0 || n < 200_000) 0.0 else n * 8 / sec / 1e6
        }
    } catch (e: Exception) { 0.0 }
}

private var lastMbps = 0.0
private var lastMbpsAt = 0L

/** The speed test is reused for 5 minutes, so the next episode starts without waiting for it. */
private suspend fun cachedMbps(url: String): Double {
    val now = System.currentTimeMillis()
    if (lastMbps > 0 && now - lastMbpsAt < 300_000L) return lastMbps
    val v = measureMbps(url)
    if (v > 0) { lastMbps = v; lastMbpsAt = now }
    return v
}

/** Auto: the original file when the phone decodes it in hardware and the network is fast enough, else the best converted version that fits. */
private fun autoPick(s: Stream, mbps: Double, hw: Boolean): String {
    val need = if (s.bitrate > 0) s.bitrate / 1e6 else when { s.height >= 2000 -> 40.0; s.height >= 1000 -> 10.0; else -> 5.0 }
    if (mbps <= 0.0) return if (hw) "orig" else "720"
    if (hw && mbps >= need * 1.6) return "orig"
    return TIERS.firstOrNull { (h, kbps) -> (s.height <= 0 || h <= s.height) && kbps / 1000.0 * 1.6 <= mbps }?.first?.toString() ?: "480"
}

// Position and time are polled only while these two are on screen (controls visible). The rest of the player does not redraw twice a second.
@Composable
private fun SeekBar(exo: ExoPlayer?, onTouch: () -> Unit) {
    var scrub by remember { mutableStateOf<Float?>(null) }
    val pd by produceState(0L to 0L, exo) {
        while (true) {
            value = (exo?.currentPosition ?: 0L) to (exo?.duration ?: 0L).coerceAtLeast(0L)
            delay(500)
        }
    }
    val total = pd.second.coerceAtLeast(1L)
    Slider(
        value = (scrub ?: (pd.first.toFloat() / total)).coerceIn(0f, 1f),
        onValueChange = { scrub = it; onTouch() },
        onValueChangeFinished = { scrub?.let { v -> exo?.seekTo((v * total).toLong()) }; scrub = null },
        colors = SliderDefaults.colors(thumbColor = RED, activeTrackColor = RED, inactiveTrackColor = Color(0x66FFFFFF)),
        modifier = Modifier.fillMaxWidth().height(28.dp)
    )
}

@Composable
private fun TimeLabel(exo: ExoPlayer?) {
    val pd by produceState(0L to 0L, exo) {
        while (true) {
            value = (exo?.currentPosition ?: 0L) to (exo?.duration ?: 0L).coerceAtLeast(0L)
            delay(1000)
        }
    }
    Text(fmtTime(pd.first) + "  /  " + fmtTime(pd.second), Modifier.padding(horizontal = 8.dp), color = Color.White, fontSize = 16.sp, maxLines = 1)
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(req: PlayReq, repo: Repo, store: Store, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val act = ctx as ComponentActivity
    val scope = rememberCoroutineScope()

    var ep by remember { mutableStateOf(req.start) }
    var exo by remember { mutableStateOf<ExoPlayer?>(null) }
    var playing by remember { mutableStateOf(true) }
    var buffering by remember { mutableStateOf(true) }
    var quality by remember { mutableStateOf(store.quality) }   // what you chose: auto | orig | 1080 | 720 | 480
    var playingAs by remember { mutableStateOf("orig") }         // what is playing now
    var controls by remember { mutableStateOf(true) }
    var touch by remember { mutableStateOf(0L) }
    var panel by remember { mutableStateOf<String?>(null) }     // cc | speed | audio | eps
    var resize by remember { mutableStateOf(0) }                // 0 fit, 1 fill, 2 zoom
    var speed by remember { mutableStateOf(1f) }
    var muted by remember { mutableStateOf(false) }
    var hud by remember { mutableStateOf<String?>(null) }
    var skipAcc by remember { mutableStateOf(0L) }   // repeated double taps add up: +10 s, +20 s, +30 s
    var err by remember { mutableStateOf<String?>(null) }
    var tracksVersion by remember { mutableStateOf(0) }
    val cur = remember { arrayOfNulls<Stream>(1) }
    val curEp = remember { arrayOfNulls<String>(1) }
    val failed = remember { HashSet<String>() }
    val engDone = remember { booleanArrayOf(false) }   // English was looked for in the current video
    val isLink = req.title.source == LINK_SOURCE || repo.isFolder(req.title.source)   // a pasted web link: always the original address, no server conversion

    BackHandler(onBack = onClose)
    BackHandler(enabled = panel != null) { panel = null }
    LaunchedEffect(hud) { if (hud != null) { delay(1100); hud = null; skipAcc = 0L } }

    // landscape, no system bars
    DisposableEffect(Unit) {
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val c = WindowCompat.getInsetsController(act.window, act.window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        onDispose {
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            c.show(WindowInsetsCompat.Type.systemBars())
            val lp = act.window.attributes; lp.screenBrightness = android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE; act.window.attributes = lp
        }
    }

    fun label(e: Episode?) = if (e == null) req.title.name else "${req.title.name} S%02dE%02d".format(e.season, e.number)

    /** Starts (or restarts) playback. mode = null: use the quality setting (Auto measures the network first). */
    fun loadEp(p: ExoPlayer, e: Episode?, mode: String? = null, at: Long = -1L, reuse: Boolean = false) {
        scope.launch {
            err = null; buffering = true
            try {
                val s = if (reuse && cur[0] != null && curEp[0] == e?.id) cur[0]!! else repo.stream(req.title, e)
                cur[0] = s; curEp[0] = e?.id
                var m = mode ?: quality
                if (isLink) m = "orig" else if (m == "auto") m = autoPick(s, cachedMbps(s.url), hwDecoder(s.codec))
                playingAs = m
                val cfgs = s.subs.map { t ->
                    val b = MediaItem.SubtitleConfiguration.Builder(Uri.parse(t.url)).setMimeType(t.mime).setLabel(t.label)
                    if (t.lang != null) b.setLanguage(t.lang)
                    b.build()
                }
                val uri = if (m == "orig") s.url else {
                    val tier = TIERS.firstOrNull { it.first == m.toIntOrNull() } ?: TIERS.last()
                    s.transcode(tier.first, tier.second)
                }
                val resume = if (at >= 0) at else store.resumePosition(e?.id ?: req.title.key)
                if (resume > 0 && at < 0) Toast.makeText(ctx, "Resuming from ${fmtTime(resume)}", Toast.LENGTH_SHORT).show()
                val item = MediaItem.Builder().setUri(uri).setSubtitleConfigurations(cfgs)
                if (isLink) linkMime(uri)?.let { item.setMimeType(it) }
                engDone[0] = false
                p.setMediaItem(item.build(), resume)
                p.prepare(); p.playWhenReady = true
            } catch (ex: Exception) { err = ex.message ?: "Could not start playback" }
        }
    }

    fun saveNow() {
        val p = exo ?: return
        store.saveProgress(req.title.key, ep?.id, label(ep), p.currentPosition, p.duration.coerceAtLeast(0))
    }

    fun switchEp(e: Episode) {
        val p = exo ?: return
        saveNow(); ep = e; failed.clear(); panel = null
        loadEp(p, e)
    }

    fun nextOf(): Episode? {
        val e = ep ?: return null
        val i = req.eps.indexOfFirst { it.id == e.id }
        return if (i >= 0 && i + 1 < req.eps.size) req.eps[i + 1] else null
    }
    val nextEpisode = nextOf()

    // create the player
    LaunchedEffect(Unit) {
        // moderate buffers: enough to ride out wifi hiccups, small enough to keep memory and CPU low
        val p = ExoPlayer.Builder(ctx).setRenderersFactory(NextRenderersFactory(ctx))
            .setLoadControl(DefaultLoadControl.Builder().setBufferDurationsMs(20_000, 45_000, 1_500, 3_000).build())
            .setHandleAudioBecomingNoisy(true)
            .build()
        p.setAudioAttributes(androidx.media3.common.AudioAttributes.DEFAULT, true)   // pause for calls, stop other music
        val lang = store.subLang
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().apply {
            setPreferredAudioLanguage("en")   // every movie and episode starts in English when it has an English track
            if (lang.isNotBlank()) { setPreferredTextLanguage(lang); setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false) }
            else setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        }.build()
        p.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_ENDED) { val n = nextOf(); if (n != null) switchEp(n) else onClose() }
            }
            override fun onTracksChanged(tracks: Tracks) {
                tracksVersion++
                if (!engDone[0]) {
                    val aud = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO && it.isTrackSupported(0) }
                    if (aud.isNotEmpty()) {
                        engDone[0] = true
                        val eng = aud.firstOrNull { isEnglish(it.getTrackFormat(0)) }
                        if (eng != null && !eng.isSelected) {
                            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                                .setOverrideForType(TrackSelectionOverride(eng.mediaTrackGroup, 0)).build()
                        }
                    }
                }
            }
            override fun onPlayerError(error: PlaybackException) {
                if (isLink) { err = error.message ?: "Playback error"; return }
                // original file failed -> ask the server to convert it; a converted stream failed -> try the original
                failed.add(playingAs)
                val order = if (playingAs == "orig") listOf("720", "480") else listOf("orig", "480")
                val next = order.firstOrNull { it !in failed }
                if (next != null) {
                    Toast.makeText(ctx, if (next == "orig") "Trying the original file…" else "Trying ${next}p from the server…", Toast.LENGTH_SHORT).show()
                    loadEp(p, ep, mode = next, at = p.currentPosition, reuse = true)
                } else err = error.message ?: "Playback error"
            }
        })
        loadEp(p, ep)
        exo = p
    }

    // progress is saved every 15 s (kept in memory, written to disk every 30 s); nothing here redraws the screen
    LaunchedEffect(exo) {
        if (exo == null) return@LaunchedEffect
        while (true) { delay(15_000); saveNow() }
    }
    // Auto quality: if the picture keeps buffering for 12 s, go one step lower at the same position
    LaunchedEffect(exo) {
        val p = exo ?: return@LaunchedEffect
        var stuck = 0
        while (true) {
            delay(1000)
            if (buffering && quality == "auto" && !isLink) stuck++ else stuck = 0
            if (stuck >= 12) {
                stuck = 0
                val next = LADDER.getOrNull(LADDER.indexOf(playingAs) + 1)
                if (next != null) {
                    Toast.makeText(ctx, "Slow network: lowering quality to ${qualityName(next)}", Toast.LENGTH_SHORT).show()
                    loadEp(p, ep, mode = next, at = p.currentPosition, reuse = true)
                }
            }
        }
    }
    LaunchedEffect(controls, touch, playing, panel) {
        if (controls && playing && panel == null) { delay(3500); controls = false }
    }
    DisposableEffect(exo) {
        val p = exo
        val obs = androidx.lifecycle.LifecycleEventObserver { _, ev -> if (ev == androidx.lifecycle.Lifecycle.Event.ON_PAUSE) p?.pause() }
        act.lifecycle.addObserver(obs)
        onDispose {
            act.lifecycle.removeObserver(obs)
            if (p != null) {
                store.saveProgress(req.title.key, ep?.id, label(ep), p.currentPosition, p.duration.coerceAtLeast(0), flush = true)
                p.release()
            }
        }
    }

    val p = exo
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (p != null) AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    this.player = p
                    useController = false
                    keepScreenOn = true
                    setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                }
            },
            update = { v -> v.resizeMode = when (resize) { 1 -> 3; 2 -> 4; else -> 0 } },
            modifier = Modifier.fillMaxSize()
        )

        // ---- touch layer: tap = controls, double tap = ±10 s, swipe = seek / brightness / volume
        Box(
            Modifier.fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { if (panel != null) panel = null else { controls = !controls; touch = System.currentTimeMillis() } },
                        onDoubleTap = { off ->
                            val pl = exo
                            if (pl != null) {
                                val left = off.x < size.width / 2f
                                val d = pl.duration
                                val t = (pl.currentPosition + if (left) -10_000L else 10_000L).let { if (d > 0) it.coerceIn(0L, d) else it.coerceAtLeast(0L) }
                                pl.seekTo(t)
                                val dlt = if (left) -10_000L else 10_000L
                                skipAcc = if (skipAcc != 0L && (skipAcc < 0) == left) skipAcc + dlt else dlt
                                hud = (if (skipAcc > 0) "+" else "−") + abs(skipAcc) / 1000 + " s"
                            }
                        }
                    )
                }
                .pointerInput(Unit) {
                    val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                    var mode = 0; var tx = 0f; var ty = 0f; var seekBy = 0L
                    var bright = act.window.attributes.screenBrightness.let { if (it < 0f) 0.5f else it }
                    var vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                    detectDragGestures(
                        onDragStart = { mode = 0; tx = 0f; ty = 0f; seekBy = 0L; vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() },
                        onDragEnd = {
                            val pl = exo
                            if (mode == 1 && seekBy != 0L && pl != null) {
                                val d = pl.duration
                                pl.seekTo((pl.currentPosition + seekBy).let { if (d > 0) it.coerceIn(0L, d) else it.coerceAtLeast(0L) })
                            }
                            mode = 0; seekBy = 0L
                        },
                        onDragCancel = { mode = 0; seekBy = 0L },
                        onDrag = { change, drag ->
                            change.consume()
                            tx += drag.x; ty += drag.y
                            if (mode == 0 && (abs(tx) > 24f || abs(ty) > 24f)) {
                                mode = if (abs(tx) > abs(ty)) 1 else if (change.position.x < size.width / 2f) 2 else 3
                            }
                            when (mode) {
                                1 -> {
                                    seekBy += (drag.x * 90_000f / size.width).toLong()
                                    val target = ((exo?.currentPosition ?: 0L) + seekBy).coerceAtLeast(0L)
                                    hud = (if (seekBy >= 0) "+" else "−") + fmtTime(abs(seekBy)) + "  →  " + fmtTime(target)
                                }
                                2 -> {
                                    bright = (bright - drag.y / size.height * 1.3f).coerceIn(0.02f, 1f)
                                    val lp = act.window.attributes; lp.screenBrightness = bright; act.window.attributes = lp
                                    hud = "Brightness ${(bright * 100).toInt()}%"
                                }
                                3 -> {
                                    vol = (vol - drag.y / size.height * maxVol * 1.3f).coerceIn(0f, maxVol.toFloat())
                                    am.setStreamVolume(AudioManager.STREAM_MUSIC, vol.toInt(), 0)
                                    hud = "Volume ${(vol / maxVol * 100).toInt()}%"
                                }
                            }
                        }
                    )
                }
        )

        // ---- centre: -10 | play/pause or spinner | +10
        if (controls && panel == null) {
            Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(56.dp)) {
                Seek10(false) { exo?.let { it.seekTo((it.currentPosition - 10_000L).coerceAtLeast(0L)); touch = System.currentTimeMillis() } }
                Box(Modifier.size(76.dp).clickable { exo?.let { if (it.isPlaying) it.pause() else it.play() }; touch = System.currentTimeMillis() }, contentAlignment = Alignment.Center) {
                    if (buffering) CircularProgressIndicator(color = RED, strokeWidth = 4.dp, modifier = Modifier.size(64.dp))
                    else if (playing) PauseIcon(54.dp) else PlayIcon(60.dp)
                }
                Seek10(true) { exo?.let { val d = it.duration; it.seekTo((it.currentPosition + 10_000L).let { t -> if (d > 0) t.coerceAtMost(d) else t }); touch = System.currentTimeMillis() } }
            }
        } else if (buffering && panel == null) {
            CircularProgressIndicator(color = RED, strokeWidth = 4.dp, modifier = Modifier.align(Alignment.Center).size(56.dp))
        }

        // ---- top right: close
        if (controls && panel == null) {
            Box(
                Modifier.align(Alignment.TopEnd).padding(18.dp).size(48.dp).clickable(onClick = onClose),
                contentAlignment = Alignment.Center
            ) { Text("✕", color = Color.White, fontSize = 30.sp) }
        }

        // ---- floating settings button (right side)
        if (controls && panel == null) {
            Box(
                Modifier.align(Alignment.CenterEnd).padding(end = 22.dp).size(64.dp).background(Color(0xAA2B2B2B), CircleShape)
                    .clickable { panel = "speed" },
                contentAlignment = Alignment.Center
            ) { Text("⚙", color = Color.White, fontSize = 30.sp) }
        }

        // ---- bottom bar
        if (controls && panel == null) {
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000))))
                    .padding(horizontal = 14.dp)
            ) {
                SeekBar(exo) { touch = System.currentTimeMillis() }
                Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    BarButton({ exo?.let { if (it.isPlaying) it.pause() else it.play() }; touch = System.currentTimeMillis() }) {
                        if (playing) PauseIcon(30.dp) else PlayIcon(30.dp)
                    }
                    BarButton({ muted = !muted; exo?.volume = if (muted) 0f else 1f }) { Text(if (muted) "🔇" else "🔊", fontSize = 22.sp) }
                    TimeLabel(exo)
                    Spacer(Modifier.width(6.dp))
                    val e = ep
                    if (e != null) Box(
                        Modifier.background(Color.White, RoundedCornerShape(8.dp)).padding(horizontal = 14.dp, vertical = 6.dp)
                    ) { Text("S${e.season} · E${e.number}", color = Color.Black, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
                    Text(
                        buildAnnotatedString {
                            append(req.title.name)
                            if (e != null) { append(" – "); withStyle(SpanStyle(color = GREEN)) { append(e.name) } }
                        },
                        Modifier.weight(1f).padding(horizontal = 12.dp), color = Color.White, fontSize = 18.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    if (req.eps.isNotEmpty()) BarButton({ panel = "eps" }) { Text("☰", color = Color.White, fontSize = 24.sp) }
                    if (nextEpisode != null) BarButton({ switchEp(nextEpisode) }) { Text("⏭", color = Color.White, fontSize = 24.sp) }
                    if (!isLink) BarButton({ panel = "hd" }) {
                        Box(Modifier.border(2.dp, Color.White, RoundedCornerShape(4.dp)).padding(horizontal = 4.dp, vertical = 1.dp)) {
                            Text(if (quality == "auto") "A" else "HD", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    BarButton({ panel = "cc" }) {
                        Box(Modifier.border(2.dp, Color.White, RoundedCornerShape(4.dp)).padding(horizontal = 4.dp, vertical = 1.dp)) {
                            Text("CC", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    BarButton({ panel = "speed" }) { Text("⚙", color = Color.White, fontSize = 26.sp) }
                    BarButton({ resize = (resize + 1) % 3; hud = listOf("Fit", "Fill", "Zoom")[resize] }) { Text("⛶", color = Color.White, fontSize = 26.sp) }
                }
            }
        }

        // ---- short messages
        hud?.let {
            Box(
                Modifier.align(Alignment.TopCenter).padding(top = 40.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(24.dp)).padding(horizontal = 20.dp, vertical = 10.dp)
            ) { Text(it, color = Color.White, fontSize = 18.sp) }
        }

        // ---- side panel with tabs
        panel?.let { tab ->
            @Suppress("UNUSED_VARIABLE") val tv = tracksVersion
            val tracks = p?.currentTracks?.groups.orEmpty()
            val texts = tracks.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported() }
            val audios = tracks.filter { it.type == C.TRACK_TYPE_AUDIO && it.isSupported() }
            val textOn = p?.trackSelectionParameters?.disabledTrackTypes?.contains(C.TRACK_TYPE_TEXT) == false
            Column(
                Modifier.align(Alignment.TopEnd).fillMaxHeight(0.92f).fillMaxWidth(0.52f).widthIn(min = 320.dp)
                    .background(PANEL)
            ) {
                Row(Modifier.fillMaxWidth().padding(start = 8.dp, end = 4.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    val tabs = listOf("cc" to "Audio & Subs") + (if (isLink) emptyList<Pair<String, String>>() else listOf("hd" to "Quality")) +
                        listOf("speed" to "Speed") + (if (req.eps.isNotEmpty()) listOf("eps" to "Episodes") else emptyList())
                    Row(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
                        tabs.forEach { (id, name) ->
                            Column(Modifier.clickable { panel = id }.padding(horizontal = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(name, color = if (tab == id) Color.White else Color(0xFF9A9A9A), fontSize = 16.sp, fontWeight = if (tab == id) FontWeight.Bold else FontWeight.Normal, maxLines = 1, modifier = Modifier.padding(vertical = 8.dp))
                                Box(Modifier.fillMaxWidth().height(3.dp).background(if (tab == id) RED else Color.Transparent))
                            }
                        }
                    }
                    Box(Modifier.size(44.dp).clickable { panel = null }, contentAlignment = Alignment.Center) { Text("✕", color = Color.White, fontSize = 26.sp) }
                }
                LazyColumn(Modifier.fillMaxWidth()) {
                    when (tab) {
                        "cc" -> {
                            val aNames = trackNames(audios, true)
                            val tNames = trackNames(texts, false)
                            item { PanelHeader("Audio") }
                            itemsIndexed(audios) { n, g ->
                                PanelRow(aNames[n], g.isSelected) {
                                    p?.trackSelectionParameters = p!!.trackSelectionParameters.buildUpon()
                                        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
                                }
                            }
                            if (audios.isEmpty()) item { Text("No playable audio track.", Modifier.padding(16.dp), color = Color(0xFF9A9A9A)) }
                            item { PanelHeader("Subtitles") }
                            item { PanelRow("Off", !textOn) {
                                p?.trackSelectionParameters = p!!.trackSelectionParameters.buildUpon()
                                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                                store.subLang = ""
                            } }
                            itemsIndexed(texts) { n, g ->
                                PanelRow(tNames[n], textOn && g.isSelected) {
                                    p?.trackSelectionParameters = p!!.trackSelectionParameters.buildUpon()
                                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
                                    store.subLang = g.getTrackFormat(0).language ?: ""
                                }
                            }
                            if (texts.isEmpty()) item { Text("No subtitles in this video.", Modifier.padding(16.dp), color = Color(0xFF9A9A9A)) }
                        }
                        "hd" -> {
                            val s0 = cur[0]
                            item { PanelHeader("Quality" + if (quality == "auto") " · now playing " + qualityName(playingAs) else "") }
                            val opts = ArrayList<Pair<String, String>>()
                            opts.add("auto" to "Auto (adapts to your network and phone)")
                            opts.add("orig" to "Original" + (if (s0 != null && s0.height > 0) " · ${s0.height}p" else ""))
                            TIERS.forEach { (h, _) -> if (s0 == null || s0.height <= 0 || h < s0.height) opts.add("$h" to "${h}p (converted by the server)") }
                            itemsIndexed(opts) { _, o ->
                                PanelRow(o.second, quality == o.first) {
                                    quality = o.first; store.quality = o.first; failed.clear()
                                    p?.let { pl -> loadEp(pl, ep, mode = if (o.first == "auto") null else o.first, at = pl.currentPosition, reuse = true) }
                                    panel = null
                                }
                            }
                            item { Text("Converted versions use the server's processor. Original uses the least battery when your phone decodes it in hardware.", Modifier.padding(16.dp), color = Color(0xFF9A9A9A), fontSize = 13.sp) }
                        }
                        "speed" -> {
                            item { PanelHeader("Playback speed") }
                            itemsIndexed(listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)) { _, s ->
                                PanelRow(if (s == 1f) "Normal" else "${s}×", speed == s) { speed = s; p?.setPlaybackSpeed(s) }
                            }
                            item { PanelHeader("Picture size") }
                            itemsIndexed(listOf("Fit", "Fill (stretch)", "Zoom (crop)")) { i, n -> PanelRow(n, resize == i) { resize = i } }
                        }
                        else -> {
                            val e0 = ep
                            val list = req.eps.filter { e0 == null || it.season == e0.season }
                            item { PanelHeader(if (e0 != null) "Season ${e0.season}" else "Episodes") }
                            itemsIndexed(list) { _, e -> PanelRow("${e.number}. ${e.name}", e.id == e0?.id) { switchEp(e) } }
                        }
                    }
                }
            }
        }

        // ---- error
        err?.let { msg ->
            Column(
                Modifier.align(Alignment.Center).padding(24.dp).background(Color(0xE6101014), RoundedCornerShape(16.dp)).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("This video can't be played", color = Color.White, fontSize = 18.sp)
                Text(msg, color = Color(0xFFB0B0B8), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp), maxLines = 3, overflow = TextOverflow.Ellipsis)
                Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { exo?.let { pl -> failed.clear(); loadEp(pl, ep, at = pl.currentPosition) } }) { Text("Try again") }
                    OutlinedButton(onClick = onClose) { Text("Go back") }
                }
            }
        }
    }
}
