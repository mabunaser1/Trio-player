package com.example.trio

import android.app.Activity
import android.content.Intent
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    // a video link sent to the app from a browser or another app ("Open with" / "Share")
    private var incoming by mutableStateOf<String?>(null)

    private fun linkFrom(i: Intent?): String? {
        if (i == null) return null
        val d = i.data
        if (i.action == Intent.ACTION_VIEW && d != null) return d.toString()
        if (i.action == Intent.ACTION_SEND) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return null
            return Regex("https?://\\S+").find(t)?.value
        }
        return null
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); setIntent(intent); incoming = linkFrom(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        incoming = linkFrom(intent)
        // smaller bitmaps (RGB565) and no re-downloading of posters: less memory, less network, less battery
        coil.Coil.setImageLoader(
            coil.ImageLoader.Builder(this).allowRgb565(true).crossfade(false).respectCacheHeaders(false)
                .memoryCache { coil.memory.MemoryCache.Builder(this).maxSizePercent(0.12).build() }   // posters never take more than 12% of the memory
                .diskCache { coil.disk.DiskCache.Builder().directory(cacheDir.resolve("posters")).maxSizeBytes(120L * 1024 * 1024).build() }
                .build()
        )
        val scheme = darkColorScheme(
            primary = RED_, onPrimary = Color.White, background = BG, surface = BG,
            surfaceVariant = Color(0xFF1F1F23), onSurfaceVariant = Color(0xFFB0B0B8)
        )
        setContent { MaterialTheme(colorScheme = scheme) { Surface(Modifier.fillMaxSize()) { App(incoming) { incoming = null } } } }
    }
}

@Composable
fun App(incoming: String?, onConsumed: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val repo = remember { Repo(ctx, store) }
    val scope = rememberCoroutineScope()
    val loggedIn = repo.servers.isNotEmpty()   // at least one saved server
    var showAdd by remember { mutableStateOf(false) }
    val dl = remember { Downloads(ctx.applicationContext) }
    val webs = remember { HashMap<String, WebHolder>() }
    var fileAction by remember { mutableStateOf<Pair<String, String>?>(null) }
    val notifAsk = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) { dl.refresh() }
    LaunchedEffect(dl.active) { while (dl.active) { delay(1500); dl.refresh() } }   // progress is polled only while something downloads
    var tab by remember { mutableStateOf(if (store.loggedIn) 0 else 2) }
    var skipped by remember { mutableStateOf(store.skipped) }
    var detail by remember { mutableStateOf<Title?>(null) }
    var play by remember { mutableStateOf<PlayReq?>(null) }
    var hist by remember { mutableStateOf(store.history()) }
    var myList by remember { mutableStateOf(store.myList()) }
    var favs by remember { mutableStateOf(store.favs()) }
    var lastBack by remember { mutableStateOf(0L) }
    // scroll positions and the search live here, so coming back from a title page finds everything where you left it
    val homeState = rememberLazyListState()
    val profileState = rememberLazyListState()
    val searchGrid = rememberLazyGridState()
    val search = remember { SearchState().also { it.all = store.globalSearch } }
    val year = remember { java.util.Calendar.getInstance().get(java.util.Calendar.YEAR) }
    val allTitles = repo.titles
    val lm = repo.latestM
    val ls = repo.latestS
    val rows by produceState(emptyList<Pair<String, List<Title>>>(), allTitles, lm, ls) {
        value = withContext(Dispatchers.Default) { buildRows(allTitles, year, lm, ls) }
    }

    LaunchedEffect(incoming) {
        val u = incoming
        if (u != null) { if (isWebLink(u)) store.addLink(u); play = linkReq(u); onConsumed() }
    }
    // opening a server: show the saved library at once, then ask for what is new (two tiny requests), then a full update only when it is a day old
    LaunchedEffect(repo.activeId) {
        if (repo.activeId.isNotBlank()) {
            repo.loadCache(); repo.quickRefresh(); repo.refresh(); Repo.scheduleDaily(ctx)
        }
    }
    // coming back to the app picks up newly added movies and episodes (at most every 5 minutes)
    DisposableEffect(Unit) {
        val act = ctx as? ComponentActivity
        val obs = androidx.lifecycle.LifecycleEventObserver { _, ev ->
            if (ev == androidx.lifecycle.Lifecycle.Event.ON_START) scope.launch { repo.quickRefresh() }
        }
        act?.lifecycle?.addObserver(obs)
        onDispose { act?.lifecycle?.removeObserver(obs) }
    }

    val pl = play
    val d = detail

    // back: title page / other tab -> Home; on Home press twice to leave the app
    BackHandler(enabled = pl == null && d == null && (loggedIn || skipped)) {
        val wh = if (tab == 0 && repo.isFolder(repo.activeId)) webs[repo.activeId] else null
        if (wh != null && wh.view.canGoBack()) wh.view.goBack()
        else if (tab != 0) tab = 0
        else {
            val now = System.currentTimeMillis()
            if (now - lastBack < 2000L) (ctx as? Activity)?.finish()
            else { lastBack = now; Toast.makeText(ctx, "Press back again to exit", Toast.LENGTH_SHORT).show() }
        }
    }

    val removeContinue: (Title) -> Unit = { t ->
        store.removeFromContinue(t.key); hist = store.history()
        Toast.makeText(ctx, "Removed from Continue Watching", Toast.LENGTH_SHORT).show()
    }
    val resume: (Hist, Title) -> Unit = { h, t ->
        // jump straight back into the episode or movie that was being watched
        scope.launch {
            val eps: List<Episode> = if (t.series) try { repo.episodes(t) } catch (e: Exception) { emptyList() } else emptyList()
            if (t.series && eps.isEmpty()) Toast.makeText(ctx, "Could not load episodes. Check your connection.", Toast.LENGTH_SHORT).show()
            else play = PlayReq(t, eps, eps.firstOrNull { it.id == h.epId })
        }
    }

    fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notifAsk.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    // Download button: starts it, or plays the finished file, or retries a failed one
    val startDownload: (Title, Episode?) -> Unit = { t, e ->
        val ex = dl.find(t.key, e?.id ?: "")
        when {
            ex != null && ex.complete -> play = dl.playReq(ex)
            ex != null && ex.failed -> dl.retry(ex)
            ex != null -> Toast.makeText(ctx, "Already downloading", Toast.LENGTH_SHORT).show()
            else -> scope.launch {
                try {
                    val s = repo.stream(t, e)
                    val label = e?.let { "S${it.season} E${it.number}  ${it.name}" } ?: ""
                    val file = t.name + (e?.let { " S%02dE%02d".format(it.season, it.number) } ?: t.year?.let { " ($it)" } ?: "") + "." + s.container.ifBlank { "mkv" }
                    askNotif()
                    val id = dl.enqueue(s.url, file, t.name, label, e?.thumb ?: t.poster, t.key, e?.id ?: "")
                    Toast.makeText(ctx, if (id >= 0) "Download started" else "Could not start the download", Toast.LENGTH_SHORT).show()
                } catch (x: Exception) {
                    Toast.makeText(ctx, "Could not start the download. Check your connection.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    // a video file found on a website
    val downloadUrl: (String) -> Unit = { u ->
        if (dl.find("", u) != null) Toast.makeText(ctx, "Already in Downloads", Toast.LENGTH_SHORT).show()
        else {
            askNotif()
            val id = dl.enqueue(u, fileNameOf(u), linkName(u), "From website", null, "", u)
            Toast.makeText(ctx, if (id >= 0) "Download started" else "Could not start the download", Toast.LENGTH_SHORT).show()
        }
    }

    val switchServer: (String) -> Unit = { id ->
        if (id != repo.activeId) scope.launch {
            repo.switchTo(id)
            search.q = ""; search.results = emptyList(); search.done = ""; search.filter = "All"
            homeState.scrollToItem(0); profileState.scrollToItem(0); searchGrid.scrollToItem(0)
            detail = null
        }
    }

    when {
        pl != null -> PlayerScreen(pl, repo, store) { play = null; hist = store.history() }
        !loggedIn && !skipped -> LoginScreen(repo, onDone = { tab = 0 }, onSkip = { store.skipped = true; skipped = true })
        d != null -> DetailScreen(
            t = d, repo = repo, hist = hist, inList = d.key in myList, inFav = d.key in favs,
            onToggleList = { store.toggleMyList(d.key); myList = store.myList() },
            onToggleFav = { store.toggleFav(d.key); favs = store.favs() },
            onPlay = { play = it }, onBack = { detail = null },
            dl = dl, onDownload = startDownload
        )
        else -> Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> {
                        val site = repo.activeServer?.takeIf { it.type == "folder" }
                        if (site != null) {
                            // an open website: shown inside the app
                            val holder = webs.getOrPut(site.id) { createWeb(ctx, site.url) }
                            WebSiteScreen(repo, holder, site.url, switchServer, { showAdd = true }) { u, mime -> fileAction = u to mime }
                        } else HomeScreen(
                            repo, rows, hist, homeState, onOpen = { detail = it }, onResume = resume, onRemove = removeContinue,
                            onSwitch = switchServer, onAdd = { showAdd = true }
                        )
                    }
                    1 -> SearchScreen(repo, search, searchGrid) { detail = it }
                    2 -> LinksScreen(store) { u -> store.addLink(u); play = linkReq(u) }
                    else -> ProfileScreen(
                        repo, hist, myList, favs, profileState,
                        onOpen = { detail = it }, onResume = resume, onRemove = removeContinue,
                        onUpdate = { scope.launch { repo.refresh(force = true) } },
                        onSwitch = switchServer, onAdd = { showAdd = true },
                        onRemoveServer = { sv -> scope.launch { repo.removeServer(sv.id); webs.remove(sv.id)?.view?.destroy(); detail = null } },
                        dl = dl, onPlayDl = { play = dl.playReq(it) }, onDeleteDl = { dl.remove(it) }, onRetryDl = { dl.retry(it) }
                    )
                }
            }
            TrioNavBar(tab) { tab = it }
        }
    }
    fileAction?.let { (u, mime) ->
        FileActionDialog(
            u, mime,
            onPlay = { fileAction = null; play = linkReq(u) },
            onDownload = { fileAction = null; downloadUrl(u) },
            onDismiss = { fileAction = null }
        )
    }
    if (showAdd) AddServerDialog(repo, onDismiss = { showAdd = false }) {
        showAdd = false
        search.q = ""; search.results = emptyList(); search.done = ""; search.filter = "All"
        detail = null; tab = 0
    }
}
