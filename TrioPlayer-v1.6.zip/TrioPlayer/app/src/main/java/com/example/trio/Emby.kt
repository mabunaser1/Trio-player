package com.example.trio

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.Dispatcher
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

class AuthException(msg: String) : IOException(msg)

/** one client for everything: connections are reused, which makes many small requests fast */
internal val HTTP: OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(6, TimeUnit.SECONDS).readTimeout(40, TimeUnit.SECONDS)
    .dispatcher(Dispatcher().apply { maxRequestsPerHost = 8 }).build()

private fun authHeader(store: Store) =
    "MediaBrowser Client=\"Trio Player\", Device=\"Android\", DeviceId=\"${store.deviceId}\", Version=\"1.0\""

class Auth(val url: String, val token: String, val uid: String)

object EmbyAuth {
    /** Returns the new session, or a message for the user. */
    suspend fun login(store: Store, url: String, user: String, pass: String): Pair<Auth?, String?> = withContext(Dispatchers.IO) {
        try {
            val b = store.normalize(url)
            if (b.isBlank()) return@withContext null to "Enter the server address"
            val body = JSONObject().put("Username", user).put("Pw", pass).toString().toRequestBody("application/json".toMediaType())
            val req = Request.Builder().url("$b/Users/AuthenticateByName").post(body)
                .header("X-Emby-Authorization", authHeader(store)).header("Authorization", authHeader(store)).build()
            HTTP.newCall(req).execute().use { r ->
                if (r.code == 401 || r.code == 400) return@withContext null to "Wrong username or password"
                if (!r.isSuccessful) return@withContext null to "The server answered HTTP ${r.code}"
                val o = JSONObject(r.body!!.string())
                Auth(b, o.getString("AccessToken"), o.getJSONObject("User").getString("Id")) to null
            }
        } catch (e: Exception) {
            null to "Cannot reach the server (${e.message ?: "network error"}). Are you on the right wifi?"
        }
    }
}

/**
 * Emby and Jellyfin share this API. One EmbySource per saved server. The whole catalog is downloaded in parallel pages
 * (without long descriptions), and the server's own "latest" lists are asked for in two tiny requests on every start.
 */
class EmbySource(private val store: Store, override val id: String) : Source {
    private val sv get() = store.server(id)
    override val name get() = sv?.name ?: id
    override val home get() = sv?.url ?: ""
    override val ready get() = sv?.token?.isNotBlank() == true

    private val base get() = sv?.url ?: ""
    private val token get() = sv?.token ?: ""
    private val uid get() = sv?.uid ?: ""

    private fun rawBody(path: String, params: Map<String, String>): String {
        val b = "$base$path".toHttpUrl().newBuilder()
        params.forEach { (k, v) -> b.addQueryParameter(k, v) }
        b.addQueryParameter("api_key", token)
        val req = Request.Builder().url(b.build()).header("X-Emby-Token", token).build()
        HTTP.newCall(req).execute().use { r ->
            if (r.code == 401) throw AuthException("Session expired")
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            return r.body!!.string()
        }
    }

    private suspend fun body(path: String, params: Map<String, String> = emptyMap()): String = withContext(Dispatchers.IO) {
        try { rawBody(path, params) }
        catch (e: AuthException) {
            // token no longer valid: sign in again with the saved account, then retry once
            val s = sv ?: throw e
            val (a, _) = EmbyAuth.login(store, s.url, s.user, s.pass)
            if (a == null) throw e
            store.upsertServer(s.copy(token = a.token, uid = a.uid))
            rawBody(path, params)
        }
    }
    private suspend fun get(path: String, params: Map<String, String> = emptyMap()) = JSONObject(body(path, params))
    private suspend fun getArr(path: String, params: Map<String, String> = emptyMap()) = JSONArray(body(path, params))

    private fun img(itemId: String, type: String, w: Int) = "$base/Items/$itemId/Images/$type?maxWidth=$w&quality=80&api_key=$token"

    private fun parseDate(s: String): Long = try {
        val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US); f.timeZone = TimeZone.getTimeZone("UTC")
        f.parse(s.take(19))?.time ?: 0L
    } catch (e: Exception) { 0L }

    private fun title(o: JSONObject): Title {
        val iid = o.getString("Id")
        val hasPoster = o.optJSONObject("ImageTags")?.has("Primary") == true
        val hasBackdrop = (o.optJSONArray("BackdropImageTags")?.length() ?: 0) > 0
        val g = o.optJSONArray("Genres")
        return Title(
            key = "$id:$iid", source = id, id = iid, name = o.optString("Name"),
            year = if (o.has("ProductionYear")) o.optInt("ProductionYear") else null,
            series = o.optString("Type") == "Series", overview = "",
            rating = o.optDouble("CommunityRating", 0.0),
            genres = if (g == null) emptyList() else (0 until g.length()).map { g.getString(it) },
            poster = if (hasPoster) img(iid, "Primary", 320) else null,
            backdrop = if (hasBackdrop) img(iid, "Backdrop", 1280) else null,
            added = parseDate(o.optString("DateCreated")),
            runtimeMin = (o.optLong("RunTimeTicks") / 600_000_000L).toInt()
        )
    }

    // no Overview here: the long texts are most of the download, and they are only needed on a title page
    private val fields = "Genres,CommunityRating,ProductionYear,DateCreated,RunTimeTicks"
    private val slim = mapOf("ImageTypeLimit" to "1", "EnableImageTypes" to "Primary,Backdrop")

    private suspend fun page(start: Int, limit: Int): Pair<List<Title>, Int> {
        val o = get(
            "/Users/$uid/Items", slim + mapOf(
                "IncludeItemTypes" to "Movie,Series", "Recursive" to "true", "Fields" to fields,
                "SortBy" to "DateCreated", "SortOrder" to "Descending", "EnableTotalRecordCount" to "true",
                "StartIndex" to "$start", "Limit" to "$limit"
            )
        )
        val items = o.optJSONArray("Items") ?: return emptyList<Title>() to 0
        val list = ArrayList<Title>(items.length())
        for (i in 0 until items.length()) list.add(title(items.getJSONObject(i)))
        return list to o.optInt("TotalRecordCount", start + list.size)
    }

    /** First page tells the total, the other pages are fetched four at a time. */
    override suspend fun catalog(onProgress: (Int, Int) -> Unit): List<Title> = coroutineScope {
        val (first, total) = page(0, 1000)
        val out = ArrayList<Title>(maxOf(total, first.size))
        out.addAll(first)
        onProgress(out.size, total)
        if (first.isNotEmpty() && out.size < total) {
            val n = first.size
            val gate = Semaphore(4)
            val jobs = (n until total step n).map { s -> async { gate.withPermit { page(s, n).first } } }
            for (j in jobs) { out.addAll(j.await()); onProgress(out.size, total) }
        }
        out
    }

    /** The server's own "recently added": (movies, series with new episodes), newest first. Two small requests. */
    override suspend fun latest(): Pair<List<Title>, List<Title>> = coroutineScope {
        val common = slim + mapOf("Fields" to fields, "GroupItems" to "true")
        val mj = async {
            try { getArr("/Users/$uid/Items/Latest", common + mapOf("IncludeItemTypes" to "Movie", "Limit" to "40")) }
            catch (e: AuthException) { throw e } catch (e: Exception) { JSONArray() }
        }
        val ej = async {
            try { getArr("/Users/$uid/Items/Latest", common + mapOf("IncludeItemTypes" to "Episode", "Limit" to "120")) }
            catch (e: AuthException) { throw e } catch (e: Exception) { JSONArray() }
        }
        val ma = mj.await()
        val movies = (0 until ma.length()).map { title(ma.getJSONObject(it)) }
        val sids = LinkedHashSet<String>()
        val ea = ej.await()
        for (i in 0 until ea.length()) {
            val o = ea.getJSONObject(i)
            val sid = if (o.optString("Type") == "Series") o.optString("Id") else o.optString("SeriesId")
            if (sid.isNotBlank()) sids.add(sid)
        }
        val ids = sids.take(60)
        val series = if (ids.isEmpty()) emptyList() else {
            val o = get("/Users/$uid/Items", slim + mapOf("Ids" to ids.joinToString(","), "Fields" to fields))
            val items = o.optJSONArray("Items")
            val byId = HashMap<String, Title>()
            if (items != null) for (i in 0 until items.length()) { val t = title(items.getJSONObject(i)); byId[t.id] = t }
            ids.mapNotNull { byId[it] }
        }
        movies to series
    }

    /** The server's own search over its whole library. */
    override suspend fun search(q: String): List<Title> {
        val o = get(
            "/Users/$uid/Items", slim + mapOf(
                "SearchTerm" to q, "IncludeItemTypes" to "Movie,Series", "Recursive" to "true",
                "Fields" to fields, "Limit" to "200"
            )
        )
        val items = o.optJSONArray("Items") ?: return emptyList()
        return (0 until items.length()).map { title(items.getJSONObject(it)) }
    }

    override suspend fun details(t: Title): String = get("/Users/$uid/Items/${t.id}").optString("Overview")

    override suspend fun episodes(t: Title): List<Episode> {
        val o = get("/Shows/${t.id}/Episodes", mapOf("userId" to uid, "Fields" to "Overview,RunTimeTicks"))
        val items = o.optJSONArray("Items") ?: return emptyList()
        return (0 until items.length()).map {
            val e = items.getJSONObject(it)
            val eid = e.getString("Id")
            val hasThumb = e.optJSONObject("ImageTags")?.has("Primary") == true
            Episode(
                eid, e.optString("Name"), e.optInt("ParentIndexNumber", 0), e.optInt("IndexNumber", 0),
                (e.optLong("RunTimeTicks") / 600_000_000L).toInt(), if (hasThumb) img(eid, "Primary", 480) else null, e.optString("Overview")
            )
        }.sortedWith(compareBy({ it.season }, { it.number }))
    }

    override suspend fun stream(t: Title, ep: Episode?): Stream {
        val itemId = ep?.id ?: t.id
        val o = get("/Users/$uid/Items/$itemId")
        val ms = o.optJSONArray("MediaSources")?.optJSONObject(0)
        val msId = ms?.optString("Id")?.ifBlank { null } ?: itemId
        val subs = ArrayList<SubTrack>()
        val streams = ms?.optJSONArray("MediaStreams")
        var vh = 0
        var vc = ""
        var eng = -1
        val b = base
        val tok = token
        if (streams != null) for (i in 0 until streams.length()) {
            val s = streams.getJSONObject(i)
            val type = s.optString("Type")
            if (type == "Video" && vh == 0) { vh = s.optInt("Height"); vc = s.optString("Codec") }
            if (type == "Audio" && eng < 0) {
                val l = s.optString("Language").lowercase()
                if (l == "eng" || l == "en" || s.optString("DisplayTitle").contains("english", true)) eng = s.optInt("Index")
            }
            if (type != "Subtitle" || !s.optBoolean("IsExternal")) continue
            if (s.has("IsTextSubtitleStream") && !s.optBoolean("IsTextSubtitleStream")) continue
            val codec = s.optString("Codec").lowercase()
            val ext = when (codec) { "ass", "ssa" -> "ass"; "vtt", "webvtt" -> "vtt"; else -> "srt" }
            val mime = when (ext) { "ass" -> "text/x-ssa"; "vtt" -> "text/vtt"; else -> "application/x-subrip" }
            val label = s.optString("DisplayTitle").ifBlank { s.optString("Language").ifBlank { "Subtitle ${i + 1}" } }
            subs.add(SubTrack(label, "$b/Videos/$itemId/$msId/Subtitles/${s.optInt("Index")}/0/Stream.$ext?api_key=$tok", s.optString("Language").ifBlank { null }, mime))
        }
        val direct = "$b/Videos/$itemId/stream?static=true&MediaSourceId=$msId&api_key=$tok"
        val devId = store.deviceId
        // the server converts the video to H.264/AAC at the chosen height and bitrate (needs transcoding enabled on that server)
        val transcode = { h: Int, kbps: Int ->
            "$b/Videos/$itemId/master.m3u8?MediaSourceId=$msId&VideoCodec=h264&AudioCodec=aac&TranscodingMaxAudioChannels=2" +
                "&SegmentContainer=ts&MaxHeight=$h&MaxWidth=${h * 16 / 9}&VideoBitRate=${kbps * 1000}&MaxStreamingBitrate=${(kbps + 192) * 1000}" +
                (if (eng >= 0) "&AudioStreamIndex=$eng" else "") +
                "&DeviceId=$devId&PlaySessionId=${System.currentTimeMillis()}&api_key=$tok"
        }
        val parts = ms?.optString("Container").orEmpty().lowercase().split(',').map { it.trim() }
        val ext = when {
            "mp4" in parts -> "mp4"
            "matroska" in parts || "mkv" in parts || parts.firstOrNull().isNullOrBlank() -> "mkv"
            else -> parts.first()
        }
        return Stream(direct, subs, ms?.optLong("Bitrate") ?: 0L, vh, vc, eng, ext, transcode)
    }
}
