package com.example.trio

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.view.ViewGroup
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private val VIDEO_EXT = setOf("mkv", "mp4", "avi", "m4v", "mov", "webm", "ts", "m2ts", "wmv", "flv", "mpg", "mpeg", "3gp", "m3u8")

fun isVideoUrl(u: String): Boolean {
    val p = u.substringBefore('?').substringBefore('#').lowercase()
    return VIDEO_EXT.any { p.endsWith(".$it") }
}

fun fileNameOf(u: String): String =
    Uri.decode(u.substringBefore('?').substringBefore('#').trimEnd('/').substringAfterLast('/')).ifBlank { "video" }

@Composable
fun DownloadIcon(tint: Color, dp: Dp) {
    Canvas(Modifier.size(dp)) {
        val w = this.size.width
        val h = this.size.height
        val sw = w * 0.1f
        drawLine(tint, Offset(w * 0.5f, h * 0.12f), Offset(w * 0.5f, h * 0.64f), sw, StrokeCap.Round)
        drawLine(tint, Offset(w * 0.28f, h * 0.44f), Offset(w * 0.5f, h * 0.66f), sw, StrokeCap.Round)
        drawLine(tint, Offset(w * 0.72f, h * 0.44f), Offset(w * 0.5f, h * 0.66f), sw, StrokeCap.Round)
        drawLine(tint, Offset(w * 0.2f, h * 0.86f), Offset(w * 0.8f, h * 0.86f), sw, StrokeCap.Round)
    }
}

/** One browser per open-site server, kept alive while you switch tabs so the page is still there when you come back. */
class WebHolder(val view: WebView) {
    var progress by mutableStateOf(0)
    var loading by mutableStateOf(false)
    var canBack by mutableStateOf(false)
    var canForward by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    /** (address, mime type) of a video or file the page wants to open */
    var onFile: (String, String) -> Unit = { _, _ -> }
    fun sync() { canBack = view.canGoBack(); canForward = view.canGoForward() }
}

@SuppressLint("SetJavaScriptEnabled")
fun createWeb(ctx: Context, url: String): WebHolder {
    val wv = WebView(ctx)
    val h = WebHolder(wv)
    wv.setBackgroundColor(android.graphics.Color.BLACK)
    wv.settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        useWideViewPort = true
        loadWithOverviewMode = true
        setSupportZoom(true)
        builtInZoomControls = true
        displayZoomControls = false
        mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        mediaPlaybackRequiresUserGesture = true
        allowFileAccess = false
    }
    wv.webViewClient = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val u = request.url.toString()
            if (isVideoUrl(u)) { h.onFile(u, ""); return true }       // a video file: Play / Download choice instead of a browser download
            return !u.startsWith("http", ignoreCase = true)            // block intent:, market:, tel: ... links
        }
        override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) { h.loading = true; h.error = null; h.sync() }
        override fun onPageFinished(view: WebView, url: String?) { h.loading = false; h.sync() }
        override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) { h.sync() }
        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (request.isForMainFrame) h.error = error.description?.toString() ?: "The page could not be loaded"
        }
    }
    wv.webChromeClient = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) { h.progress = newProgress }
    }
    // a link the site sends as a file download
    wv.setDownloadListener(DownloadListener { u, _, _, mime, _ -> h.onFile(u, mime ?: "") })
    // press and hold a link to a video
    wv.setOnLongClickListener { v ->
        val r = (v as WebView).hitTestResult
        val ex = r.extra
        if ((r.type == WebView.HitTestResult.SRC_ANCHOR_TYPE || r.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) && ex != null && isVideoUrl(ex)) {
            h.onFile(ex, ""); true
        } else false
    }
    wv.loadUrl(url)
    return h
}

/** The server's website inside the app: your own top bar, the site below it. Video files open a Play / Download choice. */
@Composable
fun WebSiteScreen(
    repo: Repo, holder: WebHolder, homeUrl: String,
    onSwitch: (String) -> Unit, onAdd: () -> Unit, onFile: (String, String) -> Unit
) {
    holder.onFile = onFile
    // a hidden page stops running (battery)
    DisposableEffect(holder) { holder.view.onResume(); onDispose { holder.view.onPause() } }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            ServerSwitcher(repo, onSwitch, onAdd)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { holder.view.goBack() }, enabled = holder.canBack) {
                Icon(Icons.Filled.ArrowBack, "Back", tint = if (holder.canBack) Color.White else Color(0xFF55555C))
            }
            IconButton(onClick = { holder.view.goForward() }, enabled = holder.canForward) {
                Icon(Icons.Filled.ArrowForward, "Forward", tint = if (holder.canForward) Color.White else Color(0xFF55555C))
            }
            IconButton(onClick = { holder.view.reload() }) { Icon(Icons.Filled.Refresh, "Reload", tint = Color.White) }
            IconButton(onClick = { holder.view.loadUrl(homeUrl) }) { Icon(Icons.Filled.Home, "Site home", tint = Color.White) }
        }
        Box(Modifier.fillMaxWidth().height(3.dp)) {
            if (holder.loading) LinearProgressIndicator(progress = { holder.progress / 100f }, color = RED_, trackColor = Color.Transparent, modifier = Modifier.fillMaxSize())
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                factory = { holder.view.also { (it.parent as? ViewGroup)?.removeView(it) } },
                modifier = Modifier.fillMaxSize()
            )
            holder.error?.let { msg ->
                Column(Modifier.fillMaxSize().background(BG).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("Can't open this page", fontSize = 18.sp)
                    Text(msg + "\nSome sites only work on their own network (for example BDIX).", Modifier.padding(top = 8.dp), color = Color(0xFF9A9A9A), textAlign = TextAlign.Center)
                    Button(onClick = { holder.error = null; holder.view.reload() }, modifier = Modifier.padding(top = 16.dp)) { Text("Try again") }
                }
            }
        }
    }
}

/** What to do with a video file found on a website. */
@Composable
fun FileActionDialog(url: String, mime: String, onPlay: () -> Unit, onDownload: () -> Unit, onDismiss: () -> Unit) {
    val name = remember(url) { fileNameOf(url) }
    val canPlay = isVideoUrl(url) || mime.startsWith("video/")
    val canDownload = !url.substringBefore('?').lowercase().endsWith(".m3u8")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(name, fontSize = 16.sp, maxLines = 3, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (canPlay) Button(onClick = onPlay, modifier = Modifier.fillMaxWidth()) { Text("▶  Play in Trio Player") }
                if (canDownload) OutlinedButton(onClick = onDownload, modifier = Modifier.fillMaxWidth()) {
                    DownloadIcon(Color.White, 20.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Download for offline")
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
