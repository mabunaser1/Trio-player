package com.example.trio

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch

val BG = Color(0xFF0A0A0A)
val RED_ = Color(0xFFE50914)

// ------------------------------------------------------------------ login

@Composable
fun LoginScreen(repo: Repo, onDone: () -> Unit, onSkip: () -> Unit) {
    val store = repo.store
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf(DEFAULT_URL) }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.Center) {
        Image(
            painterResource(R.drawable.logo), "Trio Player",
            Modifier.align(Alignment.CenterHorizontally).size(140.dp)
        )
        Text("Add a server (optional)", Modifier.padding(top = 12.dp), style = MaterialTheme.typography.titleMedium)
        Text("Emby / Jellyfin (with username), or just a movie website address (no login needed).", Modifier.padding(top = 4.dp, bottom = 16.dp), color = Color(0xFFB0B0B8), fontSize = 13.sp)
        OutlinedTextField(
            url, { url = it }, singleLine = true, label = { Text("Server address") }, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
        )
        OutlinedTextField(user, { user = it }, singleLine = true, label = { Text("Username (optional)") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        OutlinedTextField(
            pass, { pass = it }, singleLine = true, label = { Text("Password (optional)") }, visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
        error?.let { Text(it, Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.error) }
        Button(
            onClick = {
                busy = true; error = null
                scope.launch {
                    val e = repo.addServer("", url, user.trim(), pass)
                    busy = false
                    if (e == null) onDone() else error = e
                }
            },
            enabled = !busy && url.isNotBlank(), modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
        ) { Text(if (busy) "Connecting…" else if (user.isBlank()) "Connect" else "Sign in") }
        TextButton(onClick = onSkip, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Skip for now, just play links") }
        Text("The password stays on this phone only. Connect to the BDIX wifi first.", Modifier.padding(top = 12.dp), color = Color(0xFF8A8A92), fontSize = 12.sp)
    }
}

// ------------------------------------------------------------------ cards and rows

private val POSTER_GRADS = listOf(
    listOf(Color(0xFF42275A), Color(0xFF734B6D)), listOf(Color(0xFF134E5E), Color(0xFF3F8F6B)), listOf(Color(0xFF8E0E00), Color(0xFF3A1C18)),
    listOf(Color(0xFF141E30), Color(0xFF35577D)), listOf(Color(0xFF603813), Color(0xFFB27A4C)), listOf(Color(0xFF1D4350), Color(0xFFA43931))
)

@Composable
fun PosterCard(
    t: Title, modifier: Modifier = Modifier, progress: Float? = null, onRemove: (() -> Unit)? = null, tag: String? = null, onClick: () -> Unit
) {
    Column(modifier.clickable(onClick = onClick)) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (t.poster != null) {
                // fixed decode size + a stable cache key: no re-measuring, no re-downloading, smaller bitmaps
                val ctx = LocalContext.current
                val req = remember(t.poster) {
                    ImageRequest.Builder(ctx).data(t.poster).size(300, 450).memoryCacheKey("p:${t.key}").diskCacheKey("p:${t.key}").build()
                }
                AsyncImage(model = req, contentDescription = t.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
            else {
                val g = POSTER_GRADS[(t.key.hashCode() and 0x7fffffff) % POSTER_GRADS.size]
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(g)), contentAlignment = Alignment.Center) {
                    Text(t.name, Modifier.padding(8.dp), style = MaterialTheme.typography.labelLarge, maxLines = 5, textAlign = TextAlign.Center, color = Color.White)
                }
            }
            // series carry a small red mark
            if (t.series) Box(
                Modifier.align(Alignment.TopStart).padding(4.dp).background(RED_, RoundedCornerShape(4.dp)).padding(horizontal = 5.dp, vertical = 1.dp)
            ) { Text("SERIES", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
            if (onRemove != null) Box(
                Modifier.align(Alignment.TopEnd).padding(4.dp).size(28.dp).background(Color(0xCC000000), CircleShape).clickable(onClick = onRemove),
                contentAlignment = Alignment.Center
            ) { Text("✕", color = Color.White, fontSize = 13.sp) }
            else if (t.rating > 0) Text(
                t.ratingText,
                Modifier.align(Alignment.TopEnd).padding(4.dp).background(Color(0xAA000000), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp),
                style = MaterialTheme.typography.labelSmall
            )
            if (tag != null) Text(
                tag, Modifier.align(Alignment.BottomStart).padding(4.dp).background(Color(0xCC000000), RoundedCornerShape(4.dp)).padding(horizontal = 5.dp, vertical = 1.dp),
                color = Color.White, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (progress != null) LinearProgressIndicator(
                progress = { progress }, color = RED_, trackColor = Color(0x66FFFFFF),
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
            )
        }
        Text(t.name, Modifier.padding(top = 4.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium)
        Text(
            t.yearText,
            color = Color(0xFF8A8A92), style = MaterialTheme.typography.labelSmall, maxLines = 1
        )
    }
}

@Composable
fun PosterRow(title: String, list: List<Title>, onOpen: (Title) -> Unit) {
    if (list.isEmpty()) return
    Column(Modifier.padding(top = 16.dp)) {
        Text(title, Modifier.padding(horizontal = 16.dp, vertical = 6.dp), style = MaterialTheme.typography.titleMedium)
        LazyRow(state = rememberLazyListState(), contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.key }, contentType = { "poster" }) { t -> PosterCard(t, Modifier.width(112.dp)) { onOpen(t) } }
        }
    }
}

// ------------------------------------------------------------------ home

fun buildRows(titles: List<Title>, year: Int, latestM: List<String>, latestS: List<String>): List<Pair<String, List<Title>>> {
    val by = titles.associateBy { it.key }
    val out = ArrayList<Pair<String, List<Title>>>()
    val nm = latestM.mapNotNull { by[it] }
    val ns = latestS.mapNotNull { by[it] }
    if (nm.isNotEmpty()) out.add("Recently added movies" to nm.take(30))
    if (ns.isNotEmpty()) out.add("Recently added series" to ns.take(30))
    if (nm.isEmpty() && ns.isEmpty()) out.add("Recently added" to titles.sortedByDescending { it.added }.take(30))
    out.add("Latest releases" to titles.filter { (it.year ?: 0) >= year - 1 }.sortedWith(compareByDescending<Title> { it.year ?: 0 }.thenByDescending { it.rating }).take(30))
    out.add("Top rated" to titles.filter { it.rating >= 7.0 }.sortedByDescending { it.rating }.take(30))
    out.add("Movies" to titles.filter { !it.series }.sortedBy { it.key.hashCode() }.take(30))
    out.add("Series" to titles.filter { it.series }.sortedByDescending { it.added }.take(30))
    titles.flatMap { t -> t.genres.map { g -> g to t } }.groupBy({ it.first }, { it.second })
        .entries.sortedByDescending { it.value.size }.take(14)
        .forEach { out.add(it.key to it.value.sortedByDescending { t -> t.added }.take(30)) }
    return out.filter { it.second.isNotEmpty() }
}

fun continueOf(repo: Repo, hist: List<Hist>): List<Pair<Hist, Title>> =
    hist.filter { it.pos > 10_000 && !it.finished }
        .mapNotNull { h -> repo.byKey[h.titleKey]?.let { h to it } }.distinctBy { it.second.key }.take(20)

/** Continue watching: a progress bar on every card and a ✕ to remove it from the list. */
@Composable
fun ContinueRow(cont: List<Pair<Hist, Title>>, onResume: (Hist, Title) -> Unit, onRemove: (Title) -> Unit) {
    if (cont.isEmpty()) return
    Column(Modifier.padding(top = 16.dp)) {
        Text("Continue watching", Modifier.padding(horizontal = 16.dp, vertical = 6.dp), style = MaterialTheme.typography.titleMedium)
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(cont, key = { it.first.key }, contentType = { "poster" }) { (h, t) ->
                PosterCard(
                    t, Modifier.width(112.dp),
                    progress = if (h.dur > 0) (h.pos.toFloat() / h.dur).coerceIn(0f, 1f) else null,
                    onRemove = { onRemove(t) }
                ) { onResume(h, t) }
            }
        }
    }
}

/** Top-right chip on Home: the server you are in, tap to switch to another one or add a new one. */
@Composable
fun ServerSwitcher(repo: Repo, onSwitch: (String) -> Unit, onAdd: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xFF1F1F23)).clickable { open = true }.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(repo.activeServer?.name ?: "No server", Modifier.widthIn(max = 150.dp), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("  ▾", fontSize = 14.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            repo.servers.forEach { sv ->
                DropdownMenuItem(
                    text = { Text(sv.name + if (sv.id == repo.activeId) "   ✓" else "") },
                    onClick = { open = false; onSwitch(sv.id) }
                )
            }
            DropdownMenuItem(text = { Text("+ Add server") }, onClick = { open = false; onAdd() })
        }
    }
}

@Composable
fun HomeScreen(
    repo: Repo, rows: List<Pair<String, List<Title>>>, hist: List<Hist>, state: LazyListState,
    onOpen: (Title) -> Unit, onResume: (Hist, Title) -> Unit, onRemove: (Title) -> Unit,
    onSwitch: (String) -> Unit, onAdd: () -> Unit
) {
    val titles = repo.titles
    val cont = remember(hist, repo.byKey) { continueOf(repo, hist) }
    val hero = remember(titles, repo.latestM) {
        repo.latestM.firstNotNullOfOrNull { k -> repo.byKey[k]?.takeIf { it.backdrop != null } } ?: titles.firstOrNull { it.backdrop != null }
    }

    LazyColumn(Modifier.fillMaxSize(), state = state) {
        item {
            Row(Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.logo), "Trio Player", Modifier.height(44.dp).aspectRatio(1f))
                Spacer(Modifier.weight(1f))
                if (repo.servers.isNotEmpty()) ServerSwitcher(repo, onSwitch, onAdd)
            }
        }
        if (repo.refreshing) item {
            Text("Updating the library…", Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.labelMedium, color = Color(0xFF8A8A92))
        }
        if (titles.isEmpty() && !repo.refreshing && !repo.loading) item {
            Text(
                if (repo.servers.isEmpty()) "No server added. Use the Links tab to play any video link, or add a server in My Profile."
                else if (repo.lastError.isNotBlank()) "Could not load the library: ${repo.lastError}\nCheck your connection, then open My Profile and tap Update library."
                else "Your library is empty. Open My Profile and tap Update library.",
                Modifier.padding(16.dp)
            )
        }
        if (hero != null) item {
            Box(Modifier.fillMaxWidth().height(340.dp).background(MaterialTheme.colorScheme.surfaceVariant).clickable { onOpen(hero) }) {
                AsyncImage(model = hero.backdrop, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, BG))))
                Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                    Text(hero.name, style = MaterialTheme.typography.headlineMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Button(onClick = { onOpen(hero) }, modifier = Modifier.padding(top = 8.dp)) { Text("▶ Play") }
                }
            }
        }
        if (cont.isNotEmpty()) item { ContinueRow(cont, onResume, onRemove) }
        items(rows.size, key = { "$it:${rows[it].first}" }) { i -> PosterRow(rows[i].first, rows[i].second, onOpen) }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

// ------------------------------------------------------------------ search: saved catalog first, then the server's own search

/** Kept by the app (not by the screen) so opening a title and pressing back brings you to the same search. */
class SearchState {
    var q by mutableStateOf("")
    var filter by mutableStateOf("All")
    var all by mutableStateOf(false)   // search every saved server
    var results by mutableStateOf<List<Title>>(emptyList())
    var done = ""
}

fun matchesFilter(t: Title, f: String): Boolean = when (f) {
    "All" -> true
    "Movies" -> !t.series
    "Series" -> t.series
    else -> t.genres.any { it.equals(f, ignoreCase = true) }   // Anime and every genre folder
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        Modifier.clip(shape).background(if (selected) RED_ else Color(0xFF1F1F23))
            .border(1.dp, if (selected) RED_ else Color(0xFF3A3A3F), shape).clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) { Text(text, color = Color.White, fontSize = 14.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, maxLines = 1) }
}

@Composable
fun SearchScreen(repo: Repo, st: SearchState, grid: LazyGridState, onOpen: (Title) -> Unit) {
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    LaunchedEffect(st.q, st.all) {
        val s = st.q.trim()
        val tag = s + if (st.all) "|g" else ""
        if (tag == st.done) return@LaunchedEffect
        if (s.length < 2) { st.results = emptyList(); st.done = tag; busy = false; return@LaunchedEffect }
        try {
            val local = if (st.all) repo.globalLocal(s) else repo.localSearch(s)
            st.results = local
            delay(350)
            busy = true
            val remote = if (st.all) repo.globalRemote(s) else repo.serverSearch(s)
            val have = local.map { it.key }.toSet()
            st.results = local + remote.filter { it.key !in have }
            st.done = tag
        } finally { busy = false }
    }
    // folders: Movies, Series, Anime, then the library's most common genres
    val genres by produceState(emptyList<String>(), repo.titles) {
        val all = repo.titles
        value = withContext(Dispatchers.Default) {
            all.flatMap { it.genres }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }
                .map { it.key }.filter { g -> listOf("anime", "all", "movies", "series").none { g.equals(it, true) } }.take(14)
        }
    }
    val chips = listOf("All", "Movies", "Series", "Anime") + genres
    val q = st.q.trim()
    val shown = remember(st.results, st.filter, q, repo.titles) {
        if (q.length >= 2) st.results.filter { matchesFilter(it, st.filter) }
        else if (st.filter != "All") repo.titles.asSequence().filter { matchesFilter(it, st.filter) }.take(300).toList()
        else emptyList()
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            st.q, { st.q = it }, singleLine = true, label = { Text("Search movies, series, anime") },
            modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 12.dp),
            trailingIcon = { if (st.q.isNotEmpty()) IconButton(onClick = { st.q = "" }) { Icon(Icons.Filled.Clear, contentDescription = "Clear") } },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() })
        )
        if (repo.servers.size > 1) Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Search all servers", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(if (st.all) "Searching all ${repo.servers.size} servers" else "Only in ${repo.activeServer?.name ?: "this server"}", fontSize = 12.sp, color = Color(0xFF8A8A92))
            }
            Switch(checked = st.all, onCheckedChange = { st.all = it; repo.store.globalSearch = it })
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(chips, key = { it }) { c ->
                Chip(c, st.filter == c) { st.filter = c; scope.launch { grid.scrollToItem(0) } }
            }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 12.dp))
        if (q.length < 2 && st.filter == "All") Text("Search above, or pick a folder: Movies, Series, Anime or a genre.", Modifier.padding(16.dp), color = Color(0xFF8A8A92))
        else if (shown.isEmpty() && !busy) Text("Nothing found.", Modifier.padding(16.dp), color = Color(0xFF8A8A92))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(104.dp), state = grid, contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(shown, key = { it.key }, contentType = { "poster" }) { t ->
                PosterCard(t, tag = if (st.all) repo.servers.firstOrNull { it.id == t.source }?.name else null) { onOpen(t) }
            }
        }
    }
}

// ------------------------------------------------------------------ my profile: continue watching, my list, favourites, library

@Composable
fun ProfileSection(title: String, hint: String, list: List<Title>, onOpen: (Title) -> Unit) {
    if (list.isNotEmpty()) PosterRow(title, list, onOpen)
    else Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp)) {
        Text(title, Modifier.padding(vertical = 6.dp), style = MaterialTheme.typography.titleMedium)
        Text(hint, color = Color(0xFF8A8A92), fontSize = 13.sp)
    }
}

private val SERVER_GRADS = listOf(
    listOf(Color(0xFF8E0E1A), Color(0xFF2A0B0E)), listOf(Color(0xFF1F3C88), Color(0xFF0B1630)),
    listOf(Color(0xFF0F6B5C), Color(0xFF07211D)), listOf(Color(0xFF6A2C91), Color(0xFF1C0B2A))
)

@Composable
fun StatTile(count: Int, label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier.clip(shape).background(if (selected) Color(0x33E50914) else Color(0xFF1B1B1F))
            .border(1.5.dp, if (selected) RED_ else Color(0xFF2C2C31), shape).clickable(onClick = onClick).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("$count", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(label, fontSize = 12.sp, color = if (selected) Color.White else Color(0xFF9A9A9A), maxLines = 1)
    }
}

@Composable
fun ServerCard(sv: Server, index: Int, active: Boolean, count: Int, onClick: () -> Unit, onRemove: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        Modifier.width(184.dp).height(100.dp).clip(shape).background(Brush.linearGradient(SERVER_GRADS[index % SERVER_GRADS.size]))
            .border(if (active) 2.dp else 1.dp, if (active) RED_ else Color(0x33FFFFFF), shape).clickable(onClick = onClick)
    ) {
        Column(Modifier.align(Alignment.CenterStart).padding(start = 14.dp, end = 34.dp)) {
            Text(sv.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sv.url.substringAfter("//").trimEnd('/'), fontSize = 11.sp, color = Color(0xB3FFFFFF), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (active) (if (sv.type == "folder") "●  Active  ·  Website" else "●  Active  ·  $count titles") else if (sv.type == "folder") "Website" else "Tap to switch",
                Modifier.padding(top = 6.dp), fontSize = 12.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                color = if (active) Color.White else Color(0xB3FFFFFF)
            )
        }
        Box(Modifier.align(Alignment.TopEnd).size(40.dp).clickable(onClick = onRemove), contentAlignment = Alignment.Center) {
            Text("✕", color = Color(0xB3FFFFFF), fontSize = 14.sp)
        }
    }
}

@Composable
fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, onClick: (() -> Unit)?, content: @Composable () -> Unit = {}) {
    Column(Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).background(Color(0x33E50914), CircleShape), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Column(Modifier.padding(start = 14.dp)) {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(sub, fontSize = 12.sp, color = Color(0xFF9A9A9A))
            }
        }
        content()
    }
}

/** One download: tap to watch when it is finished, ✕ to delete the file. */
@Composable
fun DownloadRow(i: DlItem, onPlay: (DlItem) -> Unit, onDelete: (DlItem) -> Unit, onRetry: (DlItem) -> Unit) {
    Row(
        Modifier.fillMaxWidth().then(if (i.complete) Modifier.clickable { onPlay(i) } else Modifier).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            Modifier.width(110.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(8.dp)).background(Color(0xFF1F1F23)),
            contentAlignment = Alignment.Center
        ) {
            if (i.dl.poster != null) AsyncImage(model = i.dl.poster, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            if (i.complete) Box(Modifier.size(34.dp).border(2.dp, Color.White, CircleShape).background(Color(0x66000000), CircleShape), contentAlignment = Alignment.Center) {
                Text("▶", color = Color.White, fontSize = 14.sp)
            }
        }
        Column(Modifier.weight(1f)) {
            Text(i.dl.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            if (i.dl.sub.isNotBlank()) Text(i.dl.sub, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = Color(0xFF9A9A9A))
            when {
                i.complete -> Text("Ready to watch offline" + if (i.total > 0) "  ·  ${fmtBytes(i.total)}" else "", fontSize = 12.sp, color = Color(0xFF46D369), modifier = Modifier.padding(top = 4.dp))
                i.failed -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Download failed", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = { onRetry(i) }) { Text("Retry", fontSize = 12.sp) }
                }
                else -> Column(Modifier.padding(top = 6.dp)) {
                    if (i.total > 0) LinearProgressIndicator(progress = { i.progress }, color = RED_, trackColor = Color(0x33FFFFFF), modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(color = RED_, trackColor = Color(0x33FFFFFF), modifier = Modifier.fillMaxWidth())
                    Text(
                        if (i.total > 0) "${(i.progress * 100).toInt()}%  ·  ${fmtBytes(i.done)} of ${fmtBytes(i.total)}" else "Waiting to start…",
                        fontSize = 12.sp, color = Color(0xFF9A9A9A), modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
        Box(Modifier.size(40.dp).clickable { onDelete(i) }, contentAlignment = Alignment.Center) { Text("✕", color = Color(0xFF8A8A92)) }
    }
}

private class Cell(val t: Title, val progress: Float?, val onRemove: (() -> Unit)?, val onClick: () -> Unit)

@Composable
fun ProfileScreen(
    repo: Repo, hist: List<Hist>, myList: List<String>, favs: List<String>, state: LazyListState,
    onOpen: (Title) -> Unit, onResume: (Hist, Title) -> Unit, onRemove: (Title) -> Unit,
    onUpdate: () -> Unit, onSwitch: (String) -> Unit, onAdd: () -> Unit, onRemoveServer: (Server) -> Unit,
    dl: Downloads, onPlayDl: (DlItem) -> Unit, onDeleteDl: (DlItem) -> Unit, onRetryDl: (DlItem) -> Unit
) {
    val fmt = remember { java.text.SimpleDateFormat("d MMM yyyy, HH:mm", java.util.Locale.getDefault()) }
    val cont = remember(hist, repo.byKey) { continueOf(repo, hist) }
    val mine = remember(myList, repo.byKey) { myList.mapNotNull { repo.byKey[it] } }
    val fav = remember(favs, repo.byKey) { favs.mapNotNull { repo.byKey[it] } }
    val sv = repo.activeServer
    val name = sv?.user?.ifBlank { null } ?: sv?.name ?: "Guest"
    var sec by rememberSaveable { mutableStateOf(0) }
    var quality by remember { mutableStateOf(repo.store.quality) }
    var confirm by remember { mutableStateOf<Server?>(null) }
    confirm?.let { c ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Remove ${c.name}?") },
            text = { Text("The server is taken out of the app. Nothing is deleted on the server itself.") },
            confirmButton = { TextButton(onClick = { confirm = null; onRemoveServer(c) }) { Text("Remove") } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }
    val cells: List<Cell> = when (sec) {
        0 -> cont.map { (h, t) -> Cell(t, if (h.dur > 0) (h.pos.toFloat() / h.dur).coerceIn(0f, 1f) else null, { onRemove(t) }) { onResume(h, t) } }
        1 -> mine.map { t -> Cell(t, null, null) { onOpen(t) } }
        2 -> fav.map { t -> Cell(t, null, null) { onOpen(t) } }
        else -> emptyList()
    }
    val gridRows = cells.chunked(3)

    LazyColumn(Modifier.fillMaxSize(), state = state) {
        item {
            Column(
                Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF3B0A0F), BG))).padding(start = 16.dp, end = 16.dp, top = 24.dp, bottom = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(76.dp).border(3.dp, Color(0x55FFFFFF), CircleShape)
                            .background(Brush.linearGradient(listOf(RED_, Color(0xFF7A0710))), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Text(name.take(1).uppercase(), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold) }
                    Column(Modifier.padding(start = 16.dp)) {
                        Text(name, style = MaterialTheme.typography.headlineSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(sv?.name ?: "No server yet", color = Color(0xFFB0B0B8), style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Row(Modifier.padding(top = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatTile(cont.size, "Continue", sec == 0, Modifier.weight(1f)) { sec = 0 }
                    StatTile(mine.size, "My List", sec == 1, Modifier.weight(1f)) { sec = 1 }
                    StatTile(fav.size, "Favourites", sec == 2, Modifier.weight(1f)) { sec = 2 }
                    StatTile(dl.items.size, "Downloads", sec == 3, Modifier.weight(1f)) { sec = 3 }
                }
            }
        }
        if (cells.isEmpty() && sec != 3) item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(if (sec == 2) Icons.Filled.FavoriteBorder else Icons.Filled.Search, contentDescription = null, tint = Color(0xFF55555C), modifier = Modifier.size(48.dp))
                Text(
                    when (sec) { 0 -> "Nothing in progress.\nAnything you start watching appears here."; 1 -> "Your list is empty.\nTap + My List on any title."; else -> "No favourites yet.\nTap the heart on any title." },
                    Modifier.padding(top = 12.dp), color = Color(0xFF8A8A92), textAlign = TextAlign.Center
                )
            }
        }
        items(gridRows.size, key = { "g$sec:${gridRows[it].first().t.key}" }) { i ->
            val r = gridRows[i]
            Row(Modifier.padding(start = 12.dp, end = 12.dp, top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (k in 0 until 3) {
                    if (k < r.size) PosterCard(r[k].t, Modifier.weight(1f), progress = r[k].progress, onRemove = r[k].onRemove, onClick = r[k].onClick)
                    else Spacer(Modifier.weight(1f))
                }
            }
        }
        if (sec == 3) {
            if (dl.items.isEmpty()) item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    DownloadIcon(Color(0xFF55555C), 48.dp)
                    Text(
                        "No downloads yet.\nTap Download on a movie or episode, or press and hold a video link on a website.",
                        Modifier.padding(top = 12.dp), color = Color(0xFF8A8A92), textAlign = TextAlign.Center
                    )
                }
            }
            items(dl.items, key = { it.dl.did }) { i -> DownloadRow(i, onPlayDl, onDeleteDl, onRetryDl) }
        }
        item {
            Text("Servers", Modifier.padding(start = 16.dp, end = 16.dp, top = 32.dp, bottom = 4.dp), style = MaterialTheme.typography.titleMedium)
            Text(
                "Each server works like its own app, with its own Home, search, list and history.",
                Modifier.padding(horizontal = 16.dp), fontSize = 12.sp, color = Color(0xFF9A9A9A)
            )
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                itemsIndexed(repo.servers, key = { _, x -> x.id }) { n, x ->
                    ServerCard(x, n, x.id == repo.activeId, repo.titles.size, { onSwitch(x.id) }) { confirm = x }
                }
                item {
                    Box(
                        Modifier.width(184.dp).height(100.dp).clip(RoundedCornerShape(16.dp)).border(1.5.dp, Color(0xFF3A3A3F), RoundedCornerShape(16.dp)).clickable(onClick = onAdd),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("+", fontSize = 30.sp, color = Color.White)
                            Text("Add server", fontSize = 13.sp, color = Color(0xFFB0B0B8))
                        }
                    }
                }
            }
        }
        item {
            val last = sv?.let { repo.store.lastRefresh(it.id) } ?: 0L
            Column(Modifier.padding(horizontal = 16.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF1B1B1F))) {
                if (sv != null && sv.type == "folder") SettingRow(
                    Icons.Filled.Refresh, "Website server", "This site is browsed live inside the app, so there is nothing to update.", null
                ) else SettingRow(
                    Icons.Filled.Refresh, "Update library",
                    if (sv == null) "Add a server first" else if (repo.refreshing) "Updating…  ${repo.progress}"
                    else "Last full update: " + (if (last > 0) fmt.format(java.util.Date(last)) else "never") + ". New titles are checked every time you open the app.",
                    if (sv != null && !repo.refreshing) onUpdate else null
                )
                if (sv != null && sv.type != "folder") SettingRow(Icons.Filled.Settings, "Video quality", "Used when a video starts. Auto picks the best for your network.", null) {
                    LazyRow(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf("auto" to "Auto", "orig" to "Original", "1080" to "1080p", "720" to "720p", "480" to "480p"), key = { it.first }) { (v, label) ->
                            Chip(label, quality == v) { quality = v; repo.store.quality = v }
                        }
                    }
                }
            }
            if (repo.lastError.isNotBlank()) Text("Last error: ${repo.lastError}", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(28.dp))
        }
    }
}

/** Add another server: it gets its own Home, search, list and history, and you can switch between them. */
@Composable
fun AddServerDialog(repo: Repo, onDismiss: () -> Unit, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Add a server") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Name (optional)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    url, { url = it }, singleLine = true, label = { Text("Server address") }, placeholder = { Text("http://host:8096") },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                )
                OutlinedTextField(user, { user = it }, singleLine = true, label = { Text("Username (optional)") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                OutlinedTextField(
                    pass, { pass = it }, singleLine = true, label = { Text("Password (optional)") }, visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
                error?.let { Text(it, Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.error) }
                Text("Movie website (FTP style): just the address, leave username and password empty. It opens inside the app like a browser, and videos can be played or downloaded. Emby / Jellyfin: add your username and password.", Modifier.padding(top = 8.dp), color = Color(0xFF8A8A92), fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy && url.isNotBlank(),
                onClick = {
                    busy = true; error = null
                    scope.launch {
                        val e = repo.addServer(name, url, user.trim(), pass)
                        busy = false
                        if (e == null) onDone() else error = e
                    }
                }
            ) { Text(if (busy) "Connecting…" else "Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !busy) { Text("Cancel") } }
    )
}

// ------------------------------------------------------------------ bottom bar

@Composable
fun LinkIcon(tint: Color, dp: Dp) {
    Canvas(Modifier.size(dp)) {
        val w = this.size.width; val h = this.size.height
        val stroke = Stroke(width = w * 0.11f)
        rotate(-45f, Offset(w / 2, h / 2)) {
            drawRoundRect(tint, Offset(w * 0.02f, h * 0.34f), Size(w * 0.56f, h * 0.32f), CornerRadius(h * 0.16f), style = stroke)
            drawRoundRect(tint, Offset(w * 0.42f, h * 0.34f), Size(w * 0.56f, h * 0.32f), CornerRadius(h * 0.16f), style = stroke)
        }
    }
}

/** Black bar, big icons, the open tab sits in a red glow and its label turns white. */
@Composable
fun TrioNavBar(tab: Int, onTab: (Int) -> Unit) {
    val labels = listOf("Home", "Search", "Links", "My Profile")
    Row(Modifier.fillMaxWidth().background(Color.Black).navigationBarsPadding().height(62.dp)) {
        labels.forEachIndexed { i, label ->
            val sel = tab == i
            val tint by animateColorAsState(if (sel) Color.White else Color(0xFF8A8A92), label = "navTint")
            val pill by animateColorAsState(if (sel) Color(0x66E50914) else Color.Transparent, label = "navPill")
            Column(
                Modifier.weight(1f).fillMaxHeight()
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onTab(i) },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                Box(Modifier.width(56.dp).height(30.dp).clip(RoundedCornerShape(15.dp)).background(pill), contentAlignment = Alignment.Center) {
                    when (i) {
                        0 -> Icon(Icons.Filled.Home, contentDescription = label, tint = tint, modifier = Modifier.size(26.dp))
                        1 -> Icon(Icons.Filled.Search, contentDescription = label, tint = tint, modifier = Modifier.size(26.dp))
                        2 -> LinkIcon(tint, 24.dp)
                        else -> Icon(Icons.Filled.Person, contentDescription = label, tint = tint, modifier = Modifier.size(26.dp))
                    }
                }
                Text(label, Modifier.padding(top = 2.dp), color = tint, fontSize = 11.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
            }
        }
    }
}

// ------------------------------------------------------------------ title page (movie, or series with a season drop-down)

@Composable
fun DetailScreen(
    t: Title, repo: Repo, hist: List<Hist>, inList: Boolean, inFav: Boolean,
    onToggleList: () -> Unit, onToggleFav: () -> Unit, onPlay: (PlayReq) -> Unit, onBack: () -> Unit,
    dl: Downloads, onDownload: (Title, Episode?) -> Unit
) {
    BackHandler(onBack = onBack)
    var confirmSeason by remember { mutableStateOf(false) }
    var eps by remember(t.key) { mutableStateOf<List<Episode>>(emptyList()) }
    var loading by remember(t.key) { mutableStateOf(t.series) }
    var loadErr by remember(t.key) { mutableStateOf<String?>(null) }
    var season by remember(t.key) { mutableStateOf<Int?>(null) }
    var showSeasons by remember { mutableStateOf(false) }
    var overview by remember(t.key) { mutableStateOf(t.overview) }
    LaunchedEffect(t.key) {
        if (overview.isBlank()) try { overview = repo.details(t) } catch (e: Exception) { }
    }

    LaunchedEffect(t.key) {
        if (!t.series) return@LaunchedEffect
        try { eps = repo.episodes(t) } catch (e: Exception) { loadErr = e.message ?: "Could not load episodes" }
        loading = false
    }
    val bySeason = remember(eps) { eps.groupBy { it.season }.toSortedMap() }
    val last = remember(hist, t.key) { hist.firstOrNull { it.titleKey == t.key && it.epId != null && !it.finished } }
    val curSeason = season ?: last?.let { h -> eps.firstOrNull { it.id == h.epId }?.season } ?: bySeason.keys.firstOrNull { it > 0 } ?: bySeason.keys.firstOrNull()
    val resumeEp = last?.let { h -> eps.firstOrNull { it.id == h.epId } } ?: eps.firstOrNull { it.season > 0 } ?: eps.firstOrNull()
    fun play(e: Episode?) = onPlay(PlayReq(t, eps, e))

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Box(Modifier.fillMaxWidth().height(260.dp).background(MaterialTheme.colorScheme.surfaceVariant)) {
                val art = t.backdrop ?: t.poster
                if (art != null) AsyncImage(model = art, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x66000000), Color.Transparent, BG))))
                TextButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).statusBarsPadding()) { Text("← Back") }
                Box(
                    Modifier.align(Alignment.Center).size(72.dp).border(3.dp, RED_, CircleShape).background(Color(0x55000000), CircleShape)
                        .clickable { if (t.series) play(resumeEp) else play(null) },
                    contentAlignment = Alignment.Center
                ) { Text("▶", color = Color.White, fontSize = 30.sp) }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text(t.name, style = MaterialTheme.typography.headlineSmall)
                val meta = listOfNotNull(
                    t.year?.toString(), t.rating.takeIf { it > 0 }?.let { "★ %.1f".format(it) },
                    t.runtimeMin.takeIf { it > 0 && !t.series }?.let { "${it}m" },
                    if (t.series && bySeason.isNotEmpty()) "${bySeason.keys.count { it > 0 }.coerceAtLeast(1)} season(s)" else null,
                    t.genres.take(3).joinToString(", ").ifBlank { null }
                ).joinToString("  ·  ")
                Text(meta, Modifier.padding(top = 4.dp), style = MaterialTheme.typography.labelMedium, color = Color(0xFFB0B0B8))
                Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { if (t.series) play(resumeEp) else play(null) }, enabled = !t.series || resumeEp != null,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            if (last != null) "▶ Resume" + (resumeEp?.let { "  S${it.season} E${it.number}" } ?: "")
                            else if (!t.series && hist.any { it.key == t.key && !it.finished }) "▶ Resume" else "▶ Play"
                        )
                    }
                    OutlinedButton(onClick = onToggleFav, contentPadding = PaddingValues(horizontal = 14.dp)) {
                        Icon(
                            if (inFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, contentDescription = "Favourite",
                            tint = if (inFav) RED_ else Color.White
                        )
                    }
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = onToggleList, modifier = Modifier.weight(1f)) { Text(if (inList) "✓ My List" else "+ My List") }
                    if (!t.series) {
                        val d = dl.find(t.key, "")
                        OutlinedButton(onClick = { onDownload(t, null) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp)) {
                            DownloadIcon(if (d?.complete == true) Color(0xFF46D369) else Color.White, 20.dp)
                            Spacer(Modifier.width(6.dp))
                            Text(
                                when {
                                    d == null -> "Download"
                                    d.complete -> "Play offline"
                                    d.failed -> "Retry download"
                                    else -> "Downloading ${(d.progress * 100).toInt()}%"
                                },
                                maxLines = 1
                            )
                        }
                    } else if (eps.isNotEmpty() && curSeason != null) {
                        OutlinedButton(onClick = { confirmSeason = true }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp)) {
                            DownloadIcon(Color.White, 20.dp)
                            Spacer(Modifier.width(6.dp))
                            Text("Download ${seasonName(curSeason)}", maxLines = 1)
                        }
                    }
                }
                if (overview.isNotBlank()) Text(overview, Modifier.padding(top = 12.dp), style = MaterialTheme.typography.bodyMedium)
            }
        }
        if (t.series) {
            if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth().padding(16.dp)) }
            loadErr?.let { m -> item { Text(m, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error) } }
            if (bySeason.isNotEmpty() && curSeason != null) {
                item {
                    val n = bySeason[curSeason]?.size ?: 0
                    Box(
                        Modifier.padding(16.dp).background(Color(0xFF1F1F23), RoundedCornerShape(8.dp)).border(1.dp, Color(0x55E50914), RoundedCornerShape(8.dp))
                            .clickable { showSeasons = true }.padding(horizontal = 16.dp, vertical = 12.dp)
                    ) { Text("${seasonName(curSeason)} ($n EP)   ⌄", fontSize = 17.sp) }
                }
                val list = bySeason[curSeason].orEmpty()
                items(list, key = { it.id }) { e ->
                    val h = hist.firstOrNull { it.epId == e.id }
                    Row(
                        Modifier.fillMaxWidth().clickable { play(e) }.padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(Modifier.width(150.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                            if (e.thumb != null) AsyncImage(model = e.thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            Box(Modifier.align(Alignment.Center).size(36.dp).border(2.dp, Color.White, CircleShape).background(Color(0x66000000), CircleShape), contentAlignment = Alignment.Center) {
                                Text("▶", color = Color.White, fontSize = 14.sp)
                            }
                            if (h != null && h.dur > 0) LinearProgressIndicator(
                                progress = { (h.pos.toFloat() / h.dur).coerceIn(0f, 1f) }, color = RED_, trackColor = Color(0x66FFFFFF),
                                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                            )
                        }
                        Column(Modifier.weight(1f)) {
                            Text("${e.number}. ${e.name}", maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
                            Text(
                                listOfNotNull("E${e.number}", "S${e.season}", e.runtimeMin.takeIf { it > 0 }?.let { "${it}m" }).joinToString("  ·  "),
                                color = Color(0xFF8A8A92), style = MaterialTheme.typography.labelMedium
                            )
                            if (e.overview.isNotBlank()) Text(e.overview, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = Color(0xFFB0B0B8))
                        }
                        val d = dl.find(t.key, e.id)
                        Box(Modifier.size(44.dp).clickable { onDownload(t, e) }, contentAlignment = Alignment.Center) {
                            when {
                                d == null -> DownloadIcon(Color.White, 22.dp)
                                d.complete -> Text("✓", color = Color(0xFF46D369), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                d.failed -> Text("!", color = MaterialTheme.colorScheme.error, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                else -> CircularProgressIndicator(progress = { d.progress }, color = RED_, trackColor = Color(0x33FFFFFF), strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
                            }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(32.dp)) }
    }

    if (confirmSeason && curSeason != null) {
        val list = bySeason[curSeason].orEmpty()
        AlertDialog(
            onDismissRequest = { confirmSeason = false },
            title = { Text("Download ${seasonName(curSeason)}?") },
            text = { Text("${list.size} episodes will be saved on this phone for offline watching. Episodes already downloaded are skipped.") },
            confirmButton = { TextButton(onClick = { confirmSeason = false; list.forEach { e -> if (dl.find(t.key, e.id) == null) onDownload(t, e) } }) { Text("Download") } },
            dismissButton = { TextButton(onClick = { confirmSeason = false }) { Text("Cancel") } }
        )
    }

    if (showSeasons) {
        AlertDialog(
            onDismissRequest = { showSeasons = false },
            containerColor = Color.White, shape = RoundedCornerShape(4.dp),
            confirmButton = {},
            text = {
                LazyColumn {
                    items(bySeason.keys.toList()) { s ->
                        Row(
                            Modifier.fillMaxWidth().clickable { season = s; showSeasons = false }.padding(vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${seasonName(s)} (${bySeason[s]?.size ?: 0} EP)", Modifier.weight(1f), color = Color(0xFF202020), fontSize = 20.sp)
                            RadioButton(selected = s == curSeason, onClick = { season = s; showSeasons = false })
                        }
                        HorizontalDivider(color = Color(0xFFE0E0E0))
                    }
                }
            }
        )
    }
}

fun seasonName(s: Int) = if (s == 0) "Specials" else "Season $s"
