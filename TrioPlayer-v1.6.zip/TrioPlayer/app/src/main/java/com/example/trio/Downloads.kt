package com.example.trio

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** A download you started. The file itself and its progress are kept by Android's DownloadManager. */
data class Dl(
    val did: Long, val url: String, val fileName: String, val name: String, val sub: String,
    val poster: String?, val key: String, val epId: String
)

class DlItem(val dl: Dl, val status: Int, val done: Long, val total: Long, val uri: String?) {
    val complete get() = status == DownloadManager.STATUS_SUCCESSFUL
    val failed get() = status == DownloadManager.STATUS_FAILED
    val progress: Float get() = if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f
}

fun fmtBytes(b: Long): String =
    if (b >= 1_000_000_000L) "%.1f GB".format(b / 1_000_000_000.0) else "${(b / 1_000_000L).coerceAtLeast(0)} MB"

/**
 * Offline videos. Android's own download service does the work, so downloads continue with the app closed, resume after a
 * network break, and show a notification. Files live in the app's own movie folder (no storage permission, removed with the app).
 */
class Downloads(private val ctx: Context) {
    private val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    private val sp = ctx.getSharedPreferences("trio_dl", Context.MODE_PRIVATE)

    var items by mutableStateOf<List<DlItem>>(emptyList())
    /** something is still downloading: the screen polls for progress only while this is true */
    var active by mutableStateOf(false)

    private fun load(): List<Dl> {
        val a = try { JSONArray(sp.getString("list", "[]") ?: "[]") } catch (e: Exception) { JSONArray() }
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Dl(o.getLong("d"), o.optString("u"), o.optString("f"), o.optString("n"), o.optString("s"), o.optString("p").ifBlank { null }, o.optString("k"), o.optString("e"))
        }
    }
    private fun save(l: List<Dl>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("d", it.did).put("u", it.url).put("f", it.fileName).put("n", it.name).put("s", it.sub).put("p", it.poster ?: "").put("k", it.key).put("e", it.epId)) }
        sp.edit().putString("list", a.toString()).apply()
    }

    /** reads the state of every download from Android */
    fun refresh() {
        val list = load()
        if (list.isEmpty()) { items = emptyList(); active = false; return }
        val found = HashMap<Long, DlItem>()
        val byId = list.associateBy { it.did }
        try {
            dm.query(DownloadManager.Query().setFilterById(*list.map { it.did }.toLongArray()))?.use { c ->
                val iId = c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)
                val iSt = c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)
                val iDone = c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                val iTot = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                val iUri = c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    val d = byId[id] ?: continue
                    found[id] = DlItem(d, c.getInt(iSt), c.getLong(iDone), c.getLong(iTot), c.getString(iUri))
                }
            }
        } catch (e: Exception) { return }
        // removed in Android's own Downloads screen = gone here too
        val kept = list.filter { it.did in found }
        if (kept.size != list.size) save(kept)
        items = kept.mapNotNull { found[it.did] }
        active = items.any { !it.complete && !it.failed }
    }

    fun find(key: String, epId: String): DlItem? = items.firstOrNull { it.dl.key == key && it.dl.epId == epId }

    /** returns the download id, or -1 when it could not be started */
    fun enqueue(url: String, fileName: String, name: String, sub: String, poster: String?, key: String, epId: String): Long {
        val safe = fileName.replace(Regex("""[\\/:*?"<>|]"""), " ").replace(Regex("\\s+"), " ").trim().take(120).ifBlank { "video.mkv" }
        return try {
            val req = DownloadManager.Request(Uri.parse(url)).setTitle(name).setDescription(sub.ifBlank { "Trio Player" })
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(ctx, Environment.DIRECTORY_MOVIES, "Trio/$safe")
            val id = dm.enqueue(req)
            save(listOf(Dl(id, url, safe, name, sub, poster, key, epId)) + load())
            refresh()
            id
        } catch (e: Exception) { -1L }
    }

    fun remove(i: DlItem) {
        try { dm.remove(i.dl.did) } catch (e: Exception) { }
        save(load().filter { it.did != i.dl.did })
        refresh()
    }

    fun retry(i: DlItem) {
        val d = i.dl
        remove(i)
        enqueue(d.url, d.fileName, d.name, d.sub, d.poster, d.key, d.epId)
    }

    /** plays the finished file with the normal player */
    fun playReq(i: DlItem): PlayReq = PlayReq(
        Title("$LINK_SOURCE:dl${i.dl.did}", LINK_SOURCE, i.uri ?: "", i.dl.name + (if (i.dl.sub.isNotBlank()) "  ·  ${i.dl.sub}" else ""),
            null, false, "", 0.0, emptyList(), i.dl.poster, null, 0L, 0),
        emptyList(), null
    )
}
