package com.example.trio

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

// ------------------------------------------------------------------ finding the videos a page plays

private val MEDIA_RE = Regex("""\.(m3u8|mpd|mp4|m4v|mkv|webm|mov|flv|avi|3gp)(?![A-Za-z0-9])""", RegexOption.IGNORE_CASE)

/** advertising and tracking hosts that serve small video clips: never shown as "the video of the page" */
private val NOISE = listOf("googlevideo.com", "doubleclick.net", "googlesyndication", "adservice", "/ads/", "analytics")

/** "HLS", "DASH", "MP4" ... when this web address is a video or a video playlist, else null */
fun sniffKind(u: String): String? {
    if (!u.startsWith("http", ignoreCase = true)) return null
    val l = u.lowercase()
    if (NOISE.any { l.contains(it) }) return null
    val m = MEDIA_RE.find(l) ?: return null
    return when (val e = m.groupValues[1]) {
        "m3u8" -> "HLS"
        "mpd" -> "DASH"
        else -> e.uppercase()
    }
}

fun extOf(u: String): String = MEDIA_RE.find(u.lowercase())?.groupValues?.get(1) ?: "mp4"

/** A video the page asked for, with the headers the page's own player sent along. */
class Sniffed(val url: String, val kind: String, val headers: Map<String, String>) {
    /** HLS / DASH are many small pieces: they play, but cannot be saved as one file by Android's download service */
    val streamOnly: Boolean get() = kind == "HLS" || kind == "DASH"
}

fun fixUrl(s: String): String {
    val t = s.trim()
    return when {
        t.startsWith("http://", true) || t.startsWith("https://", true) -> t
        t.contains(' ') || !t.contains('.') -> "https://www.google.com/search?q=" + Uri.encode(t)
        else -> "https://$t"
    }
}

// ------------------------------------------------------------------ the browser itself

private const val WEB_JS = """
function lab(e){return (e.innerText||'').replace(/\s+/g,' ').trim()}
function cards(){var map={},order=[],all=document.body.querySelectorAll('*');
 for(var i=0;i<all.length;i++){var e=all[i];if(e.children.length>0)continue;var t=(e.textContent||'').trim();
  var m=/^S(\d{1,2})\s*E(\d{1,3})\b/i.exec(t);if(!m||t.length>40)continue;
  var c=e;while(c.parentElement&&c.parentElement!==document.body){var p=c.parentElement,pt=p.innerText||'';
   if((pt.match(/S\d{1,2}\s*E\d{1,3}/gi)||[]).length!==1||pt.length>600)break;c=p}
  var k=(+m[1])+'x'+(+m[2]);map[k]=c;if(order.indexOf(k)<0)order.push(k)}
 return order.map(function(k){return map[k]})}
function quals(){var out=[],seen=[],all=document.body.querySelectorAll('*');
 for(var i=0;i<all.length;i++){var e=all[i];if(e.children.length>0)continue;var t=(e.textContent||'').trim();
  if(!/^Q\d{1,2}$/.test(t))continue;var c=e;
  while(c.parentElement&&c.parentElement!==document.body){var p=c.parentElement,pt=p.innerText||'';
   if((pt.match(/\bQ\d{1,2}\b/g)||[]).length!==1||pt.length>150)break;c=p}
  if(seen.indexOf(c)<0){seen.push(c);out.push(c)}}
 return out}
function isOn(c){var m=/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/.exec(getComputedStyle(c).backgroundColor||'');
 if(!m)return false;var a=m[4]===undefined?1:+m[4];return a>0.5&&(+m[1]+ +m[2]+ +m[3])/3>120}
function playBtn(){var best=null,all=document.querySelectorAll('button,a,div,span');
 for(var i=0;i<all.length;i++){var e=all[i],t=(e.innerText||'').trim();
  if(/^\W*Play$/i.test(t)){var r=e.getBoundingClientRect();if(r.width>0&&r.height>0)best=e}}
 return best}
"""

class BrowserHolder(val view: WebView) : PlayCtl {
    var progress by mutableStateOf(0)
    var loading by mutableStateOf(false)
    var canBack by mutableStateOf(false)
    var url by mutableStateOf("")
    var title by mutableStateOf("")
    var error by mutableStateOf<String?>(null)
    var showList by mutableStateOf(false)
    val found = mutableStateListOf<Sniffed>()
    var ua: String = ""
    @Volatile var pageUrl: String = ""
    var onFound: (Sniffed) -> Unit = {}
    private val main = Handler(Looper.getMainLooper())

    /** may be called from any thread: the list is only changed on the main thread */
    fun report(s: Sniffed) {
        main.post {
            if (found.size < 40 && found.none { it.url == s.url }) { found.add(s); onFound(s) }
        }
    }

    /** a video address the person tapped on the page (a link, or a file the page offers to download) */
    fun file(u: String) {
        report(Sniffed(u, sniffKind(u) ?: "VIDEO", headersFor(u, null)))
        main.post { showList = true }
    }

    fun headersFor(u: String, ref: String?): Map<String, String> {
        val hd = LinkedHashMap<String, String>()
        val r = ref ?: pageUrl
        if (r.isNotBlank()) hd["Referer"] = r
        if (ua.isNotBlank()) hd["User-Agent"] = ua
        val ck = try { CookieManager.getInstance().getCookie(u) } catch (e: Exception) { null }
        if (!ck.isNullOrBlank()) hd["Cookie"] = ck
        return hd
    }

    private suspend fun js(body: String): String? = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
        kotlinx.coroutines.suspendCancellableCoroutine<String?> { c ->
            view.evaluateJavascript("(function(){try{" + WEB_JS + body + "}catch(e){return 'err'}})()") { r -> if (c.isActive) c.resume(r) {} }
        }
    }
    private fun unq(r: String?): String = try { JSONTokener(r ?: "\"\"").nextValue() as? String ?: "" } catch (e: Exception) { "" }

    override suspend fun items(): Pair<List<WebItem>, List<WebItem>> {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { view.onResume() }
        val r = unq(js("""return JSON.stringify({e:cards().map(function(c){var raw=(c.innerText||'');var ls=raw.split('\n').map(function(x){return x.trim()}).filter(Boolean);
            var code=(/S\d{1,2}\s*E\d{1,3}/i.exec(raw)||['Episode'])[0].toUpperCase();
            var title='';for(var k=0;k<ls.length;k++){if(!/^[\d\s·.\-:m]+$/i.test(ls[k])&&!/^NOW\s*PLAY/i.test(ls[k])&&!/^S\d{1,2}\s*E\d{1,3}$/i.test(ls[k])&&ls[k].length>2){title=ls[k];break}}
            return {t:(code+' '+title).slice(0,60),c:/NOW\s*PLAY/i.test(raw)}}),q:quals().map(function(c){return {t:lab(c).slice(0,50),c:isOn(c)}})})"""))
        return try {
            val o = JSONObject(r)
            fun conv(a: JSONArray) = (0 until a.length()).map { WebItem(a.getJSONObject(it).getString("t"), a.getJSONObject(it).getBoolean("c")) }
            conv(o.getJSONArray("e")) to conv(o.getJSONArray("q"))
        } catch (e: Exception) { emptyList<WebItem>() to emptyList() }
    }

    override suspend fun choose(kind: String, idx: Int): Sniffed? {
        val before = found.map { it.url }.toSet()
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { view.onResume() }
        js(if (kind == "ep") "var l=cards();if(l[$idx])l[$idx].click();return 'ok'" else "var l=quals();if(l[$idx])l[$idx].click();return 'ok'")
        for (n in 0 until 36) {
            kotlinx.coroutines.delay(500)
            found.firstOrNull { it.url !in before }?.let {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { view.onPause() }
                return it
            }
            if (n == 2 || n == 8 || n == 16) js("var b=playBtn();if(b)b.click();return 'ok'")   // the page's own Play button
        }
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { view.onPause() }
        return null
    }

    fun sync() {
        canBack = view.canGoBack()
        view.url?.let { url = it; pageUrl = it }
    }

    fun dispose() {
        (view.parent as? ViewGroup)?.removeView(view)
        try { view.stopLoading() } catch (e: Exception) { }
        view.destroy()
    }
}

@SuppressLint("SetJavaScriptEnabled")
fun createBrowser(ctx: Context, start: String): BrowserHolder {
    val wv = WebView(ctx)
    val h = BrowserHolder(wv)
    wv.setBackgroundColor(android.graphics.Color.BLACK)
    wv.settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        useWideViewPort = true
        loadWithOverviewMode = true
        setSupportZoom(true)
        builtInZoomControls = true
        displayZoomControls = false
        mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        mediaPlaybackRequiresUserGesture = true
        allowFileAccess = false
    }
    h.ua = wv.settings.userAgentString ?: ""
    try { CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true) } catch (e: Exception) { }
    wv.webViewClient = object : WebViewClient() {
        // every file the page asks for passes here (on a background thread): video addresses are noted, nothing is blocked
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            val u = request.url.toString()
            val kind = sniffKind(u)
            if (kind != null) h.report(Sniffed(u, kind, h.headersFor(u, request.requestHeaders["Referer"])))
            return null
        }
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val u = request.url.toString()
            if (isVideoUrl(u)) { h.file(u); return true }               // a link straight to a video file
            return !u.startsWith("http", ignoreCase = true)            // block intent:, market:, tel: ... links
        }
        override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
            h.loading = true; h.error = null; h.found.clear(); h.sync()
        }
        override fun onPageFinished(view: WebView, url: String?) { h.loading = false; h.sync() }
        override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) { h.sync() }
        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (request.isForMainFrame) h.error = error.description?.toString() ?: "The page could not be loaded"
        }
    }
    wv.webChromeClient = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) { h.progress = newProgress }
        override fun onReceivedTitle(view: WebView, title: String?) { h.title = title ?: "" }
    }
    // a link the site sends as a file download
    wv.setDownloadListener(DownloadListener { u, _, _, _, _ -> h.file(u) })
    // press and hold a link to a video
    wv.setOnLongClickListener { v ->
        val r = (v as WebView).hitTestResult
        val ex = r.extra
        if ((r.type == WebView.HitTestResult.SRC_ANCHOR_TYPE || r.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) && ex != null && sniffKind(ex) != null) {
            h.file(ex); true
        } else false
    }
    wv.loadUrl(start)
    return h
}

/** Full-screen browser: address bar on top, the page below, a red button appears when the page plays a video. */
@Composable
fun BrowserScreen(h: BrowserHolder, onClose: () -> Unit, onPlay: (Sniffed) -> Unit, onDownload: (Sniffed) -> Unit) {
    val ctx = LocalContext.current
    val focus = LocalFocusManager.current
    var address by remember { mutableStateOf(h.url) }
    var focused by remember { mutableStateOf(false) }
    h.onFound = { _ ->
        if (h.found.size == 1) Toast.makeText(ctx, "Video found: tap the red button to play or download", Toast.LENGTH_SHORT).show()
    }
    LaunchedEffect(h.url) { if (!focused) address = h.url }
    BackHandler { if (h.view.canGoBack()) h.view.goBack() else onClose() }
    // a hidden page stops running (battery), and its own player stops when you play a video in Trio Player
    DisposableEffect(h) { h.view.onResume(); onDispose { h.view.onPause() } }

    Column(Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { h.view.goBack() }, enabled = h.canBack) {
                Icon(Icons.Filled.ArrowBack, "Back", tint = if (h.canBack) Color.White else Color(0xFF55555C))
            }
            OutlinedTextField(
                address, { address = it }, singleLine = true,
                modifier = Modifier.weight(1f).onFocusChanged { focused = it.isFocused },
                textStyle = TextStyle(fontSize = 14.sp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { focus.clearFocus(); h.view.loadUrl(fixUrl(address)) })
            )
            IconButton(onClick = { h.view.reload() }) { Icon(Icons.Filled.Refresh, "Reload", tint = Color.White) }
            IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Close browser", tint = Color.White) }
        }
        Box(Modifier.fillMaxWidth().height(3.dp)) {
            if (h.loading) LinearProgressIndicator(progress = { h.progress / 100f }, color = RED_, trackColor = Color.Transparent, modifier = Modifier.fillMaxSize())
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                factory = { h.view.also { (it.parent as? ViewGroup)?.removeView(it) } },
                modifier = Modifier.fillMaxSize()
            )
            h.error?.let { msg ->
                Column(Modifier.fillMaxSize().background(BG).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("Can't open this page", fontSize = 18.sp)
                    Text(msg, Modifier.padding(top = 8.dp), color = Color(0xFF9A9A9A), textAlign = TextAlign.Center)
                    Button(onClick = { h.error = null; h.view.reload() }, modifier = Modifier.padding(top = 16.dp)) { Text("Try again") }
                }
            }
            if (h.found.isNotEmpty()) Button(
                onClick = { h.showList = true },
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp)
            ) { Text("▶  " + h.found.size + (if (h.found.size == 1) " video" else " videos") + " found") }
        }
    }
    if (h.showList) VideoListDialog(
        h,
        onPlay = { h.showList = false; onPlay(it) },
        onDownload = onDownload,
        onDismiss = { h.showList = false }
    )
}

/** Every video the page asked for: Play it in Trio Player or Download it. */
@Composable
fun VideoListDialog(h: BrowserHolder, onPlay: (Sniffed) -> Unit, onDownload: (Sniffed) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Videos on this page", fontSize = 18.sp) },
        text = {
            if (h.found.isEmpty()) Text("No video found yet. Start the video on the page, then open this list again.", color = Color(0xFF9A9A9A))
            else LazyColumn(Modifier.heightIn(max = 400.dp)) {
                items(h.found.toList(), key = { it.url }) { s ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                s.kind, Modifier.background(RED_, RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 1.dp),
                                color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold
                            )
                            Text(fileNameOf(s.url), Modifier.padding(start = 8.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                        }
                        Text(s.url.substringAfter("//"), color = Color(0xFF8A8A92), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (s.streamOnly) Text("Plays in Trio Player. Streams like this cannot be saved as one file.", color = Color(0xFF8A8A92), fontSize = 11.sp)
                        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onPlay(s) }, modifier = Modifier.weight(1f)) { Text("▶  Play") }
                            if (!s.streamOnly) OutlinedButton(onClick = { onDownload(s) }, modifier = Modifier.weight(1f)) {
                                DownloadIcon(Color.White, 18.dp)
                                Spacer(Modifier.width(6.dp))
                                Text("Download")
                            }
                        }
                    }
                    HorizontalDivider(color = Color(0xFF2A2A30))
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
